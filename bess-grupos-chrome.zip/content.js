'use strict';
/* Le pone a la pestaña el nombre de su sitio y equipo (ej. "DESA · Contenedor BYD 1")
   para identificarla dentro de los grupos. Usa el mapa que el popup guarda en vivo
   (chrome.storage); si no hay, usa la lista base (SEED). Se re-aplica un rato porque
   algunas HMIs ponen su propio título al cargar. */
(function () {
  function apply(byHost) {
    try {
      var rec = byHost && byHost[location.hostname];
      if (!rec) return;
      var eq = rec.ports && rec.ports[location.port || ''];
      var desired = rec.site + (eq && eq !== 'HMI' ? ' · ' + eq : '');
      function set() { try { if (document.title !== desired) document.title = desired; } catch (e) {} }
      set();
      var n = 0, iv = setInterval(function () { set(); if (++n > 30) clearInterval(iv); }, 400);
      window.addEventListener('DOMContentLoaded', set);
      window.addEventListener('load', set);
      try {
        var obs = new MutationObserver(set);
        var attach = function () { var t = document.querySelector('title'); if (t) { obs.observe(t, { childList: true }); } else if (document.head) { obs.observe(document.head, { childList: true, subtree: true }); } };
        if (document.head) attach(); else window.addEventListener('DOMContentLoaded', attach);
      } catch (e) {}
    } catch (e) {}
  }
  var seedBH = (window.BESS && window.SEED) ? window.BESS.buildByHost((window.SEED.sites) || []) : {};
  try {
    chrome.storage.local.get('byHost', function (r) {
      apply((r && r.byHost) ? r.byHost : seedBH);
    });
  } catch (e) {
    apply(seedBH);
  }
})();
