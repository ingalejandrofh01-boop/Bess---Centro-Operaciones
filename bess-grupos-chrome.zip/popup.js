'use strict';
/* Abre los HMIs de un grupo en pestañas nuevas y las junta en un grupo de Chrome.
   Los sitios se bajan EN VIVO desde la app (Firebase); si falla, usa la lista base. */

const CHROME_COLORS = ['grey', 'blue', 'red', 'yellow', 'green', 'pink', 'purple', 'cyan', 'orange'];

async function openGroup(title, items, color) {
  if (!items || !items.length) { return; }
  if (items.length > 15 && !confirm('Vas a abrir ' + items.length + ' pestañas de "' + title + '". ¿Continuar?')) return;
  let win;
  try { win = await chrome.windows.getCurrent(); } catch (e) { win = null; }
  const tabIds = [];
  for (const it of items) {
    try {
      const t = await chrome.tabs.create({ url: it.url, active: false, windowId: win ? win.id : undefined });
      tabIds.push(t.id);
    } catch (e) { /* ignora una URL que falle */ }
  }
  if (!tabIds.length) return;
  try {
    const groupId = await chrome.tabs.group({ tabIds });
    const col = (CHROME_COLORS.indexOf(color) >= 0) ? color : 'blue';
    await chrome.tabGroups.update(groupId, { title: title, color: col });
  } catch (e) { console.warn('No se pudo agrupar:', e && e.message); }
}

function dotColor(color) {
  return ({ grey: '#9aa4b8', blue: '#3f6cff', red: '#e5484d', yellow: '#d8a200', green: '#30a46c', pink: '#e93d82', purple: '#8e4ec6', cyan: '#0ea5a4', orange: '#e5790a' })[color] || '#3f6cff';
}
function rowBtn(label, count, color, onClick) {
  const b = document.createElement('button'); b.className = 'btn';
  const dot = document.createElement('span'); dot.className = 'dot'; dot.style.background = dotColor(color);
  const nm = document.createElement('span'); nm.className = 'nm'; nm.textContent = label;
  const ct = document.createElement('span'); ct.className = 'ct'; ct.textContent = count;
  b.appendChild(dot); b.appendChild(nm); b.appendChild(ct); b.onclick = onClick;
  return b;
}
function sect(text) { const d = document.createElement('div'); d.className = 'sect'; d.textContent = text; return d; }

function render(INV, live) {
  const app = document.getElementById('app');
  app.innerHTML = '';

  app.appendChild(sect('Por zona'));
  (INV.zoneOrder || []).forEach(function (z) {
    const items = INV.zones[z] || []; if (!items.length) return;
    const color = (INV.zoneColors || {})[z] || 'blue';
    app.appendChild(rowBtn(z, items.length, color, function () { openGroup(z, items, color); }));
  });

  const typeOrder = INV.typeOrder || [];
  if (typeOrder.length) {
    app.appendChild(sect('Por tipo de equipo'));
    typeOrder.forEach(function (t) {
      const items = INV.types[t] || []; if (!items.length) return;
      const color = (INV.typeColors || {})[t] || 'green';
      app.appendChild(rowBtn(t, items.length, color, function () { openGroup(t, items, color); }));
    });
  }

  if ((INV.solar || []).length) {
    app.appendChild(sect('Monitoreo PV / Solar'));
    app.appendChild(rowBtn('☀️ Plataformas solar', INV.solar.length, 'yellow', function () { openGroup('PV / Solar', INV.solar, 'yellow'); }));
  }

  app.appendChild(sect('Todo'));
  const allBtn = rowBtn('Abrir TODOS los sitios', (INV.all || []).length, 'grey', function () { openGroup('Todos', INV.all || [], 'grey'); });
  allBtn.classList.add('allbtn'); allBtn.querySelector('.dot').style.display = 'none';
  app.appendChild(allBtn);

  const foot = document.createElement('div'); foot.className = 'foot';
  foot.innerHTML = (live
    ? '<span style="color:#30d158">● en vivo</span> — sincronizado con la app.'
    : '<span style="color:#e5a00a">● sin conexión</span> — mostrando la lista base.') +
    '<br>Las IPs 100.96.x.x funcionan solo con la VPN activa.';
  app.appendChild(foot);
}

document.addEventListener('DOMContentLoaded', function () {
  const app = document.getElementById('app');
  app.innerHTML = '<div style="padding:22px 16px;color:#9fb0d6;font-size:12.5px">Cargando sitios…</div>';
  window.BESS.getSites(function (sites, live) {
    try { if (chrome.storage) chrome.storage.local.set({ byHost: window.BESS.buildByHost(sites) }); } catch (e) {}
    render(window.BESS.buildINV(sites), live);
  });
});
