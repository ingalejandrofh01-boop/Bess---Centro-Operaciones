'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Reloj flotante por sitio en Chrome (ventana de descarga + desfase de medidor).
   - Detecta el sitio por la IP del HMI abierto.
   - Calcula su ventana (región × temporada) y la recorre por el desfase del medidor.
   - Se sincroniza con lo que edites en la app (Firebase: medidor_bess/ventanas y
     medidor_bess/sitios_cfg). Si Firebase no responde, usa los valores por defecto.
   - Muestra un contador en tiempo real: cuánto falta para iniciar / para terminar.
   ═══════════════════════════════════════════════════════════════════════════ */
(function(){
  if (window.top !== window.self) return;            /* solo el frame principal */
  var FB_PROJECT='bitacora-descarga', FB_KEY='AIzaSyA7pwEgAPXzY8H193YuJCTu7H5cs8N7yFo';

  /* Ventana base en hora LOCAL del sitio (igual para todos); la zona horaria solo mueve el reloj. */
  var BASE_DEFAULT = { verano:{inicio:'20:00', fin:'22:00'}, invierno:{inicio:'18:00', fin:'22:00'} };
  var WINTER_DEFAULT = { inicio:-2, fin:2 };            /* invierno: entra 2 min antes, sale 2 min después (de ley) */
  var ZONA = { 'CDMX':0, 'Cancún':60, 'Mazatlán':-60 };  /* minutos respecto a CDMX (la hora del navegador) */
  var IPMAP = {"100.96.1.146":{"name":"Almacén","key":"almacen","region":"Cancún","desfase":0,"ps":88,"pw":45,"bat":"Pylontech","u":[{"n":"B1","ps":88,"pw":45}]},"100.96.3.146":{"name":"Alpha","key":"alpha","region":"Cancún","desfase":3,"ps":231,"pw":116,"bat":"Pylontech","u":[{"n":"B1","ps":231,"pw":116}]},"100.96.3.18":{"name":"BHS","key":"bhs","region":"Cancún","desfase":5,"ps":263,"pw":131,"bat":"Pylontech","u":[{"n":"B1","ps":263,"pw":131}]},"100.96.1.130":{"name":"Comedor","key":"comedor","region":"Cancún","desfase":-1,"ps":88,"pw":44,"bat":"Pylontech","u":[{"n":"B1","ps":88,"pw":44}]},"100.96.1.18":{"name":"FBO","key":"fbo","region":"Cancún","desfase":0,"ps":88,"pw":45,"bat":"Pylontech","u":[{"n":"B1","ps":88,"pw":45}]},"100.96.2.66":{"name":"Huatulco 1","key":"huatulco 1","region":"CDMX","desfase":0,"ps":130,"pw":65,"bat":"Pylontech","u":[{"n":"01","ps":130,"pw":65}]},"100.96.2.34":{"name":"Huatulco 2","key":"huatulco 2","region":"CDMX","desfase":0,"ps":206,"pw":103,"bat":"Pylontech","u":[{"n":"02","ps":206,"pw":103}]},"100.96.1.242":{"name":"Minatitlán","key":"minatitlan","region":"CDMX","desfase":0,"ps":263,"pw":131,"bat":"Pylontech","u":[{"n":"B1","ps":263,"pw":131}]},"100.96.4.66":{"name":"PTAR","key":"ptar","region":"Cancún","desfase":2.5,"ps":88,"pw":44,"bat":"Pylontech","u":[{"n":"B1","ps":88,"pw":44}]},"100.96.1.178":{"name":"T2","key":"t2","region":"Cancún","desfase":0,"ps":1780,"pw":885,"bat":"CATL","u":[{"n":"B1","ps":870,"pw":430},{"n":"B2","ps":910,"pw":455}]},"100.96.1.226":{"name":"T4","key":"t4","region":"Cancún","desfase":0,"ps":2747,"pw":1404,"bat":"CATL","u":[{"n":"B1","ps":967,"pw":468},{"n":"B2","ps":890,"pw":468},{"n":"B3","ps":890,"pw":468}]},"100.96.2.146":{"name":"Veracruz","key":"veracruz","region":"CDMX","desfase":7,"ps":805,"pw":397,"bat":"CATL","u":[{"n":"B1","ps":805,"pw":397}]},"100.96.1.34":{"name":"Chihuahua","key":"chihuahua","region":"CDMX","desfase":0,"ps":175,"pw":150,"bat":"Pylontech","u":[{"n":"B1","ps":175,"pw":150}]},"100.96.1.114":{"name":"Durango","key":"durango","region":"CDMX","desfase":0,"margen":30,"ps":400,"pw":400,"bat":"Pylontech","u":[{"n":"B1","ps":400,"pw":400}]},"100.96.2.50":{"name":"Torreón","key":"torreon","region":"CDMX","desfase":0,"ps":310,"pw":310,"bat":"Pylontech","u":[{"n":"B1","ps":310,"pw":310}]},"100.96.2.162":{"name":"Zacatecas","key":"zacatecas","region":"CDMX","desfase":0,"margen":30,"ps":106,"pw":106,"bat":"Pylontech","u":[{"n":"B1","ps":106,"pw":106}]},"100.96.1.210":{"name":"Zihuatanejo","key":"zihuatanejo","region":"CDMX","desfase":42,"margen":30,"ps":732,"pw":732,"bat":"CATL","u":[{"n":"B1","ps":732,"pw":732}]},"100.96.5.210":{"name":"Park Royal Acapulco","key":"park royal acapulco","region":"CDMX","desfase":0,"ps":582,"pw":291,"bat":"Hoycore","u":[{"n":"B1","ps":582,"pw":291}]},"100.96.5.2":{"name":"Park Royal CBE","key":"park royal cbe","region":"Cancún","desfase":-1,"ps":1290,"pw":645,"bat":"Hoycore","u":[{"n":"B1","ps":1290,"pw":645}]},"100.96.4.242":{"name":"Park Royal Cozumel","key":"park royal cozumel","region":"Cancún","desfase":1,"ps":433,"pw":221,"bat":"Hoycore","u":[{"n":"B1","ps":433,"pw":221}]},"100.96.4.178":{"name":"Park Royal Luna","key":"park royal luna","region":"Cancún","desfase":10,"ps":746,"pw":350,"bat":"Hoycore","u":[{"n":"B1","ps":746,"pw":350}]},"100.96.5.242":{"name":"Park Royal Sol","key":"park royal sol","region":"Cancún","desfase":-1,"ps":288,"pw":144,"bat":"Hoycore","u":[{"n":"B1","ps":288,"pw":144}]},"100.96.5.98":{"name":"Park Royal Vallarta","key":"park royal vallarta","region":"CDMX","desfase":-7.5,"ps":590,"pw":295,"bat":"Hoycore","u":[{"n":"B1","ps":590,"pw":295}]},"100.96.4.82":{"name":"Alysa","key":"alysa","region":"CDMX","desfase":0,"ps":450,"pw":225,"bat":"Hoypower","u":[{"n":"B1","ps":450,"pw":225}]},"100.96.5.114":{"name":"Atotonilco","key":"atotonilco","region":"CDMX","desfase":0,"ps":300,"pw":150,"bat":"BYD","u":[{"n":"B1","ps":300,"pw":150}]},"100.96.3.226":{"name":"Bidasoa","key":"bidasoa","region":"CDMX","desfase":0,"ps":null,"pw":null,"bat":"BYD","u":[]},"100.96.2.210":{"name":"Bocar","key":"bocar","region":"CDMX","desfase":0,"ps":95,"pw":48,"bat":"HoyUltra","u":[{"n":"B1","ps":95,"pw":48}]},"100.96.3.194":{"name":"Brom","key":"brom","region":"CDMX","desfase":5,"ps":750,"pw":550,"bat":"Hoycore","u":[{"n":"B1","ps":750,"pw":550}]},"100.96.5.194":{"name":"Clarimex","key":"clarimex","region":"CDMX","desfase":0,"ps":442,"pw":220,"bat":"Hoycore","u":[{"n":"B1","ps":442,"pw":220}]},"100.96.5.130":{"name":"DESA","key":"desa","region":"CDMX","desfase":-1,"ps":2210,"pw":1105,"bat":"BYD","u":[{"n":"B1","ps":1105,"pw":553},{"n":"B2","ps":1105,"pw":553}]},"100.96.2.98":{"name":"Diseko","key":"diseko","region":"CDMX","desfase":0,"ps":470,"pw":270,"bat":"Hoypower","u":[{"n":"B1","ps":470,"pw":270}]},"100.96.5.82":{"name":"Fisfiber","key":"fisfiber","region":"CDMX","desfase":0,"ps":475,"pw":210,"bat":"Huawei","u":[{"n":"B1","ps":475,"pw":210}]},"100.96.2.82":{"name":"FM Boca del Río","key":"fm boca del rio","region":"CDMX","desfase":0,"ps":90,"pw":48,"bat":"HoyUltra","u":[{"n":"B1","ps":90,"pw":48}]},"100.96.1.66":{"name":"IPASA","key":"ipasa","region":"CDMX","desfase":0,"ps":340,"pw":172,"bat":"HoyUltra","u":[{"n":"1","ps":85,"pw":43},{"n":"2","ps":85,"pw":43},{"n":"3","ps":85,"pw":43},{"n":"4","ps":85,"pw":43}]},"100.96.4.210":{"name":"LG","key":"lg","region":"CDMX","desfase":-3,"ps":12000,"pw":7100,"bat":"BYD","u":[{"n":"B1","ps":12000,"pw":7100}]},"100.96.5.18":{"name":"Plastiexports 1","key":"plastiexports 1","region":"CDMX","desfase":-23,"ps":2340,"pw":1170,"bat":"BYD","u":[{"n":"B1","ps":1170,"pw":585},{"n":"B2","ps":1170,"pw":585}]},"100.96.5.34":{"name":"Plastiexports 3","key":"plastiexports 3","region":"CDMX","desfase":-23,"ps":2700,"pw":1350,"bat":"BYD","u":[{"n":"B1","ps":1350,"pw":675},{"n":"B2","ps":1350,"pw":675}]},"100.96.2.246":{"name":"Regio Pet","key":"regio pet","region":"CDMX","desfase":0,"ps":null,"pw":null,"bat":"","u":[]},"100.96.4.2":{"name":"Resideo","key":"resideo","region":"CDMX","desfase":0,"ps":750,"pw":375,"bat":"Hoycore","u":[{"n":"B1","ps":750,"pw":375}]},"100.96.3.242":{"name":"Tejidos y Texturizados","key":"tejidos y texturizados","region":"CDMX","desfase":0,"ps":412,"pw":206,"bat":"Hoycore","u":[{"n":"B1","ps":412,"pw":206}]},"100.96.4.130":{"name":"THOR","key":"thor","region":"CDMX","desfase":3,"ps":1800,"pw":900,"bat":"Hoycore","u":[{"n":"B1","ps":900,"pw":450},{"n":"B2","ps":900,"pw":450}]},"100.96.2.2":{"name":"TOTIS","key":"totis","region":"CDMX","desfase":0,"ps":850,"pw":425,"bat":"Hoypower","u":[{"n":"B1","ps":850,"pw":425}]},"100.96.5.162":{"name":"TUGAL","key":"tugal","region":"CDMX","desfase":-4,"ps":2250,"pw":1100,"bat":"BYD","u":[{"n":"B1","ps":1125,"pw":550},{"n":"B2","ps":1125,"pw":550}]},"100.96.5.66":{"name":"Tuk","key":"tuk","region":"CDMX","desfase":0,"ps":2500,"pw":1250,"bat":"BYD","u":[{"n":"B1","ps":1250,"pw":625},{"n":"B2","ps":1250,"pw":625}]},"100.96.4.18":{"name":"Vesta","key":"vesta","region":"CDMX","desfase":5,"ps":450,"pw":225,"bat":"Hoycore","u":[{"n":"B1","ps":450,"pw":225}]},"100.96.4.146":{"name":"Vitrogenera","key":"vitrogenera","region":"CDMX","desfase":0,"ps":600,"pw":576,"bat":"Hoypower","u":[{"n":"B1","ps":600,"pw":576}]},"100.96.5.178":{"name":"Vidanta","key":"vidanta","region":"CDMX","desfase":0,"ps":450,"pw":225,"bat":"Hoycore","u":[{"n":"B1","ps":450,"pw":225}]},"100.96.5.226":{"name":"Park Royal Mazatlán","key":"park royal mazatlan","region":"Mazatlán","desfase":0,"ps":292,"pw":144,"bat":"","u":[{"n":"B1","ps":292,"pw":144}]},"100.96.6.2":{"name":"Park Royal Ixtapa","key":"park royal ixtapa","region":"CDMX","desfase":0,"ps":580,"pw":223,"bat":"Hoycore","u":[{"n":"B1","ps":580,"pw":223}]}};

  var ventBase = JSON.parse(JSON.stringify(BASE_DEFAULT));
  var ventWinter = { inicio:WINTER_DEFAULT.inicio, fin:WINTER_DEFAULT.fin };
  var sitiosCfg = {};
  var monitorUrl = '';
  var liveState = null, liveAt = 0;
  function pad2(n){ return String(n).padStart(2,'0'); }

  function seasonNow(){
    var d=new Date(), y=d.getFullYear();
    var apr1=new Date(y,3,1); var firstSunApril=new Date(y,3,1+(7-apr1.getDay())%7);
    var oct31=new Date(y,10,0); var daysToSub=(oct31.getDay()-6+7)%7; var lastSatOct=new Date(y,10,0-daysToSub);
    var t=new Date(y,d.getMonth(),d.getDate());
    return (t>=firstSunApril && t<=lastSatOct) ? 'verano' : 'invierno';
  }
  function key(s){ return String(s||'').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/[^a-z0-9]+/g,' ').trim(); }
  function hhmmToMin(s){ var p=String(s||'0:0').split(':'); return (parseInt(p[0],10)||0)*60+(parseInt(p[1],10)||0); }
  function minToHHMM(m){ m=Math.round(m); m=((m%1440)+1440)%1440; return String(Math.floor(m/60)).padStart(2,'0')+':'+String(m%60).padStart(2,'0'); }
  function fmt(mins, withSecs){
    var tot=Math.max(0,Math.round(mins*60)), h=Math.floor(tot/3600), m=Math.floor((tot%3600)/60), s=tot%60;
    if(h>0) return h+'h '+String(m).padStart(2,'0')+'m';
    if(withSecs) return m+'m '+String(s).padStart(2,'0')+'s';
    return m+' min';
  }

  /* ── Firestore REST (lee lo que guarda la app) ── */
  function fetchDoc(id, cb){
    var url='https://firestore.googleapis.com/v1/projects/'+FB_PROJECT+'/databases/(default)/documents/medidor_bess/'+id+'?key='+FB_KEY;
    fetch(url).then(function(r){ return r.ok?r.json():null; }).then(function(j){
      if(!j||!j.fields||!j.fields.data||!j.fields.data.stringValue){ cb(null); return; }
      try{ cb(JSON.parse(j.fields.data.stringValue)); }catch(e){ cb(null); }
    }).catch(function(){ cb(null); });
  }
  function loadConfig(done){
    try{
      chrome.storage.local.get(['vdCache'], function(res){
        var c=res&&res.vdCache;
        if(c){ if(c.base) ventBase=Object.assign(JSON.parse(JSON.stringify(BASE_DEFAULT)),c.base); if(c.winter) ventWinter=c.winter; if(c.sitios) sitiosCfg=c.sitios||{}; if(c.monitorUrl) monitorUrl=c.monitorUrl; }
        var fresh = c && (Date.now()-(c.at||0) < 5*60*1000);
        if(fresh){ done(); return; }
        fetchDoc('ventanas', function(v){
          if(v && v.base) ventBase=Object.assign(JSON.parse(JSON.stringify(BASE_DEFAULT)), v.base);
          if(v && v.winter) ventWinter=v.winter;
          fetchDoc('sitios_cfg', function(s){
            if(s) sitiosCfg=s;
            fetchDoc('monitor', function(mo){
              if(mo && mo.url) monitorUrl=mo.url;
              try{ chrome.storage.local.set({vdCache:{at:Date.now(), base:ventBase, winter:ventWinter, sitios:sitiosCfg, monitorUrl:monitorUrl}}); }catch(e){}
              done();
            });
          });
        });
      });
    }catch(e){ done(); }
  }

  function siteForHost(){ return IPMAP[location.hostname] || null; }
  function ventanaFor(site){
    var k=site.key, cfg=sitiosCfg[k]||{};
    var region = cfg.region || site.region || 'CDMX';
    var desf = (cfg.desfaseMin!=null) ? Number(cfg.desfaseMin) : (site.desfase||0);
    var excluir = !!cfg.excluir;
    var se = seasonNow();
    var zoneOff = (ZONA[region]!=null)?ZONA[region]:0;
    var base = (ventBase && ventBase[se]) || BASE_DEFAULT[se];
    var waS = se==='invierno' ? ((ventWinter&&ventWinter.inicio!=null)?ventWinter.inicio:WINTER_DEFAULT.inicio) : 0;
    var waE = se==='invierno' ? ((ventWinter&&ventWinter.fin!=null)?ventWinter.fin:WINTER_DEFAULT.fin) : 0;
    var margen = (cfg.margenMin!=null)?Number(cfg.margenMin):(site.margen||0);
    var sMeter = hhmmToMin(base.inicio)+waS-margen;   /* ventana en hora del MEDIDOR (sin desfase ni zona) */
    var eMeter = hhmmToMin(base.fin)+waE+margen;
    return { region:region, season:se, excluir:excluir, desfase:desf, zoneOff:zoneOff,
      inicio:minToHHMM(sMeter), fin:minToHHMM(eMeter),        /* ventana en hora del medidor */
      sBrowser:sMeter+desf-zoneOff, eBrowser:eMeter+desf-zoneOff };  /* real (CDMX) para el contador */
  }

  /* ── Overlay aislado (Shadow DOM) · arrastrable · minimizable ── */
  var host=null, shadow=null, elBig=null, elName=null, elIco=null, elMeta=null, elPill=null, elWrap=null, minimized=false;
  function loadPos(){ try{ return JSON.parse(localStorage.getItem('bessVentPos')||'null'); }catch(e){ return null; } }
  function savePos(x,y){ try{ localStorage.setItem('bessVentPos', JSON.stringify({x:x,y:y})); }catch(e){} }
  function loadMin(){ try{ return localStorage.getItem('bessVentMin')==='1'; }catch(e){ return false; } }
  function saveMin(v){ try{ localStorage.setItem('bessVentMin', v?'1':'0'); }catch(e){} }

  function ensureBox(){
    if(host) return;
    host=document.createElement('div');
    host.id='bess-vent-clock';
    host.style.cssText='position:fixed;z-index:2147483647;right:14px;bottom:14px;width:auto;height:auto;margin:0;padding:0;';
    shadow=host.attachShadow({mode:'open'});
    var style=document.createElement('style');
    style.textContent=
      ':host{all:initial}'
      +'*{box-sizing:border-box;margin:0;padding:0;font-family:"Segoe UI",system-ui,Arial,sans-serif}'
      +'.wrap{width:230px;border-radius:13px;background:rgba(10,20,45,.94);color:#fff;box-shadow:0 10px 30px rgba(0,0,0,.45);border:1px solid rgba(255,255,255,.12);overflow:hidden}'
      +'.hd{display:flex;align-items:center;gap:7px;padding:8px 10px;cursor:grab;touch-action:none}'
      +'.hd:active{cursor:grabbing}'
      +'.ico{font-size:16px;line-height:1}'
      +'.nm{font-weight:800;font-size:13.5px;letter-spacing:.2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex:1}'
      +'.btn{cursor:pointer;color:#9fb4dc;font-size:14px;line-height:1;padding:0 3px;user-select:none}'
      +'.btn:hover{color:#fff}'
      +'.bd{padding:0 10px 10px}'
      +'.big{font-weight:800;font-size:15px;font-variant-numeric:tabular-nums;line-height:1.15}'
      +'.clk{font-weight:800;font-size:12.5px;color:#eaf1ff;margin-top:4px;font-variant-numeric:tabular-nums;letter-spacing:.4px}'
      +'.clk b{color:#7aa2ff}'
      +'.meta{font-size:10.5px;color:#8aa0c8;margin-top:5px;letter-spacing:.2px;line-height:1.4}'
      +'.pb{font-size:10.5px;color:#cdd8ef;margin-top:3px;letter-spacing:.2px;line-height:1.4}'
      +'.bu{font-size:10px;color:#9fb4dc;margin-top:2px;letter-spacing:.2px;line-height:1.35}'
      +'.pill{display:none;align-items:center;gap:7px;padding:7px 11px;border-radius:30px;background:rgba(10,20,45,.94);color:#fff;box-shadow:0 8px 22px rgba(0,0,0,.4);border:1px solid rgba(255,255,255,.14);cursor:pointer;white-space:nowrap}'
      +'.pill .pdot{width:9px;height:9px;border-radius:50%;flex-shrink:0}'
      +'.pill .ptxt{font-weight:800;font-size:12px;font-variant-numeric:tabular-nums}'
      +':host(.min) .wrap{display:none}'
      +':host(.min) .pill{display:inline-flex}';
    shadow.appendChild(style);
    elWrap=document.createElement('div'); elWrap.className='wrap';
    elWrap.innerHTML=
      '<div class="hd" id="hd"><span class="ico" id="ico">🕐</span><span class="nm" id="nm">—</span>'
      +'<span class="btn" id="bmin" title="Minimizar">—</span><span class="btn" id="bcls" title="Ocultar hasta recargar">✕</span></div>'
      +'<div class="bd"><div class="big" id="big">—</div><div class="clk" id="clk"></div><div class="meta" id="meta"></div><div class="pb" id="pb"></div><div class="bu" id="bu"></div></div>';
    elPill=document.createElement('div'); elPill.className='pill'; elPill.id='pill';
    elPill.innerHTML='<span class="pdot" id="pdot"></span><span class="ptxt" id="ptxt">—</span>';
    shadow.appendChild(elWrap); shadow.appendChild(elPill);
    document.documentElement.appendChild(host);
    elBig=shadow.getElementById('big'); elName=shadow.getElementById('nm'); elIco=shadow.getElementById('ico'); elMeta=shadow.getElementById('meta');

    /* restaurar posición */
    var pos=loadPos();
    if(pos && typeof pos.x==='number'){ host.style.left=pos.x+'px'; host.style.top=pos.y+'px'; host.style.right='auto'; host.style.bottom='auto'; }
    minimized=loadMin(); if(minimized) host.classList.add('min');

    /* minimizar / cerrar / expandir */
    shadow.getElementById('bmin').addEventListener('click', function(e){ e.stopPropagation(); minimized=true; host.classList.add('min'); saveMin(true); });
    elPill.addEventListener('click', function(){ minimized=false; host.classList.remove('min'); saveMin(false); });
    shadow.getElementById('bcls').addEventListener('click', function(e){ e.stopPropagation(); try{ sessionStorage.setItem('bessVentHide','1'); }catch(err){} host.style.display='none'; });

    /* arrastrar (desde el encabezado o la pastilla) */
    function dragStart(ev){
      var p=ev.touches?ev.touches[0]:ev;
      var r=host.getBoundingClientRect();
      var offX=p.clientX-r.left, offY=p.clientY-r.top, moved=false;
      function move(e2){
        var q=e2.touches?e2.touches[0]:e2; moved=true;
        var nx=Math.max(2,Math.min(window.innerWidth-r.width-2, q.clientX-offX));
        var ny=Math.max(2,Math.min(window.innerHeight-r.height-2, q.clientY-offY));
        host.style.left=nx+'px'; host.style.top=ny+'px'; host.style.right='auto'; host.style.bottom='auto';
        if(e2.cancelable) e2.preventDefault();
      }
      function up(){
        document.removeEventListener('mousemove',move); document.removeEventListener('mouseup',up);
        document.removeEventListener('touchmove',move); document.removeEventListener('touchend',up);
        if(moved){ var r2=host.getBoundingClientRect(); savePos(r2.left,r2.top); }
      }
      document.addEventListener('mousemove',move); document.addEventListener('mouseup',up);
      document.addEventListener('touchmove',move,{passive:false}); document.addEventListener('touchend',up);
    }
    shadow.getElementById('hd').addEventListener('mousedown',dragStart);
    shadow.getElementById('hd').addEventListener('touchstart',dragStart,{passive:true});
  }

  function badge(v){
    var now=new Date();
    var nowMin=now.getHours()*60+now.getMinutes()+now.getSeconds()/60;
    var sB=v.sBrowser, eB=v.eBrowser; if(eB<=sB) eB+=1440;
    var dS=sB-nowMin, dE=eB-nowMin;
    if(dS>0){
      if(dS>60) return {ico:'🕐', t:'faltan '+fmt(dS,false)+' para iniciar', c:'#9fb4dc', pill:'faltan '+fmt(dS,false)};
      if(dS>15) return {ico:'🕐', t:'faltan '+fmt(dS,false)+' para iniciar', c:'#7aa2ff', pill:'faltan '+fmt(dS,false)};
      return {ico:'🟡', t:'faltan '+fmt(dS,true)+' para iniciar', c:'#fbbf24', pill:'en '+fmt(dS,true)};
    }
    if(dE>0){
      if(dS>-10) return {ico:'🟠', t:'Inicio de ventana · termina en '+fmt(dE,true), c:'#fb923c', pill:'term. '+fmt(dE,true)};
      return {ico:'🔵', t:'En ventana de descarga · termina en '+fmt(dE,true), c:'#60a5fa', pill:'term. '+fmt(dE,true)};
    }
    return {ico:'⚪', t:'Ventana terminada ('+v.fin+')', c:'#94a3b8', pill:'terminó'};
  }
  /* ── Estado EN VIVO del BESS Monitor (Supervisor) ── */
  function fetchState(){
    if(!monitorUrl) return;
    var base=String(monitorUrl).replace(/\/+$/,'');
    fetch(base+'/api/live/state').then(function(r){ return r.ok?r.json():null; }).then(function(arr){ if(Array.isArray(arr)){ liveState=arr; liveAt=Date.now(); } }).catch(function(){});
  }
  function liveForHost(){
    if(!liveState || (Date.now()-liveAt > 60000)) return null;
    var h2=location.host, ip=location.hostname, i;
    for(i=0;i<liveState.length;i++){ if(liveState[i] && liveState[i].host===h2) return liveState[i]; }
    for(i=0;i<liveState.length;i++){ if(liveState[i] && liveState[i].host && String(liveState[i].host).split(':')[0]===ip) return liveState[i]; }
    return null;
  }
  function liveBadge(w){
    var comm=String(w.comm||'').toLowerCase();
    if(comm==='offline'||comm==='caido'||comm.indexOf('off')>=0){ return {ico:'🔴', t:'Sin comunicación', c:'#f87171', pill:'sin com.'}; }
    var crit=(w.issues||[]).filter(function(x){ return x && x.level==='crit'; }).length;
    var bess=w.bess||[], kw=0, anyDesc=false, soc=null;
    bess.forEach(function(b){ if(b){ if(typeof b.kw==='number') kw+=b.kw; if(/descarg/i.test(b.state||'')) anyDesc=true; if(b.soc!=null && soc==null) soc=b.soc; } });
    var socTxt=(soc!=null)?(' · SOC '+Math.round(soc)+'%'):'';
    if(anyDesc || kw>5){
      var g={ico:'🟢', t:'Descargando · '+Math.round(kw)+' kW'+socTxt, c:'#34d399', pill:Math.round(kw)+' kW'};
      if(crit){ g.ico='🟠'; g.t+=' · '+crit+' alarma'+(crit>1?'s':''); g.c='#fbbf24'; }
      return g;
    }
    if(crit) return {ico:'🔴', t:(w.enVentana?'En ventana · ':'')+'sin descargar · '+crit+' alarma'+(crit>1?'s':''), c:'#f87171', pill:crit+' alarma'+(crit>1?'s':'')};
    if(w.enVentana) return {ico:'⚠️', t:'En ventana · SIN descargar · '+Math.round(kw)+' kW', c:'#fb923c', pill:'⚠ 0 kW'};
    return {ico:'⚪', t:'Standby · '+Math.round(kw)+' kW', c:'#94a3b8', pill:'standby'};
  }
  function render(){
    try{ if(sessionStorage.getItem('bessVentHide')==='1'){ if(host) host.style.display='none'; return; } }catch(e){}
    var site=siteForHost(); if(!site) return;
    var v=ventanaFor(site);
    if(v.excluir){ if(host) host.style.display='none'; return; }
    ensureBox(); host.style.display='';
    var live=liveForHost();
    var bd, vivo=false;
    if(live){ bd=liveBadge(live); vivo=true; } else { bd=badge(v); }
    var seIco = v.season==='verano' ? '☀️' : '❄️';
    elIco.textContent=bd.ico;
    elName.textContent=site.name;
    elBig.textContent=bd.t; elBig.style.color=bd.c;
    elMeta.textContent = (vivo?'🟢 En vivo · ':'🕐 Horario · ')+seIco+' '+v.season.charAt(0).toUpperCase()+v.season.slice(1)+' · '+v.region+' · ventana '+v.inicio+'–'+v.fin+(v.desfase?(' · desf '+(v.desfase>0?'+':'')+v.desfase+'m'):'');
    var clkEl=shadow.getElementById('clk');
    if(clkEl){ var nn=new Date();
      var locMin=((nn.getHours()*60+nn.getMinutes()+v.zoneOff-v.desfase)%1440+1440)%1440;
      var hms=pad2(Math.floor(locMin/60))+':'+pad2(locMin%60)+':'+pad2(nn.getSeconds());
      var nowMin=nn.getHours()*60+nn.getMinutes()+nn.getSeconds()/60; var sB=v.sBrowser, eB=v.eBrowser; if(eB<=sB) eB+=1440;
      var zt_t=[]; if(v.desfase) zt_t.push('medidor'); if(v.zoneOff!==0) zt_t.push(v.region); var zt=zt_t.length?(' <b>('+zt_t.join(' \u00B7 ')+')</b>'):'';
      var ct; if(nowMin<sB){ ct='\uD83D\uDD53 '+hms+zt+' \u00B7 entra <b>'+v.inicio+'</b>'; } else if(nowMin<eB){ ct='\uD83D\uDD53 '+hms+zt+' \u00B7 entr\u00F3 '+v.inicio+' \u00B7 sale <b>'+v.fin+'</b>'; } else { ct='\uD83D\uDD53 '+hms+zt+' \u00B7 ventana cerrada'; }
      clkEl.innerHTML=ct; }
    var pbEl=shadow.getElementById('pb');
    if(pbEl){ var ek=(v.season==='verano')?site.ps:site.pw; var parts=[]; if(site.bat) parts.push('\uD83D\uDD0B '+site.bat); if(ek!=null) parts.push('\u26A1 asignada '+ek+' kW'); pbEl.textContent=parts.join(' \u00B7 '); }
    var buEl=shadow.getElementById('bu');
    if(buEl){ if(site.u && site.u.length>1){ var pb2=site.u.map(function(x){ var kv=(v.season==='verano')?x.ps:x.pw; return x.n+' '+(kv!=null?kv:'\u2014'); }); buEl.textContent='\uD83D\uDD38 '+pb2.join(' \u00B7 ')+' kW'; buEl.style.display=''; } else { buEl.textContent=''; buEl.style.display='none'; } }
    var pdot=shadow.getElementById('pdot'), ptxt=shadow.getElementById('ptxt');
    if(pdot){ pdot.style.background=bd.c; } if(ptxt){ ptxt.textContent=site.name+' · '+bd.pill; }
  }

  function boot(){
    if(!siteForHost()) return;
    loadConfig(function(){ fetchState(); render(); });
    setInterval(render, 1000);
    setInterval(fetchState, 8000);
    setInterval(function(){ try{ chrome.storage.local.remove('vdCache'); }catch(e){} loadConfig(function(){}); }, 5*60*1000);
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
