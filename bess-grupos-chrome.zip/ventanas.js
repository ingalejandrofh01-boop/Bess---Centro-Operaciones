'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Reloj flotante por sitio en Chrome (ventana de descarga + desfase de medidor).
   - Detecta el sitio por la IP del HMI abierto.
   - Calcula su ventana (región × temporada) y la recorre por el desfase del medidor.
   - Se sincroniza con lo que edites en la app (Firebase: medidor_bess/ventanas y
     medidor_bess/sitios_cfg). Si Firebase no responde, usa los valores por defecto.
   - Muestra un contador en tiempo real: cuánto falta para iniciar / para terminar.
   ═══════════════════════════════════════════════════════════════════════════ */
(function(){
  if (window.top !== window.self) return;            /* solo el frame principal */
  var FB_PROJECT='bitacora-descarga', FB_KEY='AIzaSyA7pwEgAPXzY8H193YuJCTu7H5cs8N7yFo';

  var VENT_DEFAULT = {
    'CDMX':     { verano:{inicio:'20:00', fin:'22:00'}, invierno:{inicio:'18:00', fin:'22:00'} },
    'Cancún':   { verano:{inicio:'19:00', fin:'21:00'}, invierno:{inicio:'17:00', fin:'21:00'} },
    'Mazatlán': { verano:{inicio:'21:00', fin:'23:00'}, invierno:{inicio:'19:00', fin:'23:00'} }
  };
  var IPMAP = {"100.96.1.146":{"name":"Almacén","key":"almacen","region":"Cancún","desfase":0},"100.96.3.146":{"name":"Alpha","key":"alpha","region":"Cancún","desfase":-2.5},"100.96.3.18":{"name":"BHS","key":"bhs","region":"Cancún","desfase":-5},"100.96.1.130":{"name":"Comedor","key":"comedor","region":"Cancún","desfase":1},"100.96.1.18":{"name":"FBO","key":"fbo","region":"Cancún","desfase":0},"100.96.2.66":{"name":"Huatulco 1","key":"huatulco 1","region":"CDMX","desfase":0},"100.96.2.34":{"name":"Huatulco 2","key":"huatulco 2","region":"CDMX","desfase":0},"100.96.1.242":{"name":"Minatitlán","key":"minatitlan","region":"CDMX","desfase":0},"100.96.4.66":{"name":"PTAR","key":"ptar","region":"Cancún","desfase":-2.5},"100.96.1.178":{"name":"T2","key":"t2","region":"Cancún","desfase":0},"100.96.1.226":{"name":"T4","key":"t4","region":"Cancún","desfase":0},"100.96.2.146":{"name":"Veracruz","key":"veracruz","region":"CDMX","desfase":-7},"100.96.1.34":{"name":"Chihuahua","key":"chihuahua","region":"CDMX","desfase":0},"100.96.1.114":{"name":"Durango","key":"durango","region":"CDMX","desfase":0},"100.96.2.50":{"name":"Torreón","key":"torreon","region":"CDMX","desfase":0},"100.96.2.162":{"name":"Zacatecas","key":"zacatecas","region":"CDMX","desfase":0},"100.96.1.210":{"name":"Zihuatanejo","key":"zihuatanejo","region":"CDMX","desfase":-42},"100.96.5.210":{"name":"Park Royal Acapulco","key":"park royal acapulco","region":"CDMX","desfase":0},"100.96.5.2":{"name":"Park Royal CBE","key":"park royal cbe","region":"Cancún","desfase":0},"100.96.4.242":{"name":"Park Royal Cozumel","key":"park royal cozumel","region":"Cancún","desfase":0},"100.96.4.178":{"name":"Park Royal Luna","key":"park royal luna","region":"Cancún","desfase":-9},"100.96.5.242":{"name":"Park Royal Sol","key":"park royal sol","region":"Cancún","desfase":2},"100.96.5.98":{"name":"Park Royal Vallarta","key":"park royal vallarta","region":"CDMX","desfase":0},"100.96.4.82":{"name":"Alysa","key":"alysa","region":"CDMX","desfase":0},"100.96.5.114":{"name":"Atotonilco","key":"atotonilco","region":"CDMX","desfase":0},"100.96.3.226":{"name":"Bidasoa","key":"bidasoa","region":"CDMX","desfase":0},"100.96.2.210":{"name":"Bocar","key":"bocar","region":"CDMX","desfase":0},"100.96.3.194":{"name":"Brom","key":"brom","region":"CDMX","desfase":0},"100.96.5.194":{"name":"Clarimex","key":"clarimex","region":"CDMX","desfase":0},"100.96.5.130":{"name":"DESA","key":"desa","region":"CDMX","desfase":0},"100.96.2.98":{"name":"Diseko","key":"diseko","region":"CDMX","desfase":0},"100.96.5.82":{"name":"Fisfiber","key":"fisfiber","region":"CDMX","desfase":0},"100.96.2.82":{"name":"FM Boca del Río","key":"fm boca del rio","region":"CDMX","desfase":0},"100.96.1.66":{"name":"IPASA","key":"ipasa","region":"CDMX","desfase":0},"100.96.4.210":{"name":"LG","key":"lg","region":"CDMX","desfase":3},"100.96.5.18":{"name":"Plastiexports 1","key":"plastiexports 1","region":"CDMX","desfase":20},"100.96.5.34":{"name":"Plastiexports 3","key":"plastiexports 3","region":"CDMX","desfase":-3},"100.96.2.246":{"name":"Regio Pet","key":"regio pet","region":"CDMX","desfase":0},"100.96.4.2":{"name":"Resideo","key":"resideo","region":"CDMX","desfase":0},"100.96.3.242":{"name":"Tejidos y Texturizados","key":"tejidos y texturizados","region":"CDMX","desfase":0},"100.96.4.130":{"name":"THOR","key":"thor","region":"CDMX","desfase":-3},"100.96.2.2":{"name":"TOTIS","key":"totis","region":"CDMX","desfase":0},"100.96.5.162":{"name":"TUGAL","key":"tugal","region":"CDMX","desfase":0},"100.96.5.66":{"name":"Tuk","key":"tuk","region":"CDMX","desfase":0},"100.96.4.18":{"name":"Vesta","key":"vesta","region":"CDMX","desfase":0},"100.96.4.146":{"name":"Vitrogenera","key":"vitrogenera","region":"CDMX","desfase":0},"100.96.5.178":{"name":"Vidanta","key":"vidanta","region":"CDMX","desfase":0},"100.96.5.226":{"name":"Park Royal Mazatlán","key":"park royal mazatlan","region":"Mazatlán","desfase":0},"100.96.6.2":{"name":"Park Royal Ixtapa","key":"park royal ixtapa","region":"CDMX","desfase":0}};

  var ventanas = JSON.parse(JSON.stringify(VENT_DEFAULT));
  var sitiosCfg = {};

  function seasonNow(){
    var d=new Date(), y=d.getFullYear();
    var apr1=new Date(y,3,1); var firstSunApril=new Date(y,3,1+(7-apr1.getDay())%7);
    var oct31=new Date(y,10,0); var daysToSub=(oct31.getDay()-6+7)%7; var lastSatOct=new Date(y,10,0-daysToSub);
    var t=new Date(y,d.getMonth(),d.getDate());
    return (t>=firstSunApril && t<=lastSatOct) ? 'verano' : 'invierno';
  }
  function key(s){ return String(s||'').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/[^a-z0-9]+/g,' ').trim(); }
  function hhmmToMin(s){ var p=String(s||'0:0').split(':'); return (parseInt(p[0],10)||0)*60+(parseInt(p[1],10)||0); }
  function minToHHMM(m){ m=Math.round(m); m=((m%1440)+1440)%1440; return String(Math.floor(m/60)).padStart(2,'0')+':'+String(m%60).padStart(2,'0'); }
  function fmt(mins, withSecs){
    var tot=Math.max(0,Math.round(mins*60)), h=Math.floor(tot/3600), m=Math.floor((tot%3600)/60), s=tot%60;
    if(h>0) return h+'h '+String(m).padStart(2,'0')+'m';
    if(withSecs) return m+'m '+String(s).padStart(2,'0')+'s';
    return m+' min';
  }

  /* ── Firestore REST (lee lo que guarda la app) ── */
  function fetchDoc(id, cb){
    var url='https://firestore.googleapis.com/v1/projects/'+FB_PROJECT+'/databases/(default)/documents/medidor_bess/'+id+'?key='+FB_KEY;
    fetch(url).then(function(r){ return r.ok?r.json():null; }).then(function(j){
      if(!j||!j.fields||!j.fields.data||!j.fields.data.stringValue){ cb(null); return; }
      try{ cb(JSON.parse(j.fields.data.stringValue)); }catch(e){ cb(null); }
    }).catch(function(){ cb(null); });
  }
  function loadConfig(done){
    try{
      chrome.storage.local.get(['vdCache'], function(res){
        var c=res&&res.vdCache;
        if(c){ if(c.ventanas) ventanas=Object.assign(JSON.parse(JSON.stringify(VENT_DEFAULT)),c.ventanas); if(c.sitios) sitiosCfg=c.sitios||{}; }
        var fresh = c && (Date.now()-(c.at||0) < 5*60*1000);
        if(fresh){ done(); return; }
        fetchDoc('ventanas', function(v){
          if(v) ventanas=Object.assign(JSON.parse(JSON.stringify(VENT_DEFAULT)), v);
          fetchDoc('sitios_cfg', function(s){
            if(s) sitiosCfg=s;
            try{ chrome.storage.local.set({vdCache:{at:Date.now(), ventanas:ventanas, sitios:sitiosCfg}}); }catch(e){}
            done();
          });
        });
      });
    }catch(e){ done(); }
  }

  function siteForHost(){ return IPMAP[location.hostname] || null; }
  function ventanaFor(site){
    var k=site.key, cfg=sitiosCfg[k]||{};
    var region = cfg.region || site.region || 'CDMX';
    var desf = (cfg.desfaseMin!=null) ? Number(cfg.desfaseMin) : (site.desfase||0);
    var excluir = !!cfg.excluir;
    var se = seasonNow();
    var base = (ventanas[region] && ventanas[region][se]) || VENT_DEFAULT[region][se];
    return { region:region, season:se, excluir:excluir, desfase:desf,
      inicio:minToHHMM(hhmmToMin(base.inicio)+desf), fin:minToHHMM(hhmmToMin(base.fin)+desf) };
  }

  /* ── Overlay ── */
  var box=null;
  function ensureBox(){
    if(box) return box;
    box=document.createElement('div');
    box.id='bess-vent-clock';
    box.style.cssText='position:fixed;z-index:2147483647;right:14px;bottom:14px;min-width:210px;max-width:320px;'
      +'font-family:Segoe UI,Arial,sans-serif;border-radius:13px;padding:10px 12px;'
      +'background:rgba(10,20,45,.93);color:#fff;box-shadow:0 10px 30px rgba(0,0,0,.4);'
      +'backdrop-filter:blur(6px);border:1px solid rgba(255,255,255,.12);user-select:none;cursor:default';
    document.documentElement.appendChild(box);
    return box;
  }
  function badge(v){
    var now=new Date();
    var pi=v.inicio.split(':'), pf=v.fin.split(':');
    var start=new Date(now); start.setHours(+pi[0],+pi[1],0,0);
    var end=new Date(now); end.setHours(+pf[0],+pf[1],0,0);
    if(end<=start) end=new Date(end.getTime()+864e5);
    var dS=(start-now)/60000, dE=(end-now)/60000;
    if(dS>0){
      if(dS>60) return {ico:'🕐', t:'faltan '+fmt(dS,false)+' para iniciar', c:'#9fb4dc'};
      if(dS>15) return {ico:'🕐', t:'faltan '+fmt(dS,false)+' para iniciar', c:'#7aa2ff'};
      return {ico:'🟡', t:'faltan '+fmt(dS,true)+' para iniciar', c:'#fbbf24'};
    }
    if(dE>0){
      if(dS>-10) return {ico:'🟠', t:'Entrando ahora · termina en '+fmt(dE,true), c:'#fb923c'};
      return {ico:'🟢', t:'Descargando · termina en '+fmt(dE,true), c:'#34d399'};
    }
    return {ico:'⚪', t:'Ventana terminada ('+v.fin+')', c:'#94a3b8'};
  }
  function render(){
    try{ if(sessionStorage.getItem('bessVentHide')==='1'){ if(box) box.style.display='none'; return; } }catch(e){}
    var site=siteForHost(); if(!site) return;
    var v=ventanaFor(site);
    var b=ensureBox();
    if(v.excluir){
      b.innerHTML='<div style="display:flex;align-items:center;gap:8px"><span style="font-size:15px">🚫</span>'
        +'<div><div style="font-weight:800;font-size:13px">'+site.name+'</div>'
        +'<div style="font-size:10.5px;color:#94a3b8">Marcado como “No va” — fuera del checklist</div></div>'
        +'<span onclick="sessionStorage.setItem(\'bessVentHide\',\'1\');this.parentNode.parentNode.style.display=\'none\'" style="margin-left:auto;cursor:pointer;color:#94a3b8;font-size:14px;padding:0 2px">✕</span></div>';
      return;
    }
    var bd=badge(v);
    var seIco = v.season==='verano' ? '☀️' : '❄️';
    b.innerHTML=
      '<div style="display:flex;align-items:center;gap:7px;margin-bottom:4px">'
       +'<span style="font-size:16px;line-height:1">'+bd.ico+'</span>'
       +'<span style="font-weight:800;font-size:13.5px;letter-spacing:.2px">'+site.name+'</span>'
       +'<span onclick="sessionStorage.setItem(\'bessVentHide\',\'1\');document.getElementById(\'bess-vent-clock\').style.display=\'none\'" title="Ocultar hasta recargar" style="margin-left:auto;cursor:pointer;color:#8aa0c8;font-size:13px;padding:0 3px">✕</span>'
      +'</div>'
      +'<div style="font-weight:800;font-size:15px;color:'+bd.c+';font-variant-numeric:tabular-nums;line-height:1.15">'+bd.t+'</div>'
      +'<div style="font-size:10.5px;color:#8aa0c8;margin-top:5px;letter-spacing:.2px">'
        +seIco+' '+v.season.charAt(0).toUpperCase()+v.season.slice(1)+' · '+v.region+' · ventana '+v.inicio+'–'+v.fin
        +(v.desfase?(' · desfase '+(v.desfase>0?'+':'')+v.desfase+'m'):'')
      +'</div>';
  }

  function boot(){
    if(!siteForHost()) return;                 /* IP no registrada: no molestar */
    loadConfig(function(){ render(); });
    setInterval(render, 1000);
    /* refresca config de Firebase cada 5 min por si editaron ventanas/desfases */
    setInterval(function(){ try{ chrome.storage.local.remove('vdCache'); }catch(e){} loadConfig(function(){}); }, 5*60*1000);
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
