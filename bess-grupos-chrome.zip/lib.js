'use strict';
/* Librería común: baja los sitios en vivo desde Firebase (los que editas en la app),
   los mezcla con la lista base (SEED) y arma los grupos. Si Firebase falla, usa SEED. */
window.BESS = (function () {
  var FB_PROJECT = 'bitacora-descarga';
  var FB_KEY = 'AIzaSyA7pwEgAPXzY8H193YuJCTu7H5cs8N7yFo';

  var ZC = { 'ASUR': 'blue', 'ASUR Cancún': 'red', 'OMA': 'cyan', 'Park Royal': 'purple', 'Industrial': 'orange', 'Otro': 'grey' };
  var TC = { 'PCS Sinexcel': 'blue', 'PCS Kehua': 'cyan', 'PCS': 'blue', 'Módulos': 'green', 'Contenedores': 'orange', 'BMS': 'purple' };
  var TSEQ = ['PCS Sinexcel', 'PCS Kehua', 'PCS', 'Módulos', 'Contenedores', 'BMS'];

  function slug(s) {
    return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
      .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'z';
  }
  function classify(t) {
    t = (t || '').toLowerCase();
    if (t.indexOf('pcs') >= 0 && t.indexOf('sinexcel') >= 0) return 'PCS Sinexcel';
    if (t.indexOf('pcs') >= 0 && t.indexOf('kehua') >= 0) return 'PCS Kehua';
    if (t.indexOf('pcs') >= 0) return 'PCS';
    if (t.indexOf('contenedor') >= 0) return 'Contenedores';
    if (t.indexOf('módulo') >= 0 || t.indexOf('modulo') >= 0) return 'Módulos';
    if (t.indexOf('bms') >= 0) return 'BMS';
    return 'Otros';
  }
  function isWeb(s) {
    return !!s.hmiUrl && !/vnc/i.test(s.hmiTipo || '') && s.hmiPuerto !== 5900 && s.hmiPuerto !== 6000;
  }

  /* Firestore REST: convierte un valor "tipado" a JS normal */
  function fsVal(v) {
    if (v == null) return null;
    if (v.stringValue !== undefined) return v.stringValue;
    if (v.integerValue !== undefined) return parseInt(v.integerValue, 10);
    if (v.doubleValue !== undefined) return v.doubleValue;
    if (v.booleanValue !== undefined) return v.booleanValue;
    if (v.nullValue !== undefined) return null;
    if (v.timestampValue !== undefined) return v.timestampValue;
    if (v.arrayValue !== undefined) return (v.arrayValue.values || []).map(fsVal);
    if (v.mapValue !== undefined) {
      var o = {}, f = v.mapValue.fields || {};
      for (var k in f) o[k] = fsVal(f[k]);
      return o;
    }
    return undefined;
  }

  function fetchOverrides() {
    var url = 'https://firestore.googleapis.com/v1/projects/' + FB_PROJECT +
      '/databases/(default)/documents/inventario_ip?key=' + FB_KEY + '&pageSize=300';
    return fetch(url).then(function (r) { return r.ok ? r.json() : null; }).then(function (j) {
      if (!j || !j.documents) return {};
      var ov = {};
      j.documents.forEach(function (d) {
        var id = d.name.split('/').pop();
        var o = {}, f = d.fields || {};
        for (var k in f) o[k] = fsVal(f[k]);
        ov[id] = o;
      });
      return ov;
    }).catch(function () { return null; });
  }

  function mergeSites(seedSites, overrides) {
    var map = {}, order = [];
    (seedSites || []).forEach(function (s) { var id = slug(s.sitio); map[id] = Object.assign({}, s); if (order.indexOf(id) < 0) order.push(id); });
    Object.keys(overrides || {}).forEach(function (id) {
      var d = overrides[id] || {};
      if (d._deleted) { delete map[id]; var k = order.indexOf(id); if (k >= 0) order.splice(k, 1); return; }
      map[id] = Object.assign({}, map[id] || {}, d);
      if (order.indexOf(id) < 0) order.push(id);
    });
    return order.map(function (id) { return map[id]; }).filter(Boolean);
  }

  /* Baja sitios en vivo (merge SEED + Firebase). cb(sites, enVivo) */
  function getSites(cb) {
    var seed = (window.SEED && window.SEED.sites) || [];
    fetchOverrides().then(function (ov) {
      if (ov === null) { cb(seed, false); return; }
      cb(mergeSites(seed, ov), true);
    });
  }

  function buildINV(sites) {
    var zones = {}, seenz = [];
    sites.forEach(function (s) { var z = s.zona || 'Otro'; if (!zones[z]) { zones[z] = []; } if (seenz.indexOf(z) < 0) seenz.push(z); if (isWeb(s)) zones[z].push({ name: s.sitio, url: s.hmiUrl }); });
    var zoneOrder = seenz.filter(function (z) { return zones[z] && zones[z].length; });
    var types = {}; TSEQ.forEach(function (k) { types[k] = []; });
    sites.forEach(function (s) {
      (s.equipos || []).forEach(function (e) {
        var cat = classify(e.tipo); if (!types[cat]) return;
        var u = e.url || ''; if (cat === 'Contenedores' && u.indexOf('http://') === 0) u = 'https://' + u.slice(7);
        var nm = (s.sitio + ' · ' + (e.tipo || '') + (e.n ? (' ' + e.n) : '')).trim();
        if (u) types[cat].push({ name: nm, url: u });
      });
    });
    var typeOrder = TSEQ.filter(function (k) { return types[k].length; });
    var all = sites.filter(isWeb).map(function (s) { return { name: s.sitio, url: s.hmiUrl }; });
    var solar = ((window.SEED && window.SEED.solar) || []).map(function (p) { return { name: p.nombre, url: p.link }; });
    return { zones: zones, zoneOrder: zoneOrder, types: types, typeOrder: typeOrder, all: all, solar: solar, zoneColors: ZC, typeColors: TC };
  }

  function buildByHost(sites) {
    var bh = {};
    sites.forEach(function (s) {
      if (!s.ip) return;
      var ports = {};
      if (s.hmiPuerto) ports[String(s.hmiPuerto)] = 'HMI';
      (s.equipos || []).forEach(function (e) { if (e.puerto) ports[String(e.puerto)] = ((e.tipo || '') + (e.n ? (' ' + e.n) : '')).trim(); });
      bh[s.ip] = { site: s.sitio, ports: ports };
    });
    return bh;
  }

  return { getSites: getSites, buildINV: buildINV, buildByHost: buildByHost, mergeSites: mergeSites, fetchOverrides: fetchOverrides, slug: slug };
})();
