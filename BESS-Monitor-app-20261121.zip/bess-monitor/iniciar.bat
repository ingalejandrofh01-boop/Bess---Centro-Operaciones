@echo off
cd /d "%~dp0"
echo ============================================
echo   BESS Monitor - instalando/actualizando...
echo ============================================
call npm install
if errorlevel 1 (
    echo.
    echo Hubo un error instalando los paquetes. Revisa el mensaje de arriba.
    pause
    exit /b 1
)
echo.
echo ============================================
echo   Encendiendo el servidor...
echo ============================================
call npm start
pause
