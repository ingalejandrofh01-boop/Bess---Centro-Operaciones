# Supervisor en vivo — BESS Monitor

Pantalla nueva dentro del BESS Monitor para ver **Red · Consumo · BESS · SOC** de todos los sitios, con clasificación automática (NULO / NEGATIVO / BAJO / NORMAL / ALTO / EXCEDIDO), semáforo por sitio y **alertas por voz**. Todo corre en tu PC (localhost), sin Firebase.

## v24 · Solis: lee TODOS los sitios (todas las páginas) + clima real por radiación solar

- **Relay Solis v1.3**: ahora recorre **todas las páginas** de la lista de plantas (antes se quedaba en las del inicio).
  Va a la primera página y avanza con el botón siguiente **esperando a que cada página cargue de verdad** (no por tiempo fijo),
  así captura las 200+ plantas completas. Campos reales de Solis ya mapeados: potencia, generación del día, capacidad,
  dirección, inversores en línea/total, lat/lon y el **texto de la alarma** (p. ej. "Fallo de aislamiento DC").
- **Se refresca solo**: reenvía lo capturado cada 60 s (para que el Supervisor no lo marque "sin datos") y hace un barrido
  completo cada 10 min. No hay que estar recargando.
- **El clima ahora es dato real del sitio**: el monitor consulta la **radiación solar del día** por ubicación (Open-Meteo,
  gratis y sin credenciales) y con ella calcula cuánto *debería* generar cada planta hoy (kWh/m² = horas plena carga).
  El desempeño ("Generó correctamente / algo baja / por debajo") usa esa radiación como determinante; si no hay internet,
  cae con elegancia al texto del clima o a un valor medio. Deja la pestaña de Solis abierta con tu sesión y entra a la **Lista de plantas**.

## v23 · PV: desempeño (clima como determinante), dirección, inversores, nominal y tipo de alarma

- **Desempeño del día por planta**: calcula las horas equivalentes (kWh/kWp) y las compara con lo esperado según el **clima**.
  Veredicto: "Generó correctamente", "algo baja" o "por debajo de lo esperado". El clima es el determinante (nublado = generar menos es normal).
- Al dar **clic en un sitio** (dashboard PV) se ve: dirección, inversores en línea/total, potencia nominal, clima, generación, curva del día, desempeño y alarmas con su **tipo** (texto).
- **Relay Solis v1.2**: captura dirección, inversores, nominal, clima y el **texto de las alarmas** (de la página de alarmas de Solis). Trae un diagnóstico con los nombres de campo reales para calibrar si algo no cuadra.
- La curva de generación se va llenando con las lecturas del día y se parece a la del portal conforme pasa el tiempo.

## v22 · PV en una sola división con filtros por plataforma + BESS de FusionSolar

- El PV es ahora **un solo apartado** "☀️ Generación Solar (PV)" con **chips por plataforma** (Todas / FusionSolar / SolisCloud / iSolarCloud / SMA). Ya no hay un bloque de FusionSolar aparte.
- Las plantas FusionSolar **con batería** (Fisfiber, Abadimex) salen en una sección **🔋 BESS · FusionSolar** (lado BESS) Y en el apartado PV (lado solar): aparecen como tarjeta en los dos.
- Abadimex se agregó a la lista de sitios PV (no venía en el .txt original).

## v21 · Filtro "solo mis sitios" en PV

- El PV ahora puede mostrar **solo los sitios de tu lista** (los 79 que pasaste, en config/pv-sitios.json).
- Botón **"Solo mis sitios"** en el apartado ☀️ PV del Supervisor (solo admin). Enciende/apaga el filtro; dice cuántos quedan ocultos.
- El filtro aplica en todo el PV: dashboard, reportes e histórico.
- El match es flexible (ignora acentos/mayúsculas y reconoce nombres parecidos), así que "FM Boca del río" reconoce "FM Boca del Rio-Veracruz".
- Para agregar o quitar sitios, edita config/pv-sitios.json (lista "sitios").

## v20 · Relay de SolisCloud (PV)

- Nuevo **Skysense - SolisCloud Relay** para Tampermonkey. Desde la pestaña de SolisCloud con tu sesión, manda al Supervisor
  estado (en línea / alarma / sin conexión), generación del día, potencia y capacidad de **todas** las plantas Solis.
- No usa IP ni pide credenciales: reutiliza la propia petición (firmada) que hace la página y la reenvía solo a 127.0.0.1.
  Al refrescar reutiliza esa firma; si vence, le pide a la app que recargue su lista.
- Aparece en el apartado **☀️ PV** del Supervisor y en los reportes, junto con FusionSolar.
- La primera vez manda un diagnóstico con los nombres de campo reales para afinar el mapeo si algún valor no cuadra.
- **Skysense - SolisCloud Auto Login**: si Solis cierra la sesión, vuelve a entrar solo con el usuario que guardes en su menú de Tampermonkey (solo en esa PC). Si Solis pide captcha/verificación, no lo intenta y te avisa.

## v19 · Reportes PV por fechas (semana/mes/año) con estimado CFE

- Nueva página **/supervisor/pv/reportes** (botón "📅 Reportes" en el dashboard PV), al estilo del histórico del BESS:
  periodo **Semana / Mes / Año / Rango** con flechas para moverse, filtro **por sitio** o todos, agrupación por día/semana/mes.
- **Tendencia de generación** (gráfica de barras por día/semana/mes), KPIs de generación FV, consumo del cliente, energía de red (CFE),
  vendido, promedio diario y **ahorro estimado CFE** (editable $/kWh), y tabla **por sitio** con totales y ahorro.
- Exporta **CSV** (día por día) y **🖨 PDF** (reporte profesional del periodo).
- El monitor guarda ahora el **total diario** de cada planta (~2 años) en data/pv/diario/ para armar estos reportes.
- Corregido: los valores **-99,999,999** (dato inválido de FusionSolar) ya no se muestran; salen como "—".

## v18 · Barra superior remasterizada + PV con más parámetros, CSV y reporte PDF

- **Barra superior más compacta**: una sola fila de título + contadores y una barra de acciones delgada. Las acciones menos usadas
  (modo noche, probar voz, bitácora, calibrar VNC, configurar, monitor) quedan en el menú **⋯ Más**. Se quitó el espacio vacío de arriba.
- **Alertas** ya no se desплazan de lado: se acomodan en varias líneas y, si hay muchas, aparece "+N más · ver bitácora".
- **Modo TV arreglado**: al salir de pantalla completa (Esc o el botón del navegador) vuelve la barra de opciones sola, ya no hay que reiniciar.
- **PV con más parámetros**: por planta y en el dashboard ahora sale generación FV, **consumo del cliente**, **energía de red (CFE)**,
  vendido a red y autoconsumo, con el reparto de la generación. (Vienen de FusionSolar; Solis/Sungrow/SMA al integrar sus Relay.)
- **Exportar en /supervisor/pv**: botón **⬇ CSV** (tabla del día) y **🖨 Reporte PDF** (reporte profesional con totales y ahorro estimado CFE, imprime a PDF).
- Curva de potencia FV del día y alarmas/cortes con hora en el detalle de cada planta.

## v17 · Apartado PV (generación solar), aparte del BESS

- Nuevo apartado **☀️ Generación Solar (PV)** en el Supervisor y una página aparte **/supervisor/pv** (botón "☀️ PV"):
  dashboard con potencia en vivo, energía del día, ahorro estimado CFE (editable $/kWh), en línea / alarma / sin comunicación,
  disponibilidad, tabla ordenable con barra de comunicación del día, y al hacer clic: curva de generación del día + alarmas/cortes con hora y "desde cuándo".
- Se alimenta de los portales por sus Relay (sin IP ni credenciales):
  **FusionSolar** (ya integrado; aquí sale su lado solar), y faltan **SolisCloud**, **iSolarCloud (Sungrow)** y **SMA Sunny Portal** (siguiente entrega).
- **Fisfiber** y **Abadimex** tienen PV y BESS: aparecen en los dos apartados (marcados con 🔋 en el PV).
- Detecta y avisa (voz + bitácora): planta sin comunicación y desde cuándo, alarma y desde cuándo (con el texto), e inversores fuera (parcial).
- Historial propio en data/pv/ (62 días).

## v16 · Instalar como app y entrar sin pantalla negra

- El monitor ahora contesta en **http://localhost:3000** (sin aviso de certificado) y también en https://localhost:3000 como antes.
  Usa la de **http**: Chrome deja instalarla como app (ícono ⊕ en la barra de direcciones) y la conexión en vivo no se queda en negro.
- La primera vez en http te pedirá iniciar sesión de nuevo (es una sesión aparte de la de https).
- **FusionSolar (Huawei)**: instala el script **Skysense - FusionSolar Relay** en Tampermonkey y deja abierta una pestaña de
  FusionSolar con tu sesión iniciada (cualquier página). No pide contraseñas ni IP: lee lo mismo que ve la página.
  · cada 20 s revisa el estado de comunicación de todas las plantas (conectada / desconectada / falla)
  · cada ~1.5 min el flujo de energía de cada planta (FV, carga, red, batería, SOC) tal cual lo muestra FusionSolar
  · avisa por voz y en la bitácora cuando una planta se desconecta, cuando un equipo (batería, inversor…) pierde comunicación
    y cuando la pestaña / sesión de FusionSolar deja de mandar. Historial en data/fusion/.
  · aparece en el Supervisor como la sección "☀️ FusionSolar (Huawei)", con la barra de comunicación del día.
  · la sesión se mantiene viva sola (el Relay la refresca cada 2 min). Si FusionSolar la cierra de todos modos, el Relay recarga la
    pestaña y el script **Skysense - FusionSolar Auto Login** vuelve a entrar con el usuario que guardes en su menú de Tampermonkey
    (🔑 Guardar usuario de FusionSolar). Si FusionSolar pide código de verificación, no lo intenta y te avisa.

- **Kehua (PCS y modulos)**: instala **Skysense - Kehua Auto Login**. Entra solo al Local Controller del PCS (puerto 7100)
  y a los modulos Kehua con Horcore / BYD (7101..7109, 7201, 7202). Las contrasenas NO van en el codigo: se guardan una vez
  desde el menu de Tampermonkey (icono -> "Kehua: usuario y clave del Local Controller" y "...de los modulos"), solo en esa PC.
  En los modulos puedes poner varias claves separadas por coma (p.ej. "222,111"); prueba cada una y recuerda cual sirvio en cada sitio.
  Para un sitio con clave distinta: menu -> "Kehua: clave especial para ESTE sitio".

- Relay 3.1: funciona dentro de Skysense OPS ("Solo Pantallas" / "Ver en vivo"), que abre las pantallas por su proxy https://localhost:9001…9041.

## Instalación (v4)
1. **Cierra** el BESS Monitor.
2. **Copia estos archivos** a la carpeta del monitor, respetando las carpetas y reemplazando los anteriores:
   - `server.js`
   - `lib/supervisor.js`
   - `lib/jmobile.js`
   - `lib/historian.js` → **nuevo** (histórico por minuto)
   - `public/historico.html` → **nuevo** (dashboard + Excel/PDF)
   - `public/supervisor.html`
   - `public/supervisor-link.js`
   - `config/supervisor-sitios.json` → datos de cada sitio traídos de Centro BESS
   - `config/supervisor-credenciales.json` → usuario/contraseña de cada pantalla (del monkey)
   - `tampermonkey/Skysense BESS - Supervisor Relay.user.js` → **actualízalo en Tampermonkey (v1.1)**: ahora pone un letrerito verde "📡 Supervisor: enviando…" abajo a la derecha de cada pestaña, para que veas que sí está mandando
3. **Enciende** el monitor (`iniciar.bat`) y abre **Supervisor en vivo**.

## 🆕 v11 — Análisis de curvas y "no perder datos"
- **Análisis de curvas** (Histórico), una sola sección con tema oscuro, potencia y SOC sincronizados:
  - **Zoom:** arrastrar sobre la gráfica = **zoom de un área** (tiempo y kW). Botón "✋ Mover" para desplazarte; rueda = zoom en el tiempo; Shift + rueda = zoom en kW; doble clic = ver todo.
  - **Eje kW ajustado a lo visible:** al acercarte la curva ya no se aplasta. Con 6 h o menos se usan datos cada 5 s y se marcan las muestras.
  - **Cursor en cruz:** lectura de hora (con segundos) y de kW.
  - **Panel de Señales:** valor en el cursor, mín/máx (con hora) y promedio del horario visible; clic para mostrar u ocultar cada señal.
  - **⛶ Expandir:** pantalla completa (Esc para salir). Botón para tema claro u oscuro.
- **Relay v2.2:** si la pantalla cierra la sesión o deja de contestar, la pestaña se **recarga sola** (como F5) para que el Auto Login vuelva a entrar. Máximo una recarga cada 90 s.
- **Respaldo directo** (`"respaldoDirecto": true`, `"respaldoSeg": 45`): si la pestaña de un sitio que sí mandaba datos se calla más de 45 s, el Supervisor lee con su propia sesión mientras tanto, y la cierra en cuanto la pestaña vuelve. Los sitios que nunca han tenido pestaña no se tocan.
- **Recomendación en Chrome:** en Configuración → Rendimiento, desactiva el "Ahorro de memoria" (o agrega las IP 100.96.* como sitios que siempre deben estar activos) para que Chrome no congele las pestañas.

## 🆕 v10.1 — Relay v2.0 y página de estado
- **Relay v2.0:**
  - Pide las etiquetas en grupos de 20, para no hacer peticiones demasiado largas.
  - Si la pantalla rechaza alguna, la descarta sola y sigue mandando las demás. Antes una sola etiqueta rara hacía que no se mandara nada.
- **http://127.0.0.1:3001/estado:** abre esa dirección en Chrome para ver qué pestañas están mandando datos, a qué sitio corresponden y hace cuánto.

## 🆕 v10 — Solo pestañas: el Supervisor NO usa logins de las pantallas
- **Las pantallas tienen solo 4 accesos.** Por eso el Supervisor ya **no inicia sesión** en ninguna pantalla: todos los datos llegan de las pestañas de Chrome que tú tienes abiertas, con el script Relay, usando **la misma sesión de la pestaña** (un único login por pantalla).
- **Al encender el monitor** se cierran las sesiones que versiones anteriores hubieran dejado abiertas, para liberar esos accesos.
- **Sitio sin pestaña abierta:** la tarjeta dice "🌐 Esperando la pestaña de Chrome" y trae el botón "Abrir pantalla ↗". Si la pestaña deja de mandar, dice desde hace cuánto.
- **Relay v1.9:**
  - El letrero de la esquina explica qué pasa: "enviando N datos", "no tiene sesión", "la pantalla respondió…" o "no encuentro el BESS Monitor".
  - Si la pantalla rechaza alguna etiqueta, se corrige solo.
- **Lectura directa (opcional):** se puede volver a activar con `"lecturaDirecta": true` en `config/supervisor.json` (no recomendado con 4 accesos).

## 🆕 v9 — Fluidez, demandas contratadas y logo
- **Cada sitio se lee con su propio ciclo** (≈1 s). Antes se esperaba a que terminara la vuelta de todos, y una pantalla lenta o caída dejaba todo "pasmado" 5–20 s. El tiempo máximo de espera por pantalla bajó a 6 s.
- **Pantalla del Supervisor:** solo redibuja las tarjetas que cambian, no toda la cuadrícula; se siente mucho más fluida.
- **Demandas contratadas** corregidas con el Catálogo de sitios de Centro BESS. Chihuahua 540, Minatitlán 1750, Tugal 2664 y Vallarta 1000 estaban mal; DESA, Atotonilco, Bidasoa y Vitrogenera no tienen en el catálogo.
- **Logo oficial de Skysense** (sky en negritas + sense) en el Supervisor, el Histórico, los PDF y el recibo.
- **Sitios con varios BESS** (T4, T2, DESA…): la gráfica de potencia muestra una línea por BESS (mismo color que en la de SOC) y el total punteado.

## 🆕 v8 — Cada sitio por separado
- **VITROGENERA:** la red se lee de `ASC_4/Mains_Power` (kW), `Mains_Reactive_Power` (kVAr) y `Mains_Pf`, y el consumo de `P_Consumo`, tal cual los marca la pantalla.
- **TOTIS / VITROGENERA con `"talCual": true`:** red y consumo se muestran tal cual los marca el HMI, sin cálculos ni alarma de "balance no cuadra". En TOTIS el medidor está mal relacionado en el HMI; lo importante ahí es que el BESS descargue bien.
- **"Congelado" por separado:** si se congela solo el consumo (o solo la red), esa fila marca **❄ CONGELADO** y la alerta dice cuál y desde hace cuántos minutos. La otra medición se sigue viendo normal.
- **Página General completa:** el lector ahora trae todas las mediciones de esa página. Las que no reconoce aparecen en la tarjeta como "sin asignar" para asignarlas en ⚙️ Configurar → Por sitio.
- **Relay v1.7.**

## 🆕 v7 — Correcciones de lectura y datos cada 5 segundos
- **Proyectos con espacios en el nombre** (ej. VESTA: "VESTAS PARK_11_Abril_2026"): la lectura directa y el Relay ya los encuentran.
- **Etiquetas sin medidor conectado:** algunas pantallas tienen etiquetas de red que siempre marcan 0 (no hay medidor). Si una etiqueta **nunca** ha marcado otro valor, ya no se toma como "perdió la medición de red"; se calcula Consumo − BESS y se marca "(calc.)". Si alguna vez midió y luego cae a 0, sí alarma.
- **TOTIS:** `Battery_01/P_Mains` = red.
- **Parámetros de configuración:** SOC_Max/Min/SET, despacho, lógica y relojes se ignoran. Antes podían confundirse con el SOC.
- **Atotonilco = sitio de EXPORTACIÓN** (`"exportacion": true`):
  - Solo hay red; el PV y el BESS inyectan, y se muestra "INYECTA ↑" en lugar de alarma.
  - No hay consumo del cliente.
  - Ventana de descarga 19:00–21:00.
- **Registro cada 5 segundos:**
  - Se guarda en `data/historico-5s/` (≈1 MB por sitio al día, 31 días; se cambia con `HISTORICO_5S_DIAS`).
  - Con zoom de 6 h o menos, la gráfica usa esos datos.
  - El pico instantáneo sale con hora:minuto:segundo.
- **Pico de red en hora punta:**
  - Se enmarca en naranja justo en el punto, con su valor y hora exacta arriba (no tapa la gráfica), y una franja con el intervalo de 15 min más alto.
  - La hora punta ahora es rojo tenue (ya no morado).
- **Relay v1.6.**

## 🆕 v6 — Recibo estimado, Regio Pet dividido y más lecturas
- **Recibo CFE estimado** en el Histórico, con logo de Skysense:
  - Calcula el recibo **con BESS** y **sin BESS**, y el **ahorro** concepto por concepto (fórmula GDMTH).
  - Se imprime o guarda en PDF por separado.
  - Los precios se editan en "Precios del mes" (generales o por sitio) y se guardan en `config/tarifas-cfe.json`. Los que trae son de referencia: cópialos de un recibo real.
- **Regio Pet dividido en RegioPet 1, 2 y 3:**
  - Es la misma pantalla y la misma IP, pero cada una tiene su acometida, su consumo, su BESS, su demanda contratada (900 / 470 / 500 kW) y su histórico.
  - Se configura con `"split"` en `config/supervisor-sitios.json`.
- **SOC en décimas:** se corrige solo (386 → 38.6 %).
- **Plastiexports:** se leen `RED_P` / `RED_Q` y se aceptan los nombres "PLASTI EXPORTS 1" y "PLASTI EXPORTS 3".
- **Atotonilco:** se leen `P` / `Q` con su signo (`P_Sign`) y el medidor **SEL-735**. La lectura ahora sigue las ligas a otras páginas de la pantalla (hasta 18).
- **Navegador de la gráfica:** más alto y con asas.
  - Arrastrar el recuadro = moverte.
  - Arrastrar un asa = hacerlo más grande o más chico.
  - Clic fuera = centrar ahí; arrastrar fuera = elegir otro horario.
  - Doble clic = ver todo.
- **Relay v1.5** (actualizarlo en Tampermonkey).

## 🆕 v5 — Histórico profesional, horarios CFE y alarmas de descarga
**Histórico (📊):**
- **Gráfica de potencia interactiva:**
  - **Zoom y desplazamiento:** rueda del mouse para acercar o alejar; arrastrar para moverte; Shift + arrastrar para elegir un horario; doble clic para ver todo. Abajo tiene un navegador con recuadro azul.
  - **Cursor:** al pasar el cursor marca la hora exacta, el periodo CFE, si hay ventana de descarga, el valor de cada serie, la demanda de 15 min de ese intervalo y cada BESS.
  - **Leyendas:** con clic prendes o apagas cada serie, los periodos CFE, la ventana de descarga y los picos.
  - **Botones rápidos:** Punta de hoy, Últimas 24 h y 3 h.
  - **Estadísticas del horario visible:** kWh de consumo, red y BESS, máxima demanda de 15 min e intervalo, y pico instantáneo con su minuto.
- **Periodos Base / Intermedia / Punta (CFE GDMTH/DIST):**
  - Se sombrean en la gráfica.
  - Tabla por periodo con kWh, demanda máxima de 15 min (día e intervalo) y pico instantáneo (día y minuto).
  - Usan la hora local de cada sitio: Cancún y Cozumel van +1 h. Toma en cuenta sábados, domingos, festivos y el horario de verano o invierno de CFE.
  - Las tablas están en `public/cfe.js`.
- **Picos de demanda en punta, día por día:** intervalo de 15 min (como el medidor) y minuto exacto del pico instantáneo, para corroborar con el video del medidor.
- **Más datos:**
  - Barra "Mes a la fecha".
  - Consumo por día y periodo.
  - Energía del BESS por día.
  - Demanda en punta por día.
  - Mapa de calor con la punta marcada.
- **En vivo:** se actualiza cada 5 s cuando el rango incluye hoy.
- **Excel:** incluye además las hojas "Picos punta" y "Periodos CFE".

**Ventanas de descarga (de Centro BESS):**
- **Hora de entrada:** la de `CEREBRO_HORARIO_VERANO`, en hora CDMX y ya con el desfase del medidor.
- **Cómo se calcula cada día:** la punta de CFE de ese día más el desfase del medidor. Termina 4 min después (entrada +2 h 04 en verano, como T4 18:58–21:02). En invierno se ajusta sola.
- **Sin punta:** fines de semana y festivos no hay ventana, así que no hay alarma.

**Alarmas nuevas:**
- **"No ha iniciado la descarga de hora punta":** se da 3 min de gracia desde el inicio de la ventana.
- **"Se detuvo en plena hora punta, algo pasó":** si ya había descargado y paró.
- **En punta,** la red en 0 o negativa (inyección por descarga fija) ya no alarma.
- **Fuera de punta,** consumo en 0 da aviso.

**Microred (Bidasoa):**
- Sin acometida: se muestran consumo, cada generador o turbina (en línea o fuera), PV y BESS.
- **Si un generador sale de línea:** avisa por voz y, 1 min después, dice cuánto tomaron el BESS, el PV y los demás generadores. Si nadie tomó la carga, lanza alarma roja.

**Lectura:**
- **Plantillas nuevas:** Park Royal y Atotonilco (`P_Consumo`, `BMS_01/System_SOC`, `Battery/P_Storage`) y microred.
- **Etiquetas en varias pantallas:** busca en más páginas de la pantalla hasta encontrar consumo y SOC.
- **Tarjetas:** si falta la etiqueta de consumo, la tarjeta lista las que lee sin asignar.
- **Alias en `config/supervisor-sitios.json`:** puedes renombrar sitios (ej. "PARK ROYAL VALLARTA") sin perder sus datos.

**Velocidad:**
- **Relay (v1.4):** manda cada 1 s.
- **Lectura directa:** vueltas de ~1.5 s con 12 sitios a la vez.

**Tarjetas del Supervisor:** rediseñadas (ya no se enciman las gráficas) y con indicador de periodo CFE (PUNTA / INTERM. / BASE).

## 🆕 v4.2 — Más plantillas de pantalla
- **Microred (ej. Bidasoa):**
  - `Total_Active_Power` = consumo total.
  - `Solar/…` = solar.
  - `MG_xx` / `TG_xx` = generadores o transformadores (se muestran en la línea "OTRAS").
  - Red = Consumo − BESS − Solar, marcada "(calc.)".
  - Si algún `TG` es la acometida de CFE, asígnalo como **Red · kW** en ⚙️ Configurar → Por sitio. Si asignas varios, se suman.
- **Búsqueda más amplia:** el Relay (v1.3) y la lectura directa ahora buscan también etiquetas tipo `Active_Power`, `Potencia`, `Demanda`, `Load`, `Mains`, `CFE`, `Medidor` y `Solar`. La lista guardada de cada sitio se vuelve a descubrir sola.
- **Si un sitio lee etiquetas pero ninguna es red, consumo o BESS,** la tarjeta dice cuáles leyó. Con esos nombres se asignan en ⚙️ Configurar.

## 🆕 v4.1 — Pantallas con firmware nuevo (TUK, Tugal… inversores KEHUA + BSMU)
- **Qué les pasa:** estas pantallas piden en cada lectura un token de seguridad (**CSRF**) que solo tiene la página abierta en Chrome. Con usuario y contraseña correctos la pantalla acepta la sesión, pero no entrega datos. Por eso no aparecían, aunque tuvieran contraseña.
- **Solución:** el **script Relay v1.2** manda ese token. Con la pestaña del sitio abierta en Chrome, los datos llegan al Supervisor (en la tarjeta: "🌐 pestaña"). **Hay que actualizar el Relay en Tampermonkey.**
- **Etiquetas de esta plantilla, ya reconocidas:**

  | Etiqueta | Qué es |
  |---|---|
  | `P_Total_Consumo` | Consumo |
  | `BATTERY_0N/P_Storage` + `_Sign` | kW de cada BESS; el signo viene aparte |
  | `MCC/BSMU_N_System_available_SOC` | SOC |

- **La red no existe como etiqueta en estas pantallas.** Se calcula como **Red = Consumo − BESS** y en la tarjeta aparece "(calc.)".
- **Si en algún sitio la carga y la descarga salen al revés,** cámbialo en ⚙️ Configurar → Por sitio → Signo BESS.

## 📊 Histórico 24/7, dashboard y exportación (v4)
- **Graba solo, todo el tiempo.** En cuanto enciendes el monitor, el Supervisor lee los sitios aunque nadie tenga la pantalla abierta. Guarda **un registro por minuto y por sitio** en `data/historico/AAAA-MM-DD/<sitio>.ndjson` (≈150 KB por sitio al día). Se conservan 400 días.
- **Qué guarda:** red (kW prom/mín/máx, kVAr, FP), consumo (kW prom/mín/máx) y, por cada BESS, kW (+ descarga / − carga) y SOC. También las alertas de la bitácora.
- **Si se cae la comunicación** (VPN, pantalla, monitor apagado): esos minutos quedan como **hueco**. Se detecta y aparece en rojo claro en las gráficas y en la tabla "Cortes de datos" con hora de inicio, fin y duración. En cuanto regresa la señal, sigue grabando solo.
- **Para abrirlo:** botón **📊 Histórico** arriba en el Supervisor, o el link **"📊 Histórico y exportar"** de cada tarjeta.
- **Qué hay en la página:**
  - Sitio y periodo a elegir: Hoy, Ayer, 7 días, Este mes, Mes anterior, un mes cualquiera o rango libre.
  - Indicadores: energía descargada y cargada del BESS, consumo, energía de red, % del consumo cubierto por el BESS, demanda máx. de 15 min (como CFE) vs contratada, pico, SOC mín/máx y tiempo sin datos.
  - Gráficas: potencia (red, consumo y BESS, con el horario de descarga sombreado), SOC por batería, energía por día, demanda 15 min por día, SOC por día y mapa de calor hora × día.
- **Exportar:**
  - **Excel:** hojas Resumen, Diario, Datos (cada 1/5/15/60 min), Cortes de datos y Alertas. Se genera en la PC, no necesita internet.
  - **PDF:** reporte de varias hojas A4 horizontal. En la ventana que abre elige **"Guardar como PDF"**.
  - **CSV:** los datos crudos.
- **Todos los sitios:** en el selector de sitio elige "Todos los sitios (comparativo)" para ver el comparativo, que también se puede exportar.
- **Para apagar el modo 24/7** (y leer solo con la pantalla abierta): pon `"siempreActivo": false` en `config/supervisor.json`.

## ⚠️ Límite de usuarios de las pantallas y el script Relay (v3.3)
Las pantallas JMobile aceptan **pocos usuarios conectados a la vez**. Si el Supervisor abre su propia sesión y la pantalla ya está llena, sale el aviso "la pantalla ya tiene el máximo de usuarios conectados". Peor aún: si el Supervisor ocupa el lugar, la pestaña del monkey se puede quedar en el login.

Para no pelear por esos lugares, la v3.3 trabaja así:
1. **Script Relay (recomendado).** Instala en Tampermonkey `tampermonkey/Skysense BESS - Supervisor Relay.user.js`, junto a tu Auto Login.
   - **Qué hace:** cada pestaña que ya tengas abierta de una pantalla manda sus lecturas al Supervisor cada 5 s, **con la misma sesión de la pestaña**. No ocupa lugares extra y sigue funcionando aunque la pestaña esté en segundo plano.
   - **Adónde manda:** al receptor local `http://127.0.0.1:3001/ingest`, que solo acepta conexiones de esta PC.
   - **En la tarjeta** se ve "🌐 pestaña".
2. **Lectura directa, solo para los sitios SIN pestaña abierta.** El Supervisor entra con su propia sesión y en la tarjeta se ve "⚡ directo".
   - **Si la pantalla está llena,** no insiste durante 10 min, para no quitarle el lugar a nadie.
   - **Si una pestaña empieza a mandar datos de ese sitio,** el Supervisor cierra su sesión solo.
3. **Al apagar el monitor,** con Ctrl+C o cerrando la ventana negra, se cierran sus sesiones.
4. **Novedad v4:** la sesión de cada pantalla se guarda en `data/jmobile-sesiones.json` y **se reutiliza al reiniciar**. Antes, cada reinicio dejaba una sesión huérfana ocupando un lugar. También se corrigió que la pantalla LG (https) abría una sesión nueva en cada vuelta.
5. **Si una tarjeta dice "máximo de usuarios",** esos lugares los ocupan otras sesiones (pestañas, otras PCs o sesiones viejas que la pantalla aún no expira). La tarjeta trae el botón **"Abrir pantalla ↗"**: ábrela en Chrome con el Relay instalado y sus datos entran por la pestaña.

## Usuario y contraseña de las pantallas (ya configurado)
`config/supervisor-credenciales.json` trae el usuario y la contraseña de **las 48 pantallas del script Auto Login (monkey)**, por IP:puerto (ej. LG `Admin`, RESIDEO con su contraseña propia; el resto `admin`). No hay que capturar nada.
- **Para agregar o cambiar una:** edita ese archivo (se recarga solo), o en ⚙️ Configurar → Por sitio → Usuario/Contraseña SCADA (se guarda en ese mismo archivo).
- **Si un sitio no aparece en el archivo:** se usa el usuario general de ⚙️ Configurar y, si no hay, `admin` / `2002`.

## Cómo lee los datos (sin calibrar nada)
- **Qué son las pantallas:** las pantallas de los sitios (`http://IP:7000`) son servidores web **JMobile (Exor)**, y tienen una API que entrega el valor de cada etiqueta.
- **Cómo las lee:** el Supervisor entra con el **mismo usuario y contraseña del SCADA** que ya tiene guardados el monitor (`config/scada-auth.json`). Luego busca solo las etiquetas de la pantalla General y las lee directo, en ≈1 s por sitio, sin OCR ni capturas.
- **Etiquetas que usa** (plantilla ASUR/Skysense):

  | Etiqueta | Es |
  |---|---|
  | `MAINS/PMAINS_1` | Red kW |
  | `MAINS/QMAINS` | Red kVAr |
  | `MAINS/Cos-phi_Mains PF` | FP de red |
  | `CARGA` | Consumo kW |
  | `BATTERY/PGEN_1`, `BATTERY2/PGEN_1`… | kW de cada BESS |
  | `State of Charge`, `BATTERY2/State of Charge`… | SOC de cada BESS |

- **Etiquetas encontradas:** se guardan en `data/jmobile-tags.json`. Si cambian la pantalla de un sitio, usa ⚙️ → "Volver a buscar las etiquetas".
- **Sitios sin comunicación:** si un sitio está sin comunicación (ping), no se espera a que conteste; se marca en rojo de inmediato.
- **Si la lectura directa falla:** el Supervisor usa el OCR, si ese sitio lo tiene calibrado.
- **Ajustes opcionales** en `iniciar.bat`:
  - `set SUPERVISOR_CONCURRENCY=6` → sitios leídos a la vez.
  - `set SUPERVISOR_CYCLE_MS=5000` → pausa entre vueltas.

## Datos de Centro BESS (`config/supervisor-sitios.json`)
Por cada sitio del monitor trae: **demanda contratada** (Medidores CFE), **horario de descarga** (Cerebro BESS: hora de entrada de verano, de +5 min a +1 h 50), **potencia esperada de cada BESS** y **racks** (Lista Maestra). Lo que cambies en ⚙️ tiene prioridad sobre este archivo.

## Qué detecta
| Alerta | Nivel |
|---|---|
| Sin comunicación (del propio monitor) | 🔴 |
| Red en 0 o sin lectura con consumo activo → "perdió la medición de red" (no se marca si el BESS cubre el consumo) | 🔴 |
| Consumo en 0 con red activa → falla de medición | 🔴 |
| Demanda contratada excedida | 🔴 |
| BESS no descarga en su horario · SOC ≤ 10% · sistema alarmado | 🔴 |
| BESS descargando a menos del 50% de su potencia esperada | 🟡 |
| Red ≥ 90% del contrato · acometida negativa · FP bajo · SOC ≤ 20% | 🟡 |
| Balance que no cuadra (consumo ≠ red + BESS) · lectura congelada · datos atrasados | 🟡 |

- **Parpadeos:** cada problema debe durar 20 s para alertar, y 30 s en normal para cerrarse, así un parpadeo no dispara la voz.
- **Recordatorios:** las críticas se repiten por voz cada 5 min hasta que alguien pulsa **Enterado**.
- **Sitios en mantenimiento:** no hablan.
- **Controles de la pantalla:** silenciar 15 min / 1 h / 4 h, Modo noche (solo críticas), Modo TV (pantalla completa). La pantalla no se apaga mientras esté abierta.
- **Bitácora:** las alertas se guardan en `data/supervisor-events.json`.
