/* ══════════════════════════════════════════════════════════════════════
   ACTUALIZAR COORDENADAS DE SITIOS — BESS Monitor
   ══════════════════════════════════════════════════════════════════════

   ¿Qué hace esto?
   Lee tu propio config/sites.json, busca cada sitio por nombre, y le pone
   las coordenadas (lat/lng) correctas que me diste en el Word. Hace un
   respaldo del archivo original antes de tocar nada (sites.json.backup).

   ── Cómo correrlo ──
   1) Copia este archivo (actualizar-coordenadas.js) a la carpeta raíz de tu
      BESS Monitor (donde está server.js, junto a la carpeta config/).
   2) Cierra el BESS Monitor un momento (para que no esté escribiendo el
      archivo al mismo tiempo que este script).
   3) En una terminal, en esa misma carpeta:

        node actualizar-coordenadas.js

   4) Vuelve a prender tu BESS Monitor como siempre.

   Al correrlo vas a ver una lista de cuántos sitios se actualizaron, y si
   algún nombre no hizo match (por si tu monitor usa un nombre distinto al
   que yo supuse) — mándame esa lista si sale algo ahí y lo ajusto.
   ══════════════════════════════════════════════════════════════════════ */

const fs = require('fs');
const path = require('path');

const CONFIG_PATH = path.join(__dirname, 'config', 'sites.json');

/* Coordenadas reales, tal como vienen en el Word que me diste */
const COORDS = {
  'almacen':            [21.042650746729763, -86.87453229041462],
  'alpha':              [21.0411771557268,   -86.87187306055378],
  'alysa':              [19.823887665059495, -98.97156376058508],
  'bhs':                [21.042048367637218, -86.87440537941367],
  'bocar':              [19.30481171703749,  -99.20289349128291],
  'brom':               [19.42790008700787,  -99.20356470477303],
  'cbe':                [21.12365462401019,  -86.75418707899047],
  'chihuahua':          [28.704159983649564, -105.96892484709414],
  'comedor':            [21.042530586286063, -86.87470395178482],
  'cozumel':            [20.480882687629663, -86.97142628940406],
  'diseko':             [22.035147637597678, -102.27440260285528],
  'durango':            [24.1270544559737,   -104.53414921815273],
  'fbo':                [21.042650746729763, -86.87436062904438],
  'fisfiber':           [19.471899189998652, -99.21729638038715],
  'fm boca del rio':    [19.141432503055096, -96.10425506245122],
  'huatulco 1':         [15.773134013593461, -96.25917862959409],
  'huatulco 2':         [15.773134013593461, -96.25917862959409],
  'ipasa':              [22.006401149930827, -102.35963385833989],
  'lg':                 [25.77289383893403,  -100.16098130459038],
  'luna':               [21.123669033012234, -86.75419728617656],
  'minatitlan':         [18.102465186724036, -94.57729408822206],
  'plastiexports 1':    [25.76512346174784,  -100.20635233527577],
  'plastiexport 3':     [25.76512346174784,  -100.20635233527577],
  'ptar':               [21.042264010460254, -86.8744203787157],
  'regio pet':          [25.696040640339824, -100.51200626024308],
  'resideo':            [28.712556491224458, -106.13256689099386],
  'sol':                [21.111680773732544, -86.76074669185412],
  't&t':                [19.466992921420317, -99.24291522011463],
  't2':                 [21.042360570740037, -86.87460384735489],
  't4':                 [21.042074045683194, -86.87438611394245],
  'thor':               [22.11860191541467,  -101.00613552004512],
  'torreon':            [25.56310727047606,  -103.39875413343297],
  'totis':              [19.826459624575797, -98.97470684709192],
  'tuk':                [25.751159403442937, -100.22399785396485],
  'vallarta':           [20.54813132723537,  -105.2732665200875],
  'vesta':              [25.67430085166243,  -100.20015984097994],
  'veracruz':           [19.144892465686965, -96.18643199128678],
  'vitrogenera':        [19.461040724767475, -99.16392676244345],
  'zacatecas':          [22.900881611131695, -102.67923784700874],
  'zihuatanejo':        [17.60628007233955,  -101.4636790183081]
};

/* Alias: nombre real del sitio en tu monitor (normalizado) → clave del Word.
   Cubre mayúsculas/acentos distintos y los sitios que se dividen en varias
   unidades (B1/B2/etc.) que comparten la misma coordenada física. */
const ALIASES = {
  'almacen general': 'almacen',
  'park royal cbe': 'cbe',
  'park royal cozumel': 'cozumel',
  'park royal luna': 'luna',
  'park royal sol': 'sol',
  'hux 01': 'huatulco 1',
  'hux 02': 'huatulco 2',
  'ipasa 1': 'ipasa', 'ipasa 2': 'ipasa', 'ipasa 3': 'ipasa', 'ipasa 4': 'ipasa',
  'regiopet 1': 'regio pet', 'regiopet 2': 'regio pet', 'regiopet 3': 'regio pet',
  'plastiexports 1 b1': 'plastiexports 1', 'plastiexports 1 b2': 'plastiexports 1',
  'plastiexports 3 b1': 'plastiexport 3', 'plastiexports 3 b2': 'plastiexport 3',
  't2 b1': 't2', 't2 b2': 't2',
  't4 b1': 't4', 't4 b2': 't4', 't4 b3': 't4',
  'thor b1': 'thor', 'thor b2': 'thor',
  'tuk b1': 'tuk', 'tuk b2': 'tuk',
  'tejidos y texturizados': 't&t',
  'plasti 1': 'plastiexports 1',
  'plasti 3': 'plastiexport 3',
  'fm boca del rio': 'fm boca del rio',
  'minatitlan': 'minatitlan',
  'torreon': 'torreon',
  'puerto vallarta': 'vallarta'
};

function normalize(s) {
  return String(s || '')
    .toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '') // quitar acentos
    .trim();
}

if (!fs.existsSync(CONFIG_PATH)) {
  console.error('❌ No encontré config/sites.json en esta carpeta. ¿Corriste el script desde la carpeta raíz del BESS Monitor?');
  process.exit(1);
}

const raw = fs.readFileSync(CONFIG_PATH, 'utf-8');
const data = JSON.parse(raw);
const sites = Array.isArray(data) ? data : (data.sites || []);

if (!sites.length) {
  console.error('❌ No encontré una lista de sitios dentro de config/sites.json. Revisa el formato del archivo.');
  process.exit(1);
}

// Respaldo antes de tocar nada
const backupPath = CONFIG_PATH + '.backup-' + Date.now();
fs.writeFileSync(backupPath, raw, 'utf-8');
console.log('📦 Respaldo guardado en: ' + backupPath);

let updated = 0;
const notFound = [];

sites.forEach((site) => {
  const key = normalize(site.name);
  const docxKey = ALIASES[key] || key;
  const coords = COORDS[docxKey];
  if (coords) {
    site.lat = coords[0];
    site.lng = coords[1];
    site.exactLocation = true;
    updated++;
  } else {
    notFound.push(site.name);
  }
});

fs.writeFileSync(CONFIG_PATH, JSON.stringify(data, null, 2), 'utf-8');

console.log(`✅ ${updated} sitio(s) actualizados con coordenadas nuevas.`);
if (notFound.length) {
  console.log(`⚠️  ${notFound.length} sitio(s) sin coordenada nueva (se dejaron como estaban) — mándame esta lista si crees que alguno debería haber hecho match:`);
  notFound.forEach((n) => console.log('   - ' + n));
}
