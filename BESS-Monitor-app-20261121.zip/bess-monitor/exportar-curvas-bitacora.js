/* ============================================================================
   Exportar curvas de Bitácora (Centro BESS) → carpeta de OneDrive, por sitio.
   ----------------------------------------------------------------------------
   Lee la colección "bitacoras" de Firebase (proyecto bitacora-descarga, la MISMA
   que usa la app) y guarda cada curva (descarga/carga) como .jpg en:

     <CARPETA>/Bitacora de descarga/<Sitio>/<archivo>.jpg
     <CARPETA>/Bitacora de carga/<Sitio>/<archivo>.jpg

   - No toca la app. No borra nada. Solo AGREGA lo que falte.
   - Idempotente: lleva un registro (.curvas-exportadas.json) de lo ya bajado,
     así que puede correr a diario sin duplicar ni volver a descargar todo.
   - Sin dependencias: usa el fetch nativo de Node 18+ (tienes Node 24).

   Uso:   node exportar-curvas-bitacora.js
   Diario: prográmalo con el Programador de tareas de Windows (ver LEEME).
   ========================================================================== */

'use strict';
const fs = require('fs');
const path = require('path');

/* ── CONFIG ──────────────────────────────────────────────────────────────── */
// Carpeta destino (la de OneDrive). Se puede sobreescribir con la variable de
// entorno BITACORA_DIR o pasándola como primer argumento al script.
const CARPETA = process.argv[2] || process.env.BITACORA_DIR ||
  'C:\\Users\\Alejandro Fernandez\\OneDrive - skysense.com.mx\\ASM O&M - O&M 2026\\3- OPERACIÓN\\MONITOREO BESS\\BITÁCORA';

// Config pública de Firebase (la misma que trae la app en GitHub Pages; la
// apiKey web NO es secreta, es la clave pública del cliente).
const PROJECT_ID = 'bitacora-descarga';
const API_KEY    = 'AIzaSyA7pwEgAPXzY8H193YuJCTu7H5cs8N7yFo';
const COLLECTION = 'bitacoras';

const BASE = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/(default)/documents`;
const STATE_FILE = path.join(CARPETA, '.curvas-exportadas.json');

/* ── Utilidades ──────────────────────────────────────────────────────────── */
function log(...a){ console.log('[curvas]', ...a); }
function sanitize(s){
  return String(s == null ? '' : s)
    .replace(/[\/\\:*?"<>|]/g, '-')   // caracteres inválidos en Windows
    .replace(/\s+/g, ' ')
    .trim() || 'Sin sitio';
}
function loadState(){
  try { return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')); }
  catch { return { ids: {} }; }
}
function saveState(st){
  try { fs.mkdirSync(CARPETA, { recursive: true }); fs.writeFileSync(STATE_FILE, JSON.stringify(st, null, 1)); }
  catch(e){ log('No se pudo guardar el estado:', e.message); }
}
function ensureDir(d){ fs.mkdirSync(d, { recursive: true }); }
const MESES = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
// Carpeta por mes, p.ej. "2026-11 Noviembre" (ordena bien y se lee claro)
function mesFolder(dateStr){
  const mm = String(dateStr || '').match(/^(\d{4})-(\d{2})/);
  if (!mm) return 'Sin fecha';
  return mm[1] + '-' + mm[2] + ' ' + (MESES[parseInt(mm[2],10)-1] || '');
}
// Nombre sin colisión dentro de su carpeta: "Alpha_2026-11-09.jpg",
// "Alpha_2026-11-09 (2).jpg", …
function uniquePath(dir, base, ext){
  let p = path.join(dir, base + ext), n = 2;
  while (fs.existsSync(p)) { p = path.join(dir, base + ' (' + n + ')' + ext); n++; }
  return p;
}

async function fetchJson(url){
  const r = await fetch(url);
  if (!r.ok) throw new Error('HTTP ' + r.status + ' ' + (await r.text()).slice(0, 200));
  return r.json();
}

/* Lista TODOS los documentos de la colección, solo con los metadatos ligeros
   (sin la imagen), paginando. */
async function listAllMeta(){
  const out = [];
  let pageToken = '';
  const mask = ['site', 'date', 'tipo', 'savedAt']
    .map(f => 'mask.fieldPaths=' + f).join('&');
  do {
    const url = `${BASE}/${COLLECTION}?key=${API_KEY}&pageSize=300&${mask}` +
      (pageToken ? '&pageToken=' + encodeURIComponent(pageToken) : '');
    const data = await fetchJson(url);
    (data.documents || []).forEach(d => {
      const id = d.name.split('/').pop();
      const f = d.fields || {};
      out.push({
        id,
        site: f.site && f.site.stringValue || '',
        date: f.date && f.date.stringValue || '',
        tipo: f.tipo && f.tipo.stringValue || 'descarga'
      });
    });
    pageToken = data.nextPageToken || '';
  } while (pageToken);
  return out;
}

/* Trae UN documento completo (con la imagen) por id. */
async function fetchDataUrl(id){
  const url = `${BASE}/${COLLECTION}/${id}?key=${API_KEY}&mask.fieldPaths=dataUrl`;
  const d = await fetchJson(url);
  return d.fields && d.fields.dataUrl && d.fields.dataUrl.stringValue || '';
}

/* ── Principal ───────────────────────────────────────────────────────────── */
(async function main(){
  log('Carpeta destino:', CARPETA);
  try { ensureDir(CARPETA); }
  catch(e){ console.error('No se pudo acceder a la carpeta destino:', e.message); process.exit(1); }

  const state = loadState();
  let metas;
  try { metas = await listAllMeta(); }
  catch(e){ console.error('Error leyendo Firebase:', e.message); process.exit(1); }
  log(metas.length, 'curvas en total en la nube.');

  let nuevas = 0, saltadas = 0, fallidas = 0;
  for (const m of metas){
    if (state.ids[m.id]) { saltadas++; continue; }       // ya exportada antes
    if (!m.site || !m.date) { saltadas++; continue; }

    const esCarga = String(m.tipo).toLowerCase() === 'carga';
    const sub = esCarga ? 'Bitacora de carga' : 'Bitacora de descarga';
    /* Organizado POR MES y luego por sitio:
       Bitacora de descarga / 2026-11 Noviembre / <Sitio> / <Sitio>_2026-11-09.jpg  */
    const dir = path.join(CARPETA, sub, mesFolder(m.date), sanitize(m.site));
    const siteU = sanitize(m.site).replace(/\s+/g, '_');
    const base = esCarga ? `${siteU}_CARGA_${m.date}` : `${siteU}_${m.date}`;

    try {
      const dataUrl = await fetchDataUrl(m.id);
      const comma = dataUrl.indexOf(',');
      if (comma < 0) { fallidas++; log('Sin imagen:', m.id); continue; }
      const buf = Buffer.from(dataUrl.slice(comma + 1), 'base64');
      ensureDir(dir);
      const dest = uniquePath(dir, base, '.jpg');
      fs.writeFileSync(dest, buf);
      state.ids[m.id] = path.relative(CARPETA, dest);
      nuevas++;
      if (nuevas % 20 === 0) { saveState(state); log('…', nuevas, 'nuevas guardadas'); }
    } catch(e){
      fallidas++;
      log('Falló', m.site, m.date, '—', e.message);
    }
  }
  saveState(state);
  log(`Listo. Nuevas: ${nuevas} · Ya estaban: ${saltadas} · Fallidas: ${fallidas}`);
})();
