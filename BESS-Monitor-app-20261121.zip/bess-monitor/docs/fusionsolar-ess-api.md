FusionSolar ESS — mapa de API (capturado en vivo, la5, planta Fisfiber Local 18 / ESS1 NE=58040489, station NE=58040482)
========================================================================================================================
Todas GET salvo las POST indicadas. Mismo origen (la5.fusionsolar.huawei.com) → fetch con credentials:include.

ENUMERACIÓN
- mo-details                : /rest/pvms/web/device/v1/mo-details?dn=<ESSDN>         → name, parentDn, stationAncestor, status, meType (…LUNA2000B…)
- esm-list (racks por ESS)  : /rest/dp/pvms/business/v2/container/esm-list?essDn=<ESSDN> → [{esmDn,esmName,esmLocation}]
- online                    : /rest/pvms/web/device/v1/deviceExt/is-device-online?dn=<ESSDN> → {data:true/false}

TIEMPO REAL (poll principal)
- overview por ESS          : /rest/dp/pvms/business/v2/container/overview-realtime-data?essDn=<ESSDN>
    essDeviceStatus; bottomSignals(Estado func 10102, Energía carga/descarga 10018, SOC 10019, SOH 10020, Puerta armario 10009);
    rightSignals(Energía carga diaria 10024, descarga diaria 10025, aux diario 10043, Ciclos equiv 11001,
                 Humedad armario 1/2, Temperatura armario 1/2, Concentración de CO 1);
    esmList[].overviewSignals(SOC 10010, SOH 10006, Temp alta/baja celda, SoC alto/bajo, Tensión alta/baja)
- detalle completo por ESS  : /rest/pvms/web/device/v1/device-realtime-data?deviceDn=<ESSDN>&displayAccessModel=true
    grupos: "Información general" (SOC/SOH/SoE, temps y voltajes por grupo, contactor principal,
            detector de calor/humo, sensor de agua, baliza de alarma),
            "Información de potencia" (V/I/P por fase, FP, frecuencia, resistencia de aislamiento),
            "Información de enfriamiento" (temps agua batería/potencia, temp exterior)
- detalle por rack (ESM)    : /rest/pvms/web/device/v1/device-realtime-data?deviceDn=<ESMDN>
- celdas por rack           : /rest/dp/pvms/business/v2/container/cell-key-data?esmDn=<ESMDN> → [{cellName,status,cellSoc,cellSoh,cellTemperature,cellVoltage}]
- enum de estado (texto)    : /rest/pvms/web/device/v1/deviceExt/get-device-signals?dn=<ESSDN>&signalIds=10102 → enumMap + realValue
- info fija                 : /rest/pvms/web/device/v1/deviceExt/get-device-signals?dn=<ESSDN>&signalIds=50012,50010,10051,10065,10063,230770112,230770071
                              → SN, versión SW, paquete SW, Modelo ESS (LUNA2000-215-2S11), ESS SN, PCS SN, Refrigeración líquida SN

CURVAS / ENERGÍA (POST, body JSON)
- curva carga/descarga 5min : /rest/dp/pvms/business/v2/container/statistic-charge-power
    {essDn,queryTimeDime:"2",xDim:"1",queryStartTime:"YYYYMMDD",queryEndTime:"YYYYMMDD",timeZone:-6,showDst:true} → xAxis[] + chargeDischargePower[]
- energía por día           : /rest/dp/pvms/business/v2/container/statistic-energy
    {essDn,queryTimeDime:"10",xDim:"2",queryStartTime,queryEndTime,timeZone:-6} → xAxis[] + chargePower[] + dischargePower[]

NOTA: los IDs de señal se reusan entre endpoints/dispositivos; el monitor mapea por el campo "name" (etiqueta), no por id.
