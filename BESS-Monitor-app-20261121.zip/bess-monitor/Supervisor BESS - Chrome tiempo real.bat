@echo off
REM ============================================================
REM  Skysense BESS - Chrome en TIEMPO REAL
REM  Abre Chrome sin frenar las pestanas que quedan en segundo
REM  plano, para que las pantallas JMobile sigan refrescando y
REM  el Supervisor reciba datos en vivo sin retrasos.
REM
REM  Usa un perfil DEDICADO (solo para el monitoreo). La primera
REM  vez, dentro de esta ventana de Chrome:
REM    1) Instala Tampermonkey.
REM    2) Instala el script "Skysense BESS - Supervisor Relay".
REM    3) Inicia sesion en las pantallas / abre la app de sitios.
REM  De ahi en adelante, SIEMPRE abre las pantallas con este .bat.
REM ============================================================
setlocal
title Skysense BESS - Monitor en tiempo real

set "CHROME="
for %%P in (
  "%ProgramFiles%\Google\Chrome\Application\chrome.exe"
  "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
  "%LocalAppData%\Google\Chrome\Application\chrome.exe"
) do if exist %%~P set "CHROME=%%~P"

if not defined CHROME (
  echo No encontre Chrome. Instalalo, o edita la ruta arriba en este archivo.
  pause
  exit /b 1
)

set "PERFIL=%LocalAppData%\SkysenseBESS\ChromeMonitor"

start "" "%CHROME%" ^
  --user-data-dir="%PERFIL%" ^
  --disable-background-timer-throttling ^
  --disable-backgrounding-occluded-windows ^
  --disable-renderer-backgrounding ^
  --disable-features=CalculateNativeWinOcclusion,IntensiveWakeUpThrottling ^
  --new-window

exit /b 0
