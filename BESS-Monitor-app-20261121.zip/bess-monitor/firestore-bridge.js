/* ══════════════════════════════════════════════════════════════════════
   PUENTE: BESS Monitor (local) → Centro BESS (Firestore)
   ══════════════════════════════════════════════════════════════════════

   ¿Qué hace esto?
   Corre EN LA MISMA COMPUTADORA donde ya tienes el BESS Monitor prendido.
   Cada cierto tiempo (30 segundos por default) le pregunta a tu propio
   monitor — usando su API que ya existe en localhost:3000 — el estado de
   todos los sitios y la bitácora de eventos, y sube ese resumen a la misma
   base de Firestore que usa Centro BESS. Así Centro BESS puede mostrar el
   estado de comunicación desde cualquier lugar (no solo tu red/VPN local),
   sin que tengamos que abrir tu red hacia afuera ni tocar tu servidor.

   No modifica nada de tu BESS Monitor — solo LEE su API pública documentada
   en el README (sección 10) y escribe en dos colecciones nuevas y separadas
   de Firestore (comm_sites, comm_events), que no chocan con nada que Centro
   BESS ya use.

   ── Instalación ──
   1) Copia este archivo (firestore-bridge.js) a la MISMA carpeta donde está
      tu server.js del BESS Monitor.
   2) Abre una terminal en esa carpeta e instala la única dependencia nueva:

        npm install firebase

   3) Enciende primero tu BESS Monitor como siempre (iniciar.bat / npm start).
   4) En OTRA ventana de terminal (deja la del monitor corriendo), en la
      misma carpeta, corre:

        node firestore-bridge.js

      Vas a ver:
        🌉 Puente BESS Monitor → Centro BESS iniciado
        [Bridge] Sincronizado: 35 sitios, 12 eventos — 14:32:05

   5) Para dejarlo corriendo siempre (igual que el monitor), puedes usar
      pm2 igual que sugiere el README de tu monitor:

        npm i -g pm2
        pm2 start firestore-bridge.js --name centro-bess-bridge

   Si tu BESS Monitor corre en otro puerto o con otra URL, cambia LOCAL_API
   abajo. Si tu /api/sites regresa los campos con otro nombre (por ejemplo
   "state" en vez de "status", o "latency" en vez de "latencyMs"), ajusta el
   bloque "// ← AJUSTA AQUÍ" — está señalado exactamente dónde.

   ── Inicio de sesión ──
   Tu BESS Monitor pide usuario y contraseña para ver la API (igual que
   cuando entras por el navegador). Pon tus datos de acceso abajo en
   BESS_MONITOR_USER / BESS_MONITOR_PASS. Si al correr el script ves un
   error tipo "login no encontrado" o similar, abre el navegador, entra a
   https://localhost:3000, abre las herramientas de desarrollador (F12) →
   pestaña "Network", inicia sesión como siempre, y busca la petición que
   se llama "login" (o parecido) — ahí puedo ver la URL exacta y los
   nombres de los campos que espera, y ajusto LOGIN_PATH/LOGIN_FIELDS.
   ══════════════════════════════════════════════════════════════════════ */

const https = require('https');
const { initializeApp } = require('firebase/app');
const {
  getFirestore, doc, setDoc, collection, serverTimestamp
} = require('firebase/firestore');

/* ── Configuración ── */
const LOCAL_API = 'https://localhost:3000';   // misma URL donde abres tu BESS Monitor
const SYNC_INTERVAL_MS = 30000;               // cada 30 segundos
const EVENTS_LIMIT = 100;                     // cuántos eventos recientes traer cada vez

/* ── Credenciales de tu BESS Monitor (las mismas con las que entras por el navegador) ── */
const BESS_MONITOR_USER = 'admin';
const BESS_MONITOR_PASS = '2002';
const LOGIN_PATH = '/api/login'; // ← si no funciona, revisa Network (F12) al iniciar sesión y ajusta

/* Misma configuración de Firebase que ya usa Centro BESS (proyecto: bitacora-descarga) */
const firebaseConfig = {
  apiKey:            "AIzaSyA7pwEgAPXzY8H193YuJCTu7H5cs8N7yFo",
  authDomain:        "bitacora-descarga.firebaseapp.com",
  projectId:         "bitacora-descarga",
  storageBucket:     "bitacora-descarga.firebasestorage.app",
  messagingSenderId: "999605736584",
  appId:             "1:999605736584:web:b1a8d5deb2530b83d13b3d"
};

const app = initializeApp(firebaseConfig);
const db  = getFirestore(app);

/* El BESS Monitor usa un certificado autofirmado para su propio https local
   (lo explica su README) — esto le dice a Node que confíe en él igual que
   tu navegador cuando le diste "Continuar a localhost". */
const insecureAgent = new https.Agent({ rejectUnauthorized: false });

let sessionCookie = null; // se llena después de iniciar sesión

/* POST genérico (usado para el login) */
function postLocal(path, payload) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(payload);
    const req = https.request(LOCAL_API + path, {
      method: 'POST',
      agent: insecureAgent,
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) }
    }, (res) => {
      let body = '';
      res.on('data', (chunk) => { body += chunk; });
      res.on('end', () => resolve({ status: res.statusCode, body, headers: res.headers }));
    });
    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

async function login() {
  const result = await postLocal(LOGIN_PATH, { username: BESS_MONITOR_USER, password: BESS_MONITOR_PASS });
  const setCookie = result.headers['set-cookie'];
  if (setCookie && setCookie.length) {
    sessionCookie = setCookie.map((c) => c.split(';')[0]).join('; ');
    console.log('[Bridge] Sesión iniciada en BESS Monitor correctamente');
  } else {
    console.warn(`[Bridge] No se recibió cookie de sesión al iniciar sesión (status ${result.status}). Respuesta: ` + result.body.slice(0, 300));
    console.warn('[Bridge] Revisa BESS_MONITOR_USER / BESS_MONITOR_PASS / LOGIN_PATH arriba en el archivo.');
  }
}

function fetchLocal(path) {
  return new Promise((resolve, reject) => {
    const headers = sessionCookie ? { Cookie: sessionCookie } : {};
    const req = https.get(LOCAL_API + path, { agent: insecureAgent, headers }, (res) => {
      let body = '';
      res.on('data', (chunk) => { body += chunk; });
      res.on('end', () => {
        // Diagnóstico: si la respuesta no es lo que esperamos, mostrar el status y
        // los primeros caracteres para saber exactamente qué está devolviendo el
        // servidor (por ejemplo, una página de login en vez del JSON de sitios).
        if (res.statusCode !== 200) {
          console.warn(`[Bridge][debug] ${path} → status ${res.statusCode}. Primeros 300 caracteres:\n` + body.slice(0, 300));
        }
        try {
          const parsed = JSON.parse(body);
          resolve({ status: res.statusCode, data: parsed });
        } catch (e) {
          console.warn(`[Bridge][debug] ${path} no devolvió JSON. Primeros 300 caracteres:\n` + body.slice(0, 300));
          reject(new Error('Respuesta no era JSON válido desde ' + path + ': ' + e.message));
        }
      });
    });
    req.on('error', reject);
    req.setTimeout(10000, () => { req.destroy(new Error('Timeout consultando ' + path)); });
  });
}

function slug(str) {
  return String(str || '')
    .toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') || 'sitio';
}

async function syncSites() {
  var res = await fetchLocal('/api/sites');
  if (res.status === 401) { await login(); res = await fetchLocal('/api/sites'); }
  const raw = res.data;
  const sites = Array.isArray(raw) ? raw : (raw.sites || raw.data || []);
  if (!Array.isArray(raw) && sites.length === 0) {
    console.warn('[Bridge][debug] /api/sites devolvió JSON pero no una lista de sitios. Contenido recibido:', JSON.stringify(raw).slice(0, 300));
  }

  for (const s of sites) {
    await setDoc(doc(db, 'comm_sites', s.id || slug(s.name)), {
      name: s.name || s.id,
      ip: s.ip || '',
      port: s.port ?? null,
      city: s.city || '',
      group: s.group || '',
      address: s.address || '',
      lat: s.lat ?? null,
      lng: s.lng ?? null,
      status: s.status || 'offline',        // 'online' | 'intermittent' | 'offline'
      latencyMs: s.latencyMs ?? null,
      uptimePct: s.uptimePct ?? null,
      lastCheck: s.lastCheck ?? Date.now(),  // ya viene como timestamp en milisegundos
      offlineSince: s.offlineSince ?? null,
      maintenance: s.maintenance || null,    // {note, by, since, until, type} cuando el sitio está marcado a propósito como fuera de servicio
      scada: s.scada || null,                // datos calibrados por OCR (SOC, temperatura, etc.) una vez que los configures en tu monitor
      updatedAt: serverTimestamp()
    }, { merge: true });
  }
  return sites.length;
}

async function syncEvents() {
  var res = await fetchLocal('/api/events?limit=' + EVENTS_LIMIT);
  if (res.status === 401) { await login(); res = await fetchLocal('/api/events?limit=' + EVENTS_LIMIT); }
  const raw = res.data;
  const events = Array.isArray(raw) ? raw : (raw.events || raw.data || []);
  if (!Array.isArray(raw) && events.length === 0) {
    console.warn('[Bridge][debug] /api/events devolvió JSON pero no una lista de eventos. Contenido recibido:', JSON.stringify(raw).slice(0, 300));
  }

  for (const e of events) {
    // El propio evento ya trae un id único (siteId + timestamp) — se usa tal cual,
    // así nunca se duplica aunque se vuelva a sincronizar el mismo periodo.
    await setDoc(doc(db, 'comm_events', e.id), {
      siteId: e.siteId || '',
      siteName: e.siteName || e.siteId || '',
      ip: e.ip || '',
      from: e.from || null,
      to: e.to || 'offline',           // estado resultante: 'online' | 'intermittent' | 'offline'
      ts: e.ts ?? Date.now(),          // timestamp en milisegundos
      message: e.message || '',
      inMaintenance: !!e.inMaintenance,
      syncedAt: serverTimestamp()
    }, { merge: true });
  }
  return events.length;
}

async function syncOnce() {
  try {
    const [nSites, nEvents] = await Promise.all([syncSites(), syncEvents()]);
    const hora = new Date().toLocaleTimeString('es-MX', { hour12: false });
    console.log(`[Bridge] Sincronizado: ${nSites} sitios, ${nEvents} eventos — ${hora}`);
  } catch (err) {
    console.error('[Bridge] Error de sincronización:', err.message);
  }
}

console.log('🌉 Puente BESS Monitor → Centro BESS iniciado');
console.log('   Leyendo de: ' + LOCAL_API);
console.log('   Escribiendo en Firestore, proyecto: ' + firebaseConfig.projectId);
login().then(() => {
  syncOnce();
  setInterval(syncOnce, SYNC_INTERVAL_MS);
});
