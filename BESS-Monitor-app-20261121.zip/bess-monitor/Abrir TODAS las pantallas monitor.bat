@echo off
REM ============================================================
REM  Skysense BESS - ABRIR TODAS LAS PANTALLAS (monitor en vivo)
REM  IMPORTANTE: para que apliquen las banderas que mantienen las
REM  pestanas VIVAS en segundo plano (y el audio silencioso arranque
REM  solo), Chrome debe ARRANCAR DESDE CERO. Si Chrome ya esta abierto,
REM  cierralo primero (o deja que este .bat lo cierre).
REM
REM  Abre las 45 pantallas en TU Chrome (perfil Default, donde ya
REM  tienes Tampermonkey con Auto Login + Relay). Una sola sesion por
REM  pantalla; el servidor lee con esa misma sesion.
REM
REM  Pantallas:
REM    1. ALMACEN  ->  http://100.96.1.146:7000/
REM    2. ALPHA  ->  http://100.96.3.146:7000/
REM    3. ALYSA  ->  http://100.96.4.82:7000/
REM    4. Atotonilco  ->  http://100.96.5.114:7000/
REM    5. BHS  ->  http://100.96.3.18:7000/
REM    6. Bidasoa  ->  http://100.96.3.226:7000/
REM    7. BOCAR  ->  http://100.96.2.210:6000/
REM    8. BROM  ->  http://100.96.3.194:7000/
REM    9. CHIHUAHUA  ->  http://100.96.1.34:7000/
REM   10. Clarimex  ->  http://100.96.5.194:7000/
REM   11. COMEDOR  ->  http://100.96.1.130:7000/
REM   12. DESA  ->  http://100.96.5.130:7000/
REM   13. DISEKO  ->  http://100.96.2.98:7000/
REM   14. DURANGO  ->  http://100.96.1.114:7000/
REM   15. FBO  ->  http://100.96.1.18:7000/
REM   16. FISFIBER  ->  http://100.96.5.82:7000/
REM   17. HUATULCO 1  ->  http://100.96.2.66:7000/
REM   18. HUATULCO 2  ->  http://100.96.2.34:7000/
REM   19. LG  ->  https://100.96.4.210:7010/
REM   20. MINATITLAN  ->  http://100.96.1.242:7000/
REM   21. Park Royal Acapulco  ->  http://100.96.5.210:7000/
REM   22. PARK ROYAL CBE  ->  http://100.96.5.2:7000/
REM   23. PARK ROYAL COZUMEL  ->  http://100.96.4.242:7000/
REM   24. PARK ROYAL LUNA  ->  http://100.96.4.178:7000/
REM   25. PARK ROYAL MAZATLAN  ->  http://100.96.5.226:7000/
REM   26. PARK ROYAL SOL  ->  http://100.96.5.242:7000/
REM   27. Park Royal Vallarta  ->  http://100.96.5.98:7000/
REM   28. PLASTI 1  ->  http://100.96.5.18:7000/
REM   29. PLASTI 3  ->  http://100.96.5.34:7000/
REM   30. PTAR  ->  http://100.96.4.66:7000/
REM   31. REGIO PET  ->  http://100.96.2.246:7000/
REM   32. RESIDEO  ->  http://100.96.4.2:7000/
REM   33. T&T  ->  http://100.96.3.242:7000/
REM   34. T2  ->  http://100.96.1.178:7000/
REM   35. T4  ->  http://100.96.1.226:7000/
REM   36. THOR  ->  http://100.96.4.130:7000/
REM   37. TORREON  ->  http://100.96.2.50:7000/
REM   38. TOTIS  ->  http://100.96.2.2:7000/
REM   39. Tugal  ->  http://100.96.5.162:7000/
REM   40. Tuk  ->  http://100.96.5.66:7000/
REM   41. VERACRUZ  ->  http://100.96.2.146:7000/
REM   42. VESTA  ->  http://100.96.4.18:7000/
REM   43. VITROGENERA  ->  http://100.96.4.146:7000/
REM   44. ZACATECAS  ->  http://100.96.2.162:7000/
REM   45. ZIHUATANEJO  ->  http://100.96.1.210:7000/
REM  (FM BOCA DEL RIO e IPASA son VNC: las lee el modulo VNC, no se abren aqui.)
REM ============================================================
setlocal
title Skysense BESS - Pantallas en vivo (45)

set "CHROME="
for %%P in (
  "%ProgramFiles%\Google\Chrome\Application\chrome.exe"
  "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
  "%LocalAppData%\Google\Chrome\Application\chrome.exe"
) do if exist %%~P set "CHROME=%%~P"

if not defined CHROME (
  echo No encontre Chrome. Instalalo, o edita la ruta arriba en este archivo.
  pause
  exit /b 1
)

REM --- Cerrar Chrome para que arranque DESDE CERO y tome las banderas ---
echo.
echo  Para que las pantallas NO se frenen en segundo plano, Chrome debe
echo  arrancar desde cero. Voy a CERRAR Chrome y volver a abrirlo con las
echo  pantallas. Guarda lo que tengas abierto.
echo.
pause
taskkill /F /IM chrome.exe >nul 2>&1
timeout /t 3 /nobreak >nul

set "PERFIL=%LocalAppData%\Google\Chrome\User Data"

start "" "%CHROME%" ^
  --user-data-dir="%PERFIL%" ^
  --profile-directory="Default" ^
  --autoplay-policy=no-user-gesture-required ^
  --disable-background-timer-throttling ^
  --disable-backgrounding-occluded-windows ^
  --disable-renderer-backgrounding ^
  --disable-features=CalculateNativeWinOcclusion,IntensiveWakeUpThrottling,HighEfficiencyModeAvailable ^
  --new-window ^
  "http://100.96.1.146:7000/" ^
  "http://100.96.3.146:7000/" ^
  "http://100.96.4.82:7000/" ^
  "http://100.96.5.114:7000/" ^
  "http://100.96.3.18:7000/" ^
  "http://100.96.3.226:7000/" ^
  "http://100.96.2.210:6000/" ^
  "http://100.96.3.194:7000/" ^
  "http://100.96.1.34:7000/" ^
  "http://100.96.5.194:7000/" ^
  "http://100.96.1.130:7000/" ^
  "http://100.96.5.130:7000/" ^
  "http://100.96.2.98:7000/" ^
  "http://100.96.1.114:7000/" ^
  "http://100.96.1.18:7000/" ^
  "http://100.96.5.82:7000/" ^
  "http://100.96.2.66:7000/" ^
  "http://100.96.2.34:7000/" ^
  "https://100.96.4.210:7010/" ^
  "http://100.96.1.242:7000/" ^
  "http://100.96.5.210:7000/" ^
  "http://100.96.5.2:7000/" ^
  "http://100.96.4.242:7000/" ^
  "http://100.96.4.178:7000/" ^
  "http://100.96.5.226:7000/" ^
  "http://100.96.5.242:7000/" ^
  "http://100.96.5.98:7000/" ^
  "http://100.96.5.18:7000/" ^
  "http://100.96.5.34:7000/" ^
  "http://100.96.4.66:7000/" ^
  "http://100.96.2.246:7000/" ^
  "http://100.96.4.2:7000/" ^
  "http://100.96.3.242:7000/" ^
  "http://100.96.1.178:7000/" ^
  "http://100.96.1.226:7000/" ^
  "http://100.96.4.130:7000/" ^
  "http://100.96.2.50:7000/" ^
  "http://100.96.2.2:7000/" ^
  "http://100.96.5.162:7000/" ^
  "http://100.96.5.66:7000/" ^
  "http://100.96.2.146:7000/" ^
  "http://100.96.4.18:7000/" ^
  "http://100.96.4.146:7000/" ^
  "http://100.96.2.162:7000/" ^
  "http://100.96.1.210:7000/" 

exit /b 0
