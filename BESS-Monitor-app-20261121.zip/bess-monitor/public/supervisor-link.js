/* Botón flotante "Supervisor en vivo" en la pantalla principal del BESS Monitor.
   Lo agrega el servidor automáticamente; no hace falta tocar index.html. */
(function () {
  if (document.getElementById('sup-link-btn')) return;
  var a = document.createElement('a');
  a.id = 'sup-link-btn';
  a.href = '/supervisor';
  a.title = 'Supervisor en vivo: Red · Consumo · BESS · SOC con alertas por voz';
  a.innerHTML = '<span style="width:8px;height:8px;border-radius:50%;background:#22c55e;box-shadow:0 0 8px #22c55e;display:inline-block"></span> Supervisor en vivo';
  a.style.cssText = 'position:fixed;right:18px;bottom:18px;z-index:9999;display:flex;align-items:center;gap:8px;padding:11px 16px;border-radius:12px;' +
    'background:linear-gradient(135deg,#0f766e,#16a34a);color:#fff;font:700 13px Inter,Segoe UI,Arial,sans-serif;text-decoration:none;' +
    'box-shadow:0 10px 28px rgba(22,163,74,.35);border:1px solid rgba(255,255,255,.18)';
  document.body.appendChild(a);
})();
