/* BESS Monitor: service worker mínimo, solo para que Chrome permita instalar la app.
   No guarda nada en caché: todo se pide siempre en vivo al servidor. */
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', () => { /* sin caché: el navegador hace la petición normal */ });
