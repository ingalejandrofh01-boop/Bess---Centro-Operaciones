(() => {
  'use strict';

  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js').catch(() => {});
  }

  const socket = io();
  const grid = document.getElementById('sitesGrid');
  const eventsList = document.getElementById('eventsList');
  const toastStack = document.getElementById('toastStack');
  const escalationBar = document.getElementById('escalationBar');
  const searchBox = document.getElementById('searchBox');
  const groupBySelect = document.getElementById('groupBySelect');
  const mapViewBtn = document.getElementById('mapViewBtn');
  const mapModalBackdrop = document.getElementById('mapModalBackdrop');
  const mapCloseBtn = document.getElementById('mapCloseBtn');
  const mobileTabs = document.getElementById('mobileTabs');
  const mainLayout = document.getElementById('mainLayout');
  const playbackToggleBtn = document.getElementById('playbackToggleBtn');
  const playbackControls = document.getElementById('playbackControls');
  const playbackPlayBtn = document.getElementById('playbackPlayBtn');
  const playbackSlider = document.getElementById('playbackSlider');
  const playbackTimeLabel = document.getElementById('playbackTimeLabel');
  const playbackLiveBtn = document.getElementById('playbackLiveBtn');
  const mapPlaybackWrap = document.querySelector('.map-playback');
  const usersBtn = document.getElementById('usersBtn');
  const tvModeBtn = document.getElementById('tvModeBtn');
  const sessionUser = document.getElementById('sessionUser');
  const logoutBtn = document.getElementById('logoutBtn');
  const usersModalBackdrop = document.getElementById('usersModalBackdrop');
  const usersList = document.getElementById('usersList');
  const newUserName = document.getElementById('newUserName');
  const newUserPass = document.getElementById('newUserPass');
  const newUserRole = document.getElementById('newUserRole');
  const addUserBtn = document.getElementById('addUserBtn');
  const usersStatus = document.getElementById('usersStatus');
  const usersCloseBtn = document.getElementById('usersCloseBtn');
  const manageSitesBtn = document.getElementById('manageSitesBtn');
  const sitesModalBackdrop = document.getElementById('sitesModalBackdrop');
  const sitesCloseBtn = document.getElementById('sitesCloseBtn');
  const siteFormName = document.getElementById('siteFormName');
  const siteFormIp = document.getElementById('siteFormIp');
  const siteFormPort = document.getElementById('siteFormPort');
  const siteFormGroup = document.getElementById('siteFormGroup');
  const siteFormCity = document.getElementById('siteFormCity');
  const siteFormNewCityRow = document.getElementById('siteFormNewCityRow');
  const siteFormNewCityName = document.getElementById('siteFormNewCityName');
  const siteFormNewCityLat = document.getElementById('siteFormNewCityLat');
  const siteFormNewCityLng = document.getElementById('siteFormNewCityLng');
  const siteFormNotes = document.getElementById('siteFormNotes');
  const siteFormAddress = document.getElementById('siteFormAddress');
  const siteFormGeocodeBtn = document.getElementById('siteFormGeocodeBtn');
  const siteFormLat = document.getElementById('siteFormLat');
  const siteFormLng = document.getElementById('siteFormLng');
  const siteFormSaveBtn = document.getElementById('siteFormSaveBtn');
  const siteFormCancelBtn = document.getElementById('siteFormCancelBtn');
  const siteFormStatus = document.getElementById('siteFormStatus');
  const sitesTableBody = document.getElementById('sitesTableBody');
  const socketIndicator = document.getElementById('socketIndicator');
  const socketLabel = document.getElementById('socketLabel');
  const notifyBtn = document.getElementById('notifyBtn');
  const notifyLabel = document.getElementById('notifyLabel');
  const settingsBtn = document.getElementById('settingsBtn');
  const settingsLabel = document.getElementById('settingsLabel');
  const scadaAuthBtn = document.getElementById('scadaAuthBtn');
  const scadaAuthLabel = document.getElementById('scadaAuthLabel');
  const scadaAuthModalBackdrop = document.getElementById('scadaAuthModalBackdrop');
  const scadaUserInput = document.getElementById('scadaUserInput');
  const scadaPassInput = document.getElementById('scadaPassInput');
  const scadaAuthCancelBtn = document.getElementById('scadaAuthCancelBtn');
  const scadaAuthSaveBtn = document.getElementById('scadaAuthSaveBtn');
  const scadaAuthStatus = document.getElementById('scadaAuthStatus');
  const viewToggleBtn = document.getElementById('viewToggleBtn');
  const viewToggleLabel = document.getElementById('viewToggleLabel');
  const rankingPeriod = document.getElementById('rankingPeriod');
  const rankingTable = document.getElementById('rankingTable');
  const exportRankingBtn = document.getElementById('exportRankingBtn');
  const exportEventsBtn = document.getElementById('exportEventsBtn');
  const refreshOutageBtn = document.getElementById('refreshOutageBtn');
  const outageReportBody = document.getElementById('outageReportBody');
  const copyOutageBtn = document.getElementById('copyOutageBtn');
  const outageReportStatus = document.getElementById('outageReportStatus');
  const modalBackdrop = document.getElementById('settingsModalBackdrop');
  const teamsWebhookInput = document.getElementById('teamsWebhookInput');
  const notifyOfflineCheck = document.getElementById('notifyOffline');
  const notifyRecoveryCheck = document.getElementById('notifyRecovery');
  const notifyIntermittentCheck = document.getElementById('notifyIntermittent');
  const modalCancelBtn = document.getElementById('modalCancelBtn');
  const modalSaveBtn = document.getElementById('modalSaveBtn');
  const modalTestBtn = document.getElementById('modalTestBtn');
  const modalStatus = document.getElementById('modalStatus');
  const openHistoryBtn = document.getElementById('openHistoryBtn');
  const historyModalBackdrop = document.getElementById('historyModalBackdrop');
  const historyCloseBtn = document.getElementById('historyCloseBtn');
  const historySite = document.getElementById('historySite');
  const historyType = document.getElementById('historyType');
  const historySearch = document.getElementById('historySearch');
  const historyCount = document.getElementById('historyCount');
  const historyExportBtn = document.getElementById('historyExportBtn');
  const historyTableBody = document.getElementById('historyTableBody');
  const presetBtns = () => Array.from(document.querySelectorAll('.preset-btn'));
  const siteModalBackdrop = document.getElementById('siteModalBackdrop');
  const siteModalCloseBtn = document.getElementById('siteModalCloseBtn');
  const siteModalName = document.getElementById('siteModalName');
  const siteModalMeta = document.getElementById('siteModalMeta');
  const siteModalStatus = document.getElementById('siteModalStatus');
  const siteModalLatency = document.getElementById('siteModalLatency');
  const siteModalUptime = document.getElementById('siteModalUptime');
  const siteModalScada = document.getElementById('siteModalScada');
  const siteModalFieldsWrap = document.getElementById('siteModalFieldsWrap');
  const siteModalFieldsList = document.getElementById('siteModalFieldsList');
  const siteModalHttpAccess = document.getElementById('siteModalHttpAccess');
  const siteModalVncAccess = document.getElementById('siteModalVncAccess');
  const siteModalOpenBtn = document.getElementById('siteModalOpenBtn');
  const siteModalPreviewBtn = document.getElementById('siteModalPreviewBtn');
  const siteModalVncPort = document.getElementById('siteModalVncPort');
  const siteModalVncBtn = document.getElementById('siteModalVncBtn');
  const siteModalPreviewWrap = document.getElementById('siteModalPreviewWrap');
  const siteModalIframe = document.getElementById('siteModalIframe');
  const siteModalCalibrateBtn = document.getElementById('siteModalCalibrateBtn');
  const visionModalBackdrop = document.getElementById('visionModalBackdrop');
  const visionModalName = document.getElementById('visionModalName');
  const visionCloseBtn = document.getElementById('visionCloseBtn');
  const visionRefreshBtn = document.getElementById('visionRefreshBtn');
  const visionSaveBtn = document.getElementById('visionSaveBtn');
  const visionClearBtn = document.getElementById('visionClearBtn');
  const visionImageWrap = document.getElementById('visionImageWrap');
  const visionScreenshotImg = document.getElementById('visionScreenshotImg');
  const visionFieldBoxes = document.getElementById('visionFieldBoxes');
  const visionStatus = document.getElementById('visionStatus');
  const visionFieldLabel = document.getElementById('visionFieldLabel');
  const visionFieldKind = document.getElementById('visionFieldKind');
  const visionFieldUnit = document.getElementById('visionFieldUnit');
  const visionFieldNav = document.getElementById('visionFieldNav');
  const visionMarkFieldBtn = document.getElementById('visionMarkFieldBtn');
  const visionFieldsList = document.getElementById('visionFieldsList');
  const visionNavPreviewBtn = document.getElementById('visionNavPreviewBtn');

  const STATUS_TEXT = {
    online: 'En línea',
    intermittent: 'Intermitente',
    offline: 'Desconectado',
    unknown: 'Verificando…',
  };

  // siteId -> { el, cardData, history: [{t, up, latencyMs}, ...] }
  const cards = new Map();
  let searchTerm = '';

  // Declaradas aquí arriba (aunque se usan más abajo, en la sección del mapa)
  // porque el toggle de tema las necesita desde el arranque, antes de que el
  // mapa se haya abierto siquiera una vez.
  let leafletMap = null;
  let mapMarkers = new Map(); // siteId -> marker
  let weatherByCity = {};
  let uptime7dBySite = {};
  let stormCache = new Map(); // "ciudad|hora" -> resultado
  let mapTileLayer = null;
  let energyLayers = []; // líneas de energía + nodo hub central, se limpian y redibujan en cada render
  const GRID_HUB = { lat: 19.42651538847507, lng: -99.17726500477308, label: 'SKYSENSE' }; // Oficina central — coordenada exacta confirmada

  // ---------- Vista detallada / compacta ----------

  function applyViewMode(mode) {
    grid.classList.toggle('compact', mode === 'compact');
    viewToggleLabel.textContent = mode === 'compact' ? 'Vista detallada' : 'Vista compacta';
    viewToggleBtn.querySelector('.bell').textContent = mode === 'compact' ? '▤' : '▦';
  }

  let viewMode = 'detailed';
  try {
    viewMode = localStorage.getItem('bessViewMode') || 'detailed';
  } catch (_) { /* localStorage no disponible, se queda en modo detallado */ }
  applyViewMode(viewMode);

  viewToggleBtn.addEventListener('click', () => {
    viewMode = viewMode === 'compact' ? 'detailed' : 'compact';
    applyViewMode(viewMode);
    try { localStorage.setItem('bessViewMode', viewMode); } catch (_) { /* no crítico */ }
  });

  // ---------- Tema claro / oscuro ----------

  const themeToggleBtn = document.getElementById('themeToggleBtn');
  const themeToggleIcon = document.getElementById('themeToggleIcon');
  const themeToggleLabel = document.getElementById('themeToggleLabel');

  function applyTheme(theme) {
    if (theme === 'light') {
      document.documentElement.setAttribute('data-theme', 'light');
      themeToggleIcon.textContent = '🌙';
      themeToggleLabel.textContent = 'Modo oscuro';
    } else {
      document.documentElement.removeAttribute('data-theme');
      themeToggleIcon.textContent = '☀️';
      themeToggleLabel.textContent = 'Modo claro';
    }
    // Si el mapa ya está abierto, cambia también las teselas para que combinen.
    if (typeof setMapTheme === 'function') setMapTheme(theme);
  }

  let currentTheme = 'dark';
  try {
    currentTheme = localStorage.getItem('bess-theme') || 'dark';
  } catch (_) { /* localStorage no disponible, se queda en modo oscuro */ }
  applyTheme(currentTheme);

  themeToggleBtn.addEventListener('click', () => {
    currentTheme = currentTheme === 'light' ? 'dark' : 'light';
    applyTheme(currentTheme);
    try { localStorage.setItem('bess-theme', currentTheme); } catch (_) { /* no crítico */ }
  });

  // ---------- Silenciar sonido y voz de alertas ----------

  const muteToggleBtn = document.getElementById('muteToggleBtn');
  const muteToggleIcon = document.getElementById('muteToggleIcon');
  const muteToggleLabel = document.getElementById('muteToggleLabel');

  let soundMuted = false;
  try { soundMuted = localStorage.getItem('bess-muted') === '1'; } catch (_) { /* se queda con sonido activo */ }

  function applyMuteUI() {
    if (soundMuted) {
      muteToggleBtn.classList.add('muted');
      muteToggleIcon.textContent = '🔕';
      muteToggleLabel.textContent = 'Silenciado';
    } else {
      muteToggleBtn.classList.remove('muted');
      muteToggleIcon.textContent = '🔔';
      muteToggleLabel.textContent = 'Sonido activo';
    }
  }
  applyMuteUI();

  muteToggleBtn.addEventListener('click', () => {
    soundMuted = !soundMuted;
    applyMuteUI();
    try { localStorage.setItem('bess-muted', soundMuted ? '1' : '0'); } catch (_) { /* no crítico */ }
    if (soundMuted) speechSynthesis && speechSynthesis.cancel && speechSynthesis.cancel(); // corta una voz que ya esté sonando
  });

  // ---------- Conexión socket ----------

  socket.on('connect', () => {
    socketIndicator.className = 'socket-indicator connected';
    socketLabel.textContent = 'en vivo';
  });

  socket.on('disconnect', () => {
    socketIndicator.className = 'socket-indicator disconnected';
    socketLabel.textContent = 'sin conexión al servidor';
  });

  socket.on('sites:changed', (sitesArr) => {
    sitesArr.forEach((site) => upsertCard(site));
    // eliminar tarjetas de sitios que ya no existen
    const currentIds = new Set(sitesArr.map((s) => s.id));
    for (const id of cards.keys()) {
      if (!currentIds.has(id)) {
        cards.get(id).el.remove();
        cards.delete(id);
      }
    }
    updateSummary();
    applyFilter();
    regroupGrid();
    if (sitesModalBackdrop.classList.contains('open')) renderSitesTable();
  });

  let mapUpdateDebounce = null;

  socket.on('site:update', (site) => {
    upsertCard(site);
    updateSummary();
    if (currentDetailSite && currentDetailSite.id === site.id && siteModalBackdrop.classList.contains('open')) {
      currentDetailSite = site;
      renderMaintenanceDisplay(site);
      renderAssignmentDisplay(site);
    }
    if (mapModalBackdrop.classList.contains('open')) {
      clearTimeout(mapUpdateDebounce);
      mapUpdateDebounce = setTimeout(() => {
        renderMapMarkers();
        updateMapStats();
      }, 2000);
    }
  });

  socket.on('site:scada', (payload) => {
    const card = cards.get(payload.siteId);
    if (!card) return;
    renderScada(card, payload.scada, payload.scadaError);
  });

  socket.on('events:init', (events) => {
    eventsList.innerHTML = '';
    events.forEach((e) => addEventItem(e, false));
  });

  socket.on('site:statusChange', (evt) => {
    addEventItem(evt, true);
    if (!evt.inMaintenance) {
      showToast(evt);
      sendDesktopNotification(evt);
    }
    loadRanking();
    loadOutageReport();
  });

  // ---------- Tarjetas de sitio ----------

  function upsertCard(site) {
    let card = cards.get(site.id);
    if (!card) {
      const tpl = document.getElementById('siteCardTemplate');
      const el = tpl.content.firstElementChild.cloneNode(true);
      grid.appendChild(el);
      card = { el, history: [] };
      cards.set(site.id, card);
      fetchHistory(site.id, card);
      el.addEventListener('click', () => openSiteDetailModal(card.lastSite));
    }
    card.lastSite = site;

    const el = card.el;
    const maintType = site.maintenance ? (site.maintenance.type || 'mantenimiento') : null;
    const cardStatusMap = { mantenimiento: 'maintenance', fuera_operacion: 'outofservice', sin_comunicacion: 'knownissue' };
    const cardStatus = maintType ? cardStatusMap[maintType] : site.status;
    const cardStatusText = {
      maintenance: '🔧 Mantenimiento',
      outofservice: '⚫ Fuera de operación',
      knownissue: '🔕 Sin comunicación (conocido)',
    };
    el.dataset.status = cardStatus;
    el.querySelector('.site-name').textContent = site.name;
    el.querySelector('.site-ip').textContent = site.ip + (site.port ? `:${site.port}` : '');
    el.querySelector('.status-text').textContent = cardStatusText[cardStatus] || (STATUS_TEXT[site.status] || site.status);

    el.querySelector('.latency-value').textContent = site.latencyMs != null ? `${Math.round(site.latencyMs)} ms` : '—';
    el.querySelector('.uptime-value').textContent = site.uptimePct != null ? `${site.uptimePct}%` : '—';
    el.querySelector('.last-check-value').textContent = site.lastCheck ? timeAgo(site.lastCheck) : '—';

    if (site.hasScada) {
      renderScada(card, site.scada, site.scadaError);
    }

    if (site.lastCheck) {
      card.history.push({ t: site.lastCheck, up: site.status !== 'offline', latencyMs: site.latencyMs });
      if (card.history.length > 60) card.history.shift();
    }
    drawPulse(card);

    card._searchBlob = `${site.name} ${site.ip}`.toLowerCase();
    applyFilterToCard(card);
  }

  const STATUS_ES = { cargando: 'Cargando ⬇', descargando: 'Descargando ⬆', standby: 'Standby ⏸' };

  function extractSocAndSummary(scada) {
    if (scada.fields && Array.isArray(scada.fields)) {
      const socField = scada.fields.find((f) => f.kind === 'soc' && f.value != null);
      const otherCount = scada.fields.filter((f) => !(f.kind === 'soc' && f === socField)).length;
      return {
        soc: socField ? socField.value : null,
        summary: scada.status
          ? (STATUS_ES[scada.status] || scada.status)
          : (otherCount > 0 ? `${scada.fields.length} métricas` : null),
      };
    }
    return {
      soc: firstDefined(scada, ['soc', 'SOC', 'stateOfCharge', 'state_of_charge']),
      summary: null,
    };
  }

  function renderScada(card, scada, error) {
    const socValEl = card.el.querySelector('.soc-value');
    const socFillEl = card.el.querySelector('.soc-bar-fill');
    const tempValEl = card.el.querySelector('.temp-value');

    if (error) {
      socValEl.textContent = 'Error SCADA';
      socValEl.classList.remove('has-data');
      tempValEl.textContent = 'Error SCADA';
      tempValEl.classList.remove('has-data');
      socFillEl.style.width = '0%';
      return;
    }
    if (!scada) {
      socValEl.textContent = 'Sin SCADA';
      tempValEl.textContent = 'Sin SCADA';
      socValEl.classList.remove('has-data');
      tempValEl.classList.remove('has-data');
      socFillEl.style.width = '0%';
      return;
    }

    const { soc, summary } = extractSocAndSummary(scada);
    const temp = summary == null ? firstDefined(scada, ['tempC', 'temperature', 'temp', 'temp_c']) : null;

    if (soc != null) {
      socValEl.textContent = `${soc}%`;
      socValEl.classList.add('has-data');
      socFillEl.style.width = `${Math.max(0, Math.min(100, soc))}%`;
    } else {
      socValEl.textContent = 'Sin dato';
      socFillEl.style.width = '0%';
    }

    if (summary != null) {
      tempValEl.textContent = summary;
      tempValEl.classList.add('has-data');
    } else if (temp != null) {
      tempValEl.textContent = `${temp} °C`;
      tempValEl.classList.add('has-data');
    } else {
      tempValEl.textContent = 'Sin dato';
    }
  }

  const siteModalStability = document.getElementById('siteModalStability');
  const latencyPeriodSelect = document.getElementById('latencyPeriodSelect');
  const siteLatencyChart = document.getElementById('siteLatencyChart');
  const latencyChartStatus = document.getElementById('latencyChartStatus');
  const maintenanceDisplay = document.getElementById('maintenanceDisplay');
  const maintenanceForm = document.getElementById('maintenanceForm');
  const maintenanceNoteInput = document.getElementById('maintenanceNoteInput');
  const maintenanceTypeSelect = document.getElementById('maintenanceTypeSelect');
  const maintenanceDurationSelect = document.getElementById('maintenanceDurationSelect');
  const maintenanceSaveBtn = document.getElementById('maintenanceSaveBtn');
  const maintenanceCancelBtn = document.getElementById('maintenanceCancelBtn');
  const maintenanceToggleBtn = document.getElementById('maintenanceToggleBtn');
  const assignmentDisplay = document.getElementById('assignmentDisplay');
  const assignmentForm = document.getElementById('assignmentForm');
  const assignmentNameInput = document.getElementById('assignmentNameInput');
  const assignmentSaveBtn = document.getElementById('assignmentSaveBtn');
  const assignmentCancelBtn = document.getElementById('assignmentCancelBtn');
  const assignmentToggleBtn = document.getElementById('assignmentToggleBtn');

  function formatDurationClientMs(ms) {
    const totalMin = Math.round(ms / 60000);
    if (totalMin < 1) return '<1 min';
    if (totalMin < 60) return `${totalMin} min`;
    const h = Math.floor(totalMin / 60);
    const m = totalMin % 60;
    if (h < 24) return m ? `${h}h ${m}min` : `${h}h`;
    const d = Math.floor(h / 24);
    return `${d}d ${h % 24}h`;
  }

  async function loadSiteStability(siteId) {
    siteModalStability.innerHTML = '<p style="color:var(--text-faint);font-size:11px;">Cargando…</p>';
    try {
      const periods = [{ label: '24 horas', days: 1 }, { label: '7 días', days: 7 }, { label: '30 días', days: 30 }];
      const results = await Promise.all(periods.map(async (p) => {
        const resp = await fetch(`/api/ranking?days=${p.days}`);
        const rows = await resp.json();
        return { ...p, data: rows.find((r) => r.id === siteId) };
      }));
      siteModalStability.innerHTML = results.map((r) => `
        <div class="stability-period-card">
          <span class="sp-label">${r.label}</span>
          <span class="sp-drops ${r.data && r.data.drops > 0 ? 'has-drops' : ''}">${r.data ? r.data.drops : 0} caída${r.data && r.data.drops === 1 ? '' : 's'}</span>
          <span class="sp-detail">${r.data && r.data.downtimeMs ? formatDurationClientMs(r.data.downtimeMs) + ' caído' : 'sin caídas'}</span>
          <span class="sp-detail">${r.data && r.data.uptimePct != null ? r.data.uptimePct + '% uptime' : ''}</span>
        </div>
      `).join('');
    } catch (_) {
      siteModalStability.innerHTML = '<p style="color:var(--text-faint);font-size:11px;">No se pudo cargar.</p>';
    }
  }

  const siteModalHeatmap = document.getElementById('siteModalHeatmap');
  let heatmapTooltipEl = null;

  function heatmapLevel(uptimePct) {
    if (uptimePct == null) return 'nodata';
    if (uptimePct >= 99.9) return 'best';
    if (uptimePct >= 98) return 'good';
    if (uptimePct >= 90) return 'warn';
    return 'bad';
  }
  const HEATMAP_LEVEL_LABEL = {
    nodata: 'Sin datos ese día',
    best: 'Sin problemas',
    good: 'Muy buen día',
    warn: 'Intermitencias',
    bad: 'Caídas prolongadas',
  };

  async function loadSiteHeatmap(siteId) {
    siteModalHeatmap.innerHTML = '<p class="site-heatmap-empty">Cargando…</p>';
    try {
      const resp = await fetch(`/api/sites/${siteId}/daily-uptime?days=120`);
      const days = await resp.json(); // [{day, uptimePct, samples}, ...] ascendente
      if (!days.length) {
        siteModalHeatmap.innerHTML = '<p class="site-heatmap-empty">Todavía no hay suficiente historial para el mapa de calor — se va llenando solo con el tiempo.</p>';
        return;
      }
      const byDay = new Map(days.map((d) => [d.day, d]));
      const DAY_MS = 24 * 60 * 60 * 1000;
      const todayStart = Math.floor(Date.now() / DAY_MS) * DAY_MS;
      const rangeStart = todayStart - 119 * DAY_MS;
      const startDow = new Date(rangeStart).getDay();
      const firstCellDay = rangeStart - startDow * DAY_MS;
      const totalWeeks = Math.ceil((todayStart - firstCellDay) / DAY_MS / 7) + 1;

      if (!heatmapTooltipEl) {
        heatmapTooltipEl = document.createElement('div');
        heatmapTooltipEl.className = 'site-heatmap-tooltip';
        document.body.appendChild(heatmapTooltipEl);
      }

      let html = '<div class="site-heatmap-scroll">';
      for (let w = 0; w < totalWeeks; w++) {
        html += '<div class="site-heatmap-week">';
        for (let d = 0; d < 7; d++) {
          const dayMs = firstCellDay + (w * 7 + d) * DAY_MS;
          if (dayMs < rangeStart || dayMs > todayStart) {
            html += '<div class="site-heatmap-day" data-level="none"></div>';
            continue;
          }
          const entry = byDay.get(dayMs);
          const level = heatmapLevel(entry ? entry.uptimePct : null);
          const dateLabel = new Date(dayMs).toLocaleDateString('es-MX', { day: 'numeric', month: 'short', year: 'numeric' });
          const pctLabel = entry && entry.uptimePct != null ? `${entry.uptimePct}% uptime` : HEATMAP_LEVEL_LABEL.nodata;
          html += `<div class="site-heatmap-day" data-level="${level}" data-has="${entry ? '1' : '0'}" data-date="${escapeHtml(dateLabel)}" data-pct="${escapeHtml(pctLabel)}"></div>`;
        }
        html += '</div>';
      }
      html += '</div>';
      html += `
        <div class="site-heatmap-legend">
          Menos estable
          <div class="site-heatmap-day" data-level="bad"></div>
          <div class="site-heatmap-day" data-level="warn"></div>
          <div class="site-heatmap-day" data-level="good"></div>
          <div class="site-heatmap-day" data-level="best"></div>
          Más estable
        </div>`;
      siteModalHeatmap.innerHTML = html;

      siteModalHeatmap.querySelectorAll('.site-heatmap-day[data-has="1"]').forEach((cell) => {
        cell.addEventListener('mousemove', (e) => {
          heatmapTooltipEl.innerHTML = `<div class="hm-date">${cell.getAttribute('data-date')}</div><div class="hm-main">${cell.getAttribute('data-pct')}</div>`;
          heatmapTooltipEl.style.left = (e.clientX + 14) + 'px';
          heatmapTooltipEl.style.top = (e.clientY + 14) + 'px';
          heatmapTooltipEl.style.opacity = '1';
        });
        cell.addEventListener('mouseleave', () => { heatmapTooltipEl.style.opacity = '0'; });
      });
    } catch (_) {
      siteModalHeatmap.innerHTML = '<p class="site-heatmap-empty">No se pudo cargar el mapa de calor.</p>';
    }
  }

  // ---------- Mantenimiento ----------

  const MAINT_TYPE_META = {
    mantenimiento: { icon: '🔧', label: 'En mantenimiento', cls: 'type-mantenimiento', toggleOff: '✕ Quitar mantenimiento' },
    fuera_operacion: { icon: '⚫', label: 'Fuera de operación', cls: 'type-fuera-operacion', toggleOff: '✕ Marcar como operando' },
    sin_comunicacion: { icon: '🔕', label: 'Sin comunicación conocida (silenciado)', cls: 'type-sin-comunicacion', toggleOff: '✕ Quitar silencio' },
  };

  const maintenanceTypeButtons = document.getElementById('maintenanceTypeButtons');

  function selectMaintType(type) {
    maintenanceTypeSelect.value = type;
    maintenanceTypeButtons.querySelectorAll('.maint-type-btn').forEach((b) => {
      b.classList.toggle('selected', b.getAttribute('data-type') === type);
    });
    maintenanceSaveBtn.disabled = false;
    maintenanceSaveBtn.textContent = 'Confirmar';
  }

  maintenanceTypeButtons.querySelectorAll('.maint-type-btn').forEach((btn) => {
    btn.addEventListener('click', () => selectMaintType(btn.getAttribute('data-type')));
  });

  function openMaintenanceForm(existing) {
    maintenanceNoteInput.value = existing ? (existing.note || '') : '';
    maintenanceDurationSelect.value = existing && existing.until ? '' : ''; // no reconstruimos la duración pasada, el operador elige de nuevo si quiere renovarla
    maintenanceTypeSelect.value = '';
    maintenanceTypeButtons.querySelectorAll('.maint-type-btn').forEach((b) => b.classList.remove('selected'));
    maintenanceSaveBtn.disabled = true;
    maintenanceSaveBtn.textContent = 'Elige un tipo arriba primero';
    if (existing) selectMaintType(existing.type || 'mantenimiento'); // al editar, ya viene preseleccionado el que tenía
    maintenanceForm.style.display = 'flex';
  }

  function renderMaintenanceDisplay(site) {
    if (site.maintenance) {
      const meta = MAINT_TYPE_META[site.maintenance.type] || MAINT_TYPE_META.mantenimiento;
      const untilText = site.maintenance.until ? ` · hasta las ${new Date(site.maintenance.until).toLocaleString('es-MX')}` : ' · sin límite de tiempo';
      maintenanceDisplay.innerHTML = `
        <div class="maintenance-badge ${meta.cls}">
          ${meta.icon} ${meta.label}${site.maintenance.note ? ': ' + escapeHtml(site.maintenance.note) : ''}${untilText}
        </div>
        <div class="ops-btn-row">
          <button id="maintenanceEditBtn" class="modal-btn secondary" type="button">✎ Cambiar tipo o nota</button>
        </div>
      `;
      document.getElementById('maintenanceEditBtn').onclick = () => openMaintenanceForm(site.maintenance);
      maintenanceToggleBtn.textContent = meta.toggleOff;
      maintenanceToggleBtn.onclick = async () => {
        await fetch(`/api/sites/${site.id}/maintenance`, { method: 'DELETE' });
      };
    } else {
      maintenanceDisplay.innerHTML = '<p class="ops-empty">Operando normal — sin marcas activas.</p>';
      maintenanceToggleBtn.textContent = '🔧 Marcar estado (mantenimiento / fuera de operación / sin comunicación)';
      maintenanceToggleBtn.onclick = () => openMaintenanceForm(null);
    }
  }

  maintenanceCancelBtn.addEventListener('click', () => { maintenanceForm.style.display = 'none'; });

  maintenanceSaveBtn.addEventListener('click', async () => {
    if (!currentDetailSite) return;
    if (!maintenanceTypeSelect.value) return; // por si acaso, aunque el botón debería estar deshabilitado
    const durationMin = maintenanceDurationSelect.value ? parseInt(maintenanceDurationSelect.value, 10) : null;
    const until = durationMin ? Date.now() + durationMin * 60000 : null;
    await fetch(`/api/sites/${currentDetailSite.id}/maintenance`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ note: maintenanceNoteInput.value.trim(), until, type: maintenanceTypeSelect.value }),
    });
    maintenanceForm.style.display = 'none';
  });

  // ---------- Responsable asignado ----------

  function renderAssignmentDisplay(site) {
    if (site.assignment) {
      assignmentDisplay.innerHTML = `
        <div class="assignment-badge">
          👤 ${escapeHtml(site.assignment.assignedTo)} · desde las ${new Date(site.assignment.assignedAt).toLocaleTimeString('es-MX')}
        </div>
      `;
      assignmentToggleBtn.textContent = '✕ Quitar asignación';
      assignmentToggleBtn.onclick = async () => {
        await fetch(`/api/sites/${site.id}/assign`, { method: 'DELETE' });
      };
    } else {
      assignmentDisplay.innerHTML = '<p class="ops-empty">Nadie asignado todavía.</p>';
      assignmentToggleBtn.textContent = '👤 Asignar responsable';
      assignmentToggleBtn.onclick = () => {
        assignmentNameInput.value = '';
        assignmentForm.style.display = 'flex';
      };
    }
  }

  assignmentCancelBtn.addEventListener('click', () => { assignmentForm.style.display = 'none'; });

  assignmentSaveBtn.addEventListener('click', async () => {
    if (!currentDetailSite) return;
    const name = assignmentNameInput.value.trim();
    if (!name) return;
    await fetch(`/api/sites/${currentDetailSite.id}/assign`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ assignedTo: name }),
    });
    assignmentForm.style.display = 'none';
  });

  // ---------- Gráfica de latencia larga ----------

  async function loadLatencyChart(siteId) {
    latencyChartStatus.textContent = 'Cargando…';
    try {
      const days = latencyPeriodSelect.value;
      const resp = await fetch(`/api/sites/${siteId}/latency-history?days=${days}`);
      const points = await resp.json();
      drawLatencyChart(points);
      latencyChartStatus.textContent = points.length ? '' : 'Todavía no hay suficiente historial para este periodo.';
    } catch (_) {
      latencyChartStatus.textContent = 'No se pudo cargar la gráfica.';
    }
  }

  function drawLatencyChart(points) {
    const ctx = siteLatencyChart.getContext('2d');
    const w = siteLatencyChart.width, h = siteLatencyChart.height;
    ctx.clearRect(0, 0, w, h);
    if (!points.length) return;

    const validPoints = points.filter((p) => p.avg != null);
    const maxLat = Math.max(...points.map((p) => p.max || 0), 20);
    const stepX = w / Math.max(points.length - 1, 1);

    // Fondo rojo tenue donde el uptime de esa hora fue bajo (hubo caídas).
    points.forEach((p, i) => {
      if (p.uptimePct != null && p.uptimePct < 100) {
        ctx.fillStyle = `rgba(229, 72, 77, ${0.28 * (1 - p.uptimePct / 100) + 0.06})`;
        ctx.fillRect(i * stepX - stepX / 2, 0, stepX, h);
      }
    });

    if (validPoints.length === 0) {
      // No hay ni un solo dato de latencia en todo el periodo — casi
      // seguro el sitio estuvo caído (o casi caído) todo ese tiempo.
      // Se avisa con texto en vez de dejar solo un bloque rojo sin explicar.
      ctx.fillStyle = 'rgba(255,255,255,0.75)';
      ctx.font = '12px "IBM Plex Mono", monospace';
      ctx.textAlign = 'center';
      ctx.fillText('Sin datos de latencia — el sitio estuvo caído la mayor parte de este periodo', w / 2, h / 2 + 4);
      return;
    }

    // Línea de latencia promedio.
    ctx.strokeStyle = '#4fd1e8';
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    let started = false;
    points.forEach((p, i) => {
      if (p.avg == null) return;
      const x = i * stepX;
      const y = h - 4 - (p.avg / maxLat) * (h - 10);
      if (!started) { ctx.moveTo(x, y); started = true; } else { ctx.lineTo(x, y); }
    });
    ctx.stroke();
  }

  latencyPeriodSelect.addEventListener('change', () => {
    if (currentDetailSite) loadLatencyChart(currentDetailSite.id);
  });

  function firstDefined(obj, keys) {
    for (const k of keys) {
      if (obj[k] !== undefined && obj[k] !== null) return obj[k];
    }
    return null;
  }

  async function fetchHistory(siteId, card) {
    try {
      const resp = await fetch(`/api/sites/${siteId}/history?limit=60`);
      const data = await resp.json();
      card.history = data;
      drawPulse(card);
    } catch (_) { /* silencioso: no crítico para el render inicial */ }
  }

  function drawPulse(card) {
    const canvas = card.el.querySelector('.pulse-canvas');
    const ctx = canvas.getContext('2d');
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    const points = card.history.slice(-40);
    if (points.length < 2) return;

    const latencies = points.map((p) => (p.up ? (p.latencyMs || 1) : null));
    const validLatencies = latencies.filter((v) => v != null);
    const max = Math.max(...validLatencies, 20);
    const stepX = w / (points.length - 1);

    const status = card.el.dataset.status;
    const color = status === 'offline' ? '#e5484d' : status === 'intermittent' ? '#f5a623' : '#33d17a';

    ctx.strokeStyle = color;
    ctx.lineWidth = 1.6;
    ctx.beginPath();

    points.forEach((p, i) => {
      const x = i * stepX;
      let y;
      if (p.up) {
        const norm = (p.latencyMs || 1) / max;
        y = h - 6 - norm * (h - 14);
      } else {
        y = h - 4; // caída plana abajo = sin respuesta
      }
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    });
    ctx.stroke();

    // puntos rojos donde hubo caída
    ctx.fillStyle = '#e5484d';
    points.forEach((p, i) => {
      if (!p.up) {
        const x = i * stepX;
        ctx.beginPath();
        ctx.arc(x, h - 4, 2, 0, Math.PI * 2);
        ctx.fill();
      }
    });
  }

  // ---------- Bitácora de eventos ----------

  function addEventItem(evt, prepend) {
    const div = document.createElement('div');
    div.className = `event-item to-${evt.to}`;
    div.innerHTML = `
      <div>${escapeHtml(evt.message)}</div>
      <span class="event-time">${new Date(evt.ts).toLocaleString('es-MX')}</span>
    `;
    if (prepend) {
      eventsList.prepend(div);
    } else {
      eventsList.appendChild(div);
    }
    while (eventsList.children.length > 300) {
      eventsList.removeChild(eventsList.lastChild);
    }
  }

  // ---------- Toasts ----------

  function showToast(evt) {
    const toast = document.createElement('div');
    toast.className = `toast-card ${evt.to}`;

    const statusWord = evt.to === 'offline' ? 'Comunicación perdida'
      : evt.to === 'online' ? 'Comunicación recuperada'
      : 'Intermitencia detectada';

    toast.innerHTML = `
      <div class="toast-badge"><img src="/assets/skysense-mark.png" alt="SkySense" /></div>
      <div class="toast-body">
        <div class="toast-eyebrow">SkySense · <span class="status-word">${statusWord}</span></div>
        <div class="toast-title">${escapeHtml(evt.siteName)}</div>
        <div class="toast-msg">${escapeHtml(evt.message)}</div>
        <div class="toast-time">${new Date(evt.ts).toLocaleTimeString('es-MX')} · ${escapeHtml(evt.ip)}</div>
      </div>
      <button class="toast-close" type="button" aria-label="Cerrar">×</button>
      <div class="toast-progress-track"><div class="toast-progress-fill"></div></div>
    `;

    toastStack.appendChild(toast);

    const DURATION = 8000;
    let dismissed = false;
    const dismiss = () => {
      if (dismissed) return;
      dismissed = true;
      toast.classList.add('leaving');
      setTimeout(() => toast.remove(), 300);
    };

    const fill = toast.querySelector('.toast-progress-fill');
    requestAnimationFrame(() => {
      fill.style.transition = `width ${DURATION}ms linear`;
      fill.style.width = '0%';
    });

    toast.querySelector('.toast-close').addEventListener('click', dismiss);
    const timer = setTimeout(dismiss, DURATION);
    toast.addEventListener('mouseenter', () => {
      fill.style.transition = 'none';
      clearTimeout(timer);
    });
  }

  // ---------- Notificaciones de escritorio (por encima de la pantalla) ----------

  function updateNotifyButton() {
    if (!('Notification' in window)) {
      notifyBtn.classList.add('blocked');
      notifyLabel.textContent = 'Este navegador no soporta alertas';
      notifyBtn.disabled = true;
      return;
    }
    if (Notification.permission === 'granted') {
      notifyBtn.classList.add('active');
      notifyBtn.classList.remove('blocked');
      notifyLabel.textContent = 'Alertas de escritorio activas';
    } else if (Notification.permission === 'denied') {
      notifyBtn.classList.add('blocked');
      notifyBtn.classList.remove('active');
      notifyLabel.textContent = 'Bloqueadas — habilítalas en el navegador';
    } else {
      notifyBtn.classList.remove('active', 'blocked');
      notifyLabel.textContent = 'Activar alertas de escritorio';
    }
  }

  notifyBtn.addEventListener('click', async () => {
    if (!('Notification' in window)) return;
    if (Notification.permission === 'default') {
      await Notification.requestPermission();
      updateNotifyButton();
      if (Notification.permission === 'granted') {
        new Notification('BESS Monitor', {
          body: 'Alertas activadas. Te avisaré aquí cuando un sitio pierda o recupere comunicación.',
        });
      }
    } else {
      updateNotifyButton();
    }
  });

  function sendDesktopNotification(evt) {
    if (!('Notification' in window) || Notification.permission !== 'granted') return;
    const title = evt.to === 'offline'
      ? `⚠ ${evt.siteName} — comunicación perdida`
      : evt.to === 'online'
        ? `✓ ${evt.siteName} — comunicación recuperada`
        : `● ${evt.siteName} — intermitencia`;
    const n = new Notification(title, {
      body: `${evt.ip} · ${new Date(evt.ts).toLocaleTimeString('es-MX')}`,
      icon: '/assets/skysense-mark.png',
      badge: '/assets/skysense-mark.png',
      requireInteraction: evt.to === 'offline', // se queda en pantalla hasta que la cierren, solo para caídas
      tag: `bess-${evt.siteId}-${evt.ts}`,
    });
    n.onclick = () => { window.focus(); n.close(); };
    playAlertTone(evt.to);
  }

  let audioCtx = null;
  function playAlertTone(kind) {
    if (soundMuted) return;
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.type = 'sine';
      if (kind === 'offline') {
        osc.frequency.setValueAtTime(440, audioCtx.currentTime);
        osc.frequency.setValueAtTime(330, audioCtx.currentTime + 0.15);
      } else if (kind === 'online') {
        osc.frequency.setValueAtTime(523, audioCtx.currentTime);
        osc.frequency.setValueAtTime(659, audioCtx.currentTime + 0.12);
      } else {
        osc.frequency.setValueAtTime(392, audioCtx.currentTime);
      }
      gain.gain.setValueAtTime(0.001, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.15, audioCtx.currentTime + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.35);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.4);
    } catch (_) { /* audio no disponible, no es crítico */ }
  }

  updateNotifyButton();

  // ---------- Alertas escalonadas por tiempo caído ----------

  function beep(freq, startOffset, durationSec, volume) {
    audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.type = 'square';
    const t0 = audioCtx.currentTime + startOffset;
    osc.frequency.setValueAtTime(freq, t0);
    gain.gain.setValueAtTime(0.001, t0);
    gain.gain.exponentialRampToValueAtTime(volume, t0 + 0.03);
    gain.gain.exponentialRampToValueAtTime(0.001, t0 + durationSec);
    osc.start(t0);
    osc.stop(t0 + durationSec + 0.05);
  }

  function playEscalationSound(level) {
    if (soundMuted) return;
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      if (level === 1) {
        beep(660, 0, 0.25, 0.18);
      } else if (level === 2) {
        beep(700, 0, 0.18, 0.22);
        beep(700, 0.25, 0.18, 0.22);
      } else if (level === 3) {
        beep(880, 0, 0.15, 0.28);
        beep(880, 0.2, 0.15, 0.28);
        beep(880, 0.4, 0.15, 0.28);
      } else {
        // Nivel 4 (urgencia): patrón tipo sirena, repetido varias veces.
        for (let i = 0; i < 4; i++) {
          beep(950, i * 0.5, 0.22, 0.3);
          beep(650, i * 0.5 + 0.25, 0.22, 0.3);
        }
      }
    } catch (_) { /* audio no disponible, no es crítico */ }
  }

  function speakEscalation(evt) {
    if (soundMuted) return;
    if (!('speechSynthesis' in window)) return;
    const messages = {
      1: `Aviso. El sitio ${evt.siteName} no tiene comunicación.`,
      2: `Alerta. El sitio ${evt.siteName} lleva ${evt.minutesDown} minutos sin comunicación.`,
      3: `Atención. Contactar personal. El sitio ${evt.siteName} lleva ${evt.minutesDown} minutos sin comunicación.`,
      4: `Urgencia. Acudir a sitio. El sitio ${evt.siteName} lleva más de una hora sin comunicación.`,
    };
    try {
      const utter = new SpeechSynthesisUtterance(messages[evt.level] || messages[1]);
      utter.lang = 'es-MX';
      utter.rate = 0.95;
      speechSynthesis.speak(utter);
    } catch (_) { /* no crítico */ }
  }

  const activeEscalations = new Map(); // siteId -> evt

  function renderEscalationBar() {
    if (activeEscalations.size === 0) {
      escalationBar.style.display = 'none';
      escalationBar.innerHTML = '';
      return;
    }
    escalationBar.style.display = 'flex';
    const rows = Array.from(activeEscalations.values()).sort((a, b) => b.level - a.level);
    escalationBar.innerHTML = rows.map((e) => `
      <div class="escalation-row esc-${e.level}">
        <span>🚨 <b>${escapeHtml(e.label.toUpperCase())}</b> — ${escapeHtml(e.siteName)} (${escapeHtml(e.ip)}) lleva ${e.minutesDown} min sin comunicación</span>
        <span class="esc-time">${new Date(e.ts).toLocaleTimeString('es-MX')}</span>
        <button class="esc-dismiss" data-dismiss-site="${escapeHtml(e.siteId)}" type="button">Reconocer ✕</button>
      </div>
    `).join('');
    escalationBar.querySelectorAll('[data-dismiss-site]').forEach((btn) => {
      btn.addEventListener('click', () => {
        activeEscalations.delete(btn.getAttribute('data-dismiss-site'));
        renderEscalationBar();
      });
    });
  }

  socket.on('site:escalation', (evt) => {
    activeEscalations.set(evt.siteId, evt);
    renderEscalationBar();
    playEscalationSound(evt.level);
    speakEscalation(evt);
    if ('Notification' in window && Notification.permission === 'granted') {
      const n = new Notification(`🚨 ${evt.label} — ${evt.siteName}`, {
        body: `${evt.ip} · lleva ${evt.minutesDown} minutos sin comunicación`,
        icon: '/assets/skysense-mark.png',
        requireInteraction: evt.level >= 2,
        tag: `escalation-${evt.siteId}`,
      });
      n.onclick = () => { window.focus(); n.close(); };
    }
  });

  socket.on('site:statusChange', (evt2) => {
    if (evt2.to === 'online' && activeEscalations.has(evt2.siteId)) {
      activeEscalations.delete(evt2.siteId);
      renderEscalationBar();
    }
  });

  // ---------- Ranking de sitios problemáticos ----------

  const STATUS_DOT = { online: '🟢', intermittent: '🟡', offline: '🔴', unknown: '⚪' };

  // ---------- Reporte de sitios sin comunicación ----------

  let lastOutageText = '';

  async function loadOutageReport() {
    try {
      const resp = await fetch('/api/outage-report');
      const report = await resp.json();
      lastOutageText = report.text;

      let html = '';
      if (report.offlineCount === 0) {
        html += `<span class="ok-line">✅ Los ${report.totalSites} sitios están en línea. Sin caídas activas.</span>`;
      } else {
        const lines = report.sites.map((s) =>
          `<span class="down-line">🔴 ${escapeHtml(s.name)} (${escapeHtml(s.ip)})</span>${s.city ? ' · ' + escapeHtml(s.city) : ''} — sin comunicación desde las ${new Date(s.since).toLocaleTimeString('es-MX')} (hace ${escapeHtml(s.durationText)})${s.note ? `\n   📝 ${escapeHtml(s.note)}` : ''}`
        );
        html +=
          `${report.offlineCount} de ${report.totalSites} sitios sin comunicación:\n\n` +
          lines.join('\n') +
          `\n\n<span class="ok-line">✅ Los otros ${report.onlineCount} sitios están en línea.</span>`;
      }

      if (report.maintenanceCount > 0) {
        const typeIcon = { mantenimiento: '🔧', fuera_operacion: '⚫', sin_comunicacion: '🔕' };
        const typeLabel = { mantenimiento: 'en mantenimiento', fuera_operacion: 'fuera de operación', sin_comunicacion: 'sin comunicación conocida (silenciado)' };
        const maintLines = report.maintenanceSites.map((s) => {
          const icon = typeIcon[s.maintenanceType] || '🔧';
          const label = typeLabel[s.maintenanceType] || 'en mantenimiento';
          return `<span class="maint-line">${icon} ${escapeHtml(s.name)} (${escapeHtml(s.ip)})</span> — ${label}${s.maintenanceNote ? ': ' + escapeHtml(s.maintenanceNote) : ''} (desde hace ${escapeHtml(s.durationText)})`;
        });
        html += `\n\n<span class="maint-header">📌 Marcados como conocidos (no cuentan como falla nueva):</span>\n\n${maintLines.join('\n')}`;
      }

      outageReportBody.innerHTML = html;
    } catch (_) {
      outageReportBody.textContent = 'No se pudo cargar el reporte.';
    }
  }

  refreshOutageBtn.addEventListener('click', loadOutageReport);

  copyOutageBtn.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(lastOutageText);
      outageReportStatus.textContent = 'Copiado ✓ — dale a "🔗 Abrir Teams" y pégalo (Ctrl+V) en tu canal';
    } catch (_) {
      outageReportStatus.textContent = 'No se pudo copiar. Selecciona el texto manualmente.';
    }
  });

  loadOutageReport();
  setInterval(loadOutageReport, 30000);

  async function loadRanking() {
    const days = rankingPeriod.value;
    try {
      const resp = await fetch(`/api/ranking?days=${days}`);
      const rows = await resp.json();
      renderRanking(rows);
    } catch (_) {
      rankingTable.innerHTML = '<p style="color:var(--text-faint);font-size:11px;">No se pudo cargar el ranking.</p>';
    }
  }

  function renderRanking(rows) {
    const top = rows.slice(0, 10);
    if (top.length === 0 || top.every((r) => r.drops === 0)) {
      rankingTable.innerHTML = '<p style="color:var(--text-faint);font-size:11px;">Sin caídas registradas en este periodo.</p>';
      return;
    }
    rankingTable.innerHTML = top.map((r, i) => `
      <div class="ranking-row ${r.drops > 0 ? 'has-drops' : ''}">
        <span class="rank-pos">${i + 1}.</span>
        <span>${STATUS_DOT[r.currentStatus] || '⚪'}</span>
        <span class="rank-name" title="${escapeHtml(r.name)} (${r.ip})">${escapeHtml(r.name)}</span>
        <span class="rank-drops">${r.drops} caídas</span>
        <span class="rank-uptime">${r.uptimePct != null ? r.uptimePct + '%' : '—'}</span>
      </div>
    `).join('');
  }

  function updateExportLinks() {
    const days = rankingPeriod.value;
    exportRankingBtn.href = `/api/export/ranking.csv?days=${days}`;
    exportEventsBtn.href = `/api/export/events.csv?days=${days}`;
  }

  rankingPeriod.addEventListener('change', () => {
    loadRanking();
    updateExportLinks();
  });

  updateExportLinks();
  loadRanking();
  setInterval(loadRanking, 30000);

  // ---------- Modal de configuración de alertas Teams ----------

  async function openSettingsModal() {
    modalStatus.textContent = '';
    try {
      const resp = await fetch('/api/alerts-config');
      const cfg = await resp.json();
      teamsWebhookInput.value = '';
      teamsWebhookInput.placeholder = cfg.teamsConfigured
        ? 'Ya configurado — pega una nueva URL para reemplazarla'
        : 'https://…';
      notifyOfflineCheck.checked = cfg.notifyOnOffline;
      notifyRecoveryCheck.checked = cfg.notifyOnRecovery;
      notifyIntermittentCheck.checked = cfg.notifyOnIntermittent;
      settingsLabel.textContent = cfg.teamsConfigured ? 'Alertas Teams ✓' : 'Alertas Teams';
      settingsBtn.classList.toggle('active', cfg.teamsConfigured);
    } catch (_) { /* se abre igual con valores por defecto */ }
    modalBackdrop.classList.add('open');
  }

  function closeSettingsModal() {
    modalBackdrop.classList.remove('open');
  }

  settingsBtn.addEventListener('click', openSettingsModal);
  modalCancelBtn.addEventListener('click', closeSettingsModal);
  modalBackdrop.addEventListener('click', (e) => { if (e.target === modalBackdrop) closeSettingsModal(); });

  modalSaveBtn.addEventListener('click', async () => {
    const body = {
      notifyOnOffline: notifyOfflineCheck.checked,
      notifyOnRecovery: notifyRecoveryCheck.checked,
      notifyOnIntermittent: notifyIntermittentCheck.checked,
    };
    if (teamsWebhookInput.value.trim()) {
      body.teamsWebhookUrl = teamsWebhookInput.value.trim();
    }
    modalStatus.textContent = 'Guardando…';
    try {
      const resp = await fetch('/api/alerts-config', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const data = await resp.json();
      modalStatus.textContent = data.teamsConfigured ? 'Guardado. Webhook configurado ✓' : 'Guardado (sin webhook).';
      settingsLabel.textContent = data.teamsConfigured ? 'Alertas Teams ✓' : 'Alertas Teams';
      settingsBtn.classList.toggle('active', data.teamsConfigured);
    } catch (_) {
      modalStatus.textContent = 'No se pudo guardar. Revisa que el servidor siga corriendo.';
    }
  });

  modalTestBtn.addEventListener('click', async () => {
    modalStatus.textContent = 'Enviando mensaje de prueba a Teams…';
    try {
      const resp = await fetch('/api/alerts-test', { method: 'POST' });
      const data = await resp.json();
      if (data.error) modalStatus.textContent = `Error: ${data.error}`;
      else if (data.ok) modalStatus.textContent = 'Prueba enviada. Revisa el canal de Teams ✓';
      else modalStatus.textContent = `No se pudo enviar (${data.status || data.error || 'error desconocido'}).`;
    } catch (_) {
      modalStatus.textContent = 'No se pudo enviar la prueba.';
    }
  });

  // ---------- Modal de detalle de sitio (acceso directo al HMI) ----------

  const HTTP_SCADA_PORTS = [7000, 7010, 7020];
  const VNC_PORTS = [5900, 6000];
  let currentDetailSite = null;

  function computeAccess(site) {
    if (!site || !site.port) return null;
    if (HTTP_SCADA_PORTS.includes(site.port)) {
      return { type: 'http', url: `http://${site.ip}:${site.port}` };
    }
    if (VNC_PORTS.includes(site.port)) {
      return { type: 'vnc', url: `vnc://${site.ip}:${site.port}` };
    }
    return null;
  }

  function openSiteDetailModal(site) {
    if (!site) return;
    currentDetailSite = site;

    siteModalName.textContent = site.name;
    siteModalMeta.textContent = `${site.ip}${site.port ? ':' + site.port : ''}${site.address ? ' · 📍 ' + site.address : (site.city ? ' · ' + site.city : '')}`;

    siteModalStatus.className = `status-pill ${site.status}`;
    siteModalStatus.textContent = STATUS_TEXT[site.status] || site.status;

    siteModalLatency.textContent = site.latencyMs != null ? `${Math.round(site.latencyMs)} ms` : '—';
    siteModalUptime.textContent = site.uptimePct != null ? `${site.uptimePct}%` : '—';

    if (site.hasScada && site.scada) {
      const { soc, summary } = extractSocAndSummary(site.scada);
      const temp = summary == null ? firstDefined(site.scada, ['tempC', 'temperature', 'temp', 'temp_c']) : null;
      siteModalScada.textContent = `${soc != null ? soc + '%' : '—'}${temp != null ? ' · ' + temp + '°C' : ''}${summary ? ' · ' + summary : ''}`;

      if (site.scada.fields && site.scada.fields.length) {
        siteModalFieldsWrap.style.display = 'block';
        const statusBanner = site.scada.status
          ? `<div class="site-modal-status-banner ${site.scada.status}">${STATUS_ES[site.scada.status] || site.scada.status}</div>`
          : '';
        siteModalFieldsList.innerHTML = statusBanner + site.scada.fields.map((f) => {
          const isColor = f.kind === 'color-status';
          const displayValue = f.value == null
            ? 'sin lectura'
            : (isColor ? (STATUS_ES[f.value] || f.value) : f.value + (f.unit || ''));
          const colorClass = isColor && f.value ? ` field-status-${f.value}` : '';
          return `
          <div class="site-modal-field-card">
            <span class="f-label">${escapeHtml(f.label)}</span>
            <span class="f-value ${f.value == null ? 'no-data' : ''}${colorClass}">${displayValue}</span>
          </div>
        `;
        }).join('');
      } else {
        siteModalFieldsWrap.style.display = 'none';
      }
    } else {
      siteModalScada.textContent = 'Sin SCADA conectado todavía';
      siteModalFieldsWrap.style.display = 'none';
    }

    const access = computeAccess(site);
    siteModalHttpAccess.style.display = 'none';
    siteModalVncAccess.style.display = 'none';
    siteModalPreviewWrap.style.display = 'none';
    siteModalIframe.src = 'about:blank';

    loadSiteStability(site.id);
    loadSiteHeatmap(site.id);
    renderMaintenanceDisplay(site);
    renderAssignmentDisplay(site);
    maintenanceForm.style.display = 'none';
    assignmentForm.style.display = 'none';
    loadLatencyChart(site.id);

    if (access && access.type === 'http') {
      siteModalHttpAccess.style.display = 'flex';
      siteModalOpenBtn.href = access.url;
      siteModalPreviewBtn.onclick = () => {
        siteModalIframe.src = access.url;
        siteModalPreviewWrap.style.display = 'block';
      };
    } else if (access && access.type === 'vnc') {
      siteModalVncAccess.style.display = 'block';
      siteModalVncPort.textContent = site.port;
      siteModalVncBtn.href = access.url;
    }

    siteModalBackdrop.classList.add('open');
  }

  function closeSiteModal() {
    siteModalBackdrop.classList.remove('open');
    siteModalIframe.src = 'about:blank'; // detiene la carga al cerrar
  }

  siteModalCloseBtn.addEventListener('click', closeSiteModal);
  siteModalBackdrop.addEventListener('click', (e) => {
    if (e.target === siteModalBackdrop) closeSiteModal();
  });
  siteModalCalibrateBtn.addEventListener('click', () => {
    if (currentDetailSite) openVisionModal(currentDetailSite);
  });

  // ---------- Calibración visual (OCR) de campos personalizados ----------

  const FIELD_COLORS = ['#4fd1e8', '#f5a623', '#33d17a', '#ff6b9d', '#a78bfa', '#f97316', '#38bdf8', '#facc15'];

  let visionFields = []; // [{id, label, kind, unit, region, navigation}]
  let visionPicking = false;
  let visionPickPoints = [];
  let visionPendingFieldMeta = null; // {label, kind, unit, navigation} mientras se marca
  let visionImgNatural = { width: 0, height: 0 };
  let visionSiteId = null;
  let visionLastNav = [];

  async function openVisionModal(site) {
    visionSiteId = site.id;
    visionModalName.textContent = `Calibrar — ${site.name}`;
    visionStatus.textContent = '';
    visionPicking = false;
    visionPickPoints = [];
    visionPendingFieldMeta = null;
    visionFields = [];
    visionFieldLabel.value = '';
    visionFieldUnit.value = '';
    visionFieldNav.value = '';
    visionFieldKind.value = 'generic';
    visionModalBackdrop.classList.add('open');

    try {
      const resp = await fetch(`/api/vision/fields/${site.id}`);
      const fields = await resp.json();
      if (Array.isArray(fields)) visionFields = fields;
    } catch (_) { /* sin calibración previa */ }

    renderFieldsList();
    refreshVisionScreenshot([]);
  }

  function fieldColor(index) {
    return FIELD_COLORS[index % FIELD_COLORS.length];
  }

  let visionCurrentObjectUrl = null;

  async function refreshVisionScreenshot(navSteps) {
    const nav = navSteps !== undefined ? navSteps : [];
    visionLastNav = nav;
    visionStatus.textContent = nav.length
      ? `Navegando (${nav.join(' → ')}) y cargando captura (puede tardar hasta 40 segundos)…`
      : 'Cargando captura de la pantalla (puede tardar hasta 40 segundos)…';
    try {
      const navParam = nav.length ? `&nav=${encodeURIComponent(nav.join(','))}` : '';
      const resp = await fetch(`/api/vision/screenshot/${visionSiteId}?t=${Date.now()}${navParam}`);
      if (!resp.ok) {
        let msg = `Error del servidor (${resp.status})`;
        try { const data = await resp.json(); if (data.error) msg = data.error; } catch (_) {}
        visionStatus.textContent = msg;
        return;
      }
      const blob = await resp.blob();
      if (visionCurrentObjectUrl) URL.revokeObjectURL(visionCurrentObjectUrl);
      visionCurrentObjectUrl = URL.createObjectURL(blob);
      visionScreenshotImg.src = visionCurrentObjectUrl;
    } catch (err) {
      visionStatus.textContent = `No se pudo conectar con el servidor: ${err.message}`;
    }
  }

  visionScreenshotImg.addEventListener('load', () => {
    visionImgNatural = { width: visionScreenshotImg.naturalWidth, height: visionScreenshotImg.naturalHeight };
    if (visionImgNatural.width > 0) {
      visionStatus.textContent = '✓ Captura cargada. Si se ve en blanco o incompleta, dale clic a "🔄 Actualizar captura" otra vez (la pantalla puede tardar en dibujarse).';
      drawFieldBoxes();
    }
  });
  visionScreenshotImg.addEventListener('error', () => {
    visionStatus.textContent = 'La imagen recibida no se pudo mostrar (formato inesperado).';
  });

  function drawFieldBoxes() {
    visionFieldBoxes.innerHTML = '';
    if (!visionImgNatural.width) return;
    const scale = visionScreenshotImg.clientWidth / visionImgNatural.width;
    visionFields.forEach((field, i) => {
      // Solo se dibuja si su ruta de navegación coincide con la que se está viendo ahora
      const sameNav = JSON.stringify(field.navigation || []) === JSON.stringify(visionLastNav || []);
      if (!sameNav) return;
      const box = document.createElement('div');
      box.className = 'vision-region-box dynamic';
      box.style.setProperty('--box-color', fieldColor(i));
      box.style.setProperty('--box-bg', fieldColor(i) + '2e');
      box.style.left = `${field.region.x * scale}px`;
      box.style.top = `${field.region.y * scale}px`;
      box.style.width = `${field.region.width * scale}px`;
      box.style.height = `${field.region.height * scale}px`;
      const tag = document.createElement('span');
      tag.className = 'box-tag';
      tag.textContent = field.label;
      box.appendChild(tag);
      visionFieldBoxes.appendChild(box);
    });
  }

  visionMarkFieldBtn.addEventListener('click', () => {
    const label = visionFieldLabel.value.trim();
    if (!label) {
      visionStatus.textContent = 'Escribe un nombre para el campo antes de marcarlo (ej. "BESS 1 - SOC").';
      return;
    }
    visionPendingFieldMeta = {
      label,
      kind: visionFieldKind.value,
      unit: visionFieldUnit.value.trim(),
      navigation: visionFieldNav.value.split(',').map((s) => s.trim()).filter(Boolean),
    };
    visionPicking = true;
    visionPickPoints = [];
    visionStatus.textContent = `Marcando "${label}": haz clic en la esquina superior izquierda del número.`;
  });

  visionScreenshotImg.addEventListener('click', (e) => {
    if (!visionPicking || !visionImgNatural.width) return;
    const rect = visionScreenshotImg.getBoundingClientRect();
    const scale = visionImgNatural.width / rect.width;
    const x = (e.clientX - rect.left) * scale;
    const y = (e.clientY - rect.top) * scale;
    visionPickPoints.push({ x, y });

    if (visionPickPoints.length === 1) {
      visionStatus.textContent = 'Ahora haz clic en la esquina inferior derecha.';
      return;
    }

    const [p1, p2] = visionPickPoints;
    const region = {
      x: Math.round(Math.min(p1.x, p2.x)),
      y: Math.round(Math.min(p1.y, p2.y)),
      width: Math.round(Math.abs(p2.x - p1.x)),
      height: Math.round(Math.abs(p2.y - p1.y)),
    };

    visionFields.push({
      id: `f${Date.now()}${Math.floor(Math.random() * 1000)}`,
      label: visionPendingFieldMeta.label,
      kind: visionPendingFieldMeta.kind,
      unit: visionPendingFieldMeta.unit,
      navigation: visionPendingFieldMeta.navigation,
      region,
    });

    visionStatus.textContent = `"${visionPendingFieldMeta.label}" marcado. Puedes agregar otro campo o guardar.`;
    visionFieldLabel.value = '';
    visionFieldUnit.value = '';
    visionFieldNav.value = '';
    visionPicking = false;
    visionPickPoints = [];
    visionPendingFieldMeta = null;
    drawFieldBoxes();
    renderFieldsList();
  });

  function renderFieldsList() {
    if (visionFields.length === 0) {
      visionFieldsList.innerHTML = '<p style="color:var(--text-faint);font-size:11.5px;">Todavía no has marcado ningún campo.</p>';
      return;
    }
    visionFieldsList.innerHTML = visionFields.map((f, i) => `
      <div class="vision-field-row" data-field-id="${f.id}">
        <span class="field-color-dot" style="background:${fieldColor(i)}"></span>
        <span class="field-name">${escapeHtml(f.label)}</span>
        <span class="field-meta">${f.kind}${f.unit ? ' · ' + escapeHtml(f.unit) : ''}${(f.navigation || []).length ? ' · vía ' + escapeHtml(f.navigation.join(' → ')) : ''}</span>
        <span class="field-live-value" data-live-for="${f.id}">—</span>
        <button class="field-remove-btn" data-test="${f.id}" title="Probar lectura">▶</button>
        <button class="field-remove-btn" data-remove="${f.id}" title="Quitar">🗑</button>
      </div>
    `).join('');

    visionFieldsList.querySelectorAll('[data-test]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const id = btn.getAttribute('data-test');
        const field = visionFields.find((f) => f.id === id);
        if (!field) return;
        const valueEl = visionFieldsList.querySelector(`[data-live-for="${id}"]`);
        valueEl.textContent = 'leyendo…';
        try {
          const resp = await fetch(`/api/vision/test-field/${visionSiteId}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ region: field.region, navigation: field.navigation || [], kind: field.kind }),
          });
          const data = await resp.json();
          if (data.error) { valueEl.textContent = 'error'; valueEl.title = data.error; return; }
          valueEl.textContent = data.value != null ? `${data.value}${field.kind === 'color-status' ? '' : (field.unit || '')}` : 'sin lectura';
          valueEl.title = `visto: "${data.raw || ''}"`;
        } catch (_) {
          valueEl.textContent = 'error';
        }
      });
    });

    visionFieldsList.querySelectorAll('[data-remove]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const id = btn.getAttribute('data-remove');
        visionFields = visionFields.filter((f) => f.id !== id);
        drawFieldBoxes();
        renderFieldsList();
      });
    });
  }

  visionRefreshBtn.addEventListener('click', () => refreshVisionScreenshot([]));

  visionNavPreviewBtn.addEventListener('click', () => {
    const nav = visionFieldNav.value.split(',').map((s) => s.trim()).filter(Boolean);
    refreshVisionScreenshot(nav);
  });

  visionSaveBtn.addEventListener('click', async () => {
    visionStatus.textContent = 'Guardando…';
    try {
      await fetch(`/api/vision/fields/${visionSiteId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fields: visionFields }),
      });
      visionStatus.textContent = `Guardado ✓ — ${visionFields.length} campo(s). La lectura automática empieza en el próximo ciclo (hasta 1 minuto).`;
    } catch (_) {
      visionStatus.textContent = 'No se pudo guardar la calibración.';
    }
  });

  visionClearBtn.addEventListener('click', async () => {
    if (visionFields.length && !confirm(`¿Quitar los ${visionFields.length} campos calibrados de este sitio?`)) return;
    visionStatus.textContent = 'Quitando calibración…';
    try {
      await fetch(`/api/vision/fields/${visionSiteId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fields: [] }),
      });
      visionFields = [];
      drawFieldBoxes();
      renderFieldsList();
      visionStatus.textContent = 'Calibración eliminada. Este sitio ya no se leerá automáticamente.';
    } catch (_) {
      visionStatus.textContent = 'No se pudo quitar la calibración.';
    }
  });

  function closeVisionModal() {
    visionModalBackdrop.classList.remove('open');
    visionScreenshotImg.src = '';
  }
  visionCloseBtn.addEventListener('click', closeVisionModal);
  visionModalBackdrop.addEventListener('click', (e) => {
    if (e.target === visionModalBackdrop) closeVisionModal();
  });

  // ---------- Credenciales SkySense (para el auto-login del lector visual) ----------

  async function refreshScadaAuthLabel() {
    try {
      const resp = await fetch('/api/scada-auth');
      const data = await resp.json();
      scadaAuthLabel.textContent = data.configured ? 'Acceso SkySense ✓' : 'Acceso SkySense';
      scadaAuthBtn.classList.toggle('active', data.configured);
    } catch (_) { /* no crítico */ }
  }
  refreshScadaAuthLabel();

  scadaAuthBtn.addEventListener('click', () => {
    scadaUserInput.value = '';
    scadaPassInput.value = '';
    scadaAuthStatus.textContent = '';
    scadaAuthModalBackdrop.classList.add('open');
  });
  scadaAuthCancelBtn.addEventListener('click', () => scadaAuthModalBackdrop.classList.remove('open'));
  scadaAuthModalBackdrop.addEventListener('click', (e) => {
    if (e.target === scadaAuthModalBackdrop) scadaAuthModalBackdrop.classList.remove('open');
  });

  scadaAuthSaveBtn.addEventListener('click', async () => {
    scadaAuthStatus.textContent = 'Guardando…';
    try {
      const resp = await fetch('/api/scada-auth', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: scadaUserInput.value, password: scadaPassInput.value }),
      });
      const data = await resp.json();
      scadaAuthStatus.textContent = data.configured ? 'Guardado ✓' : 'Guardado (incompleto).';
      refreshScadaAuthLabel();
    } catch (_) {
      scadaAuthStatus.textContent = 'No se pudo guardar.';
    }
  });

  // ---------- Explorador de historial completo ----------

  const HISTORY_TYPE_LABEL = { offline: 'Caída', online: 'Recuperación', intermittent: 'Intermitencia' };
  let historyDaysFilter = 1; // 0 = todo

  function populateHistorySiteOptions() {
    const current = historySite.value;
    const opts = ['<option value="all">Todos los sitios</option>'];
    Array.from(cards.keys())
      .map((id) => ({ id, name: cards.get(id).el.querySelector('.site-name').textContent }))
      .sort((a, b) => a.name.localeCompare(b.name))
      .forEach((s) => opts.push(`<option value="${s.id}">${escapeHtml(s.name)}</option>`));
    historySite.innerHTML = opts.join('');
    if (current) historySite.value = current;
  }

  function buildHistoryQuery(forExport) {
    const params = new URLSearchParams();
    if (historySite.value && historySite.value !== 'all') params.set('siteId', historySite.value);
    if (historyType.value && historyType.value !== 'all') params.set('type', historyType.value);
    if (historyDaysFilter > 0) {
      params.set('from', String(Date.now() - historyDaysFilter * 24 * 60 * 60 * 1000));
    }
    if (!forExport) params.set('limit', '2000');
    return params.toString();
  }

  async function loadHistoryTable() {
    historyTableBody.innerHTML = '<tr><td colspan="6" class="history-empty">Cargando…</td></tr>';
    try {
      const resp = await fetch(`/api/events?${buildHistoryQuery(false)}`);
      let rows = await resp.json();

      const term = historySearch.value.trim().toLowerCase();
      if (term) {
        rows = rows.filter((r) =>
          `${r.siteName} ${r.ip} ${r.message}`.toLowerCase().includes(term)
        );
      }

      historyCount.textContent = `${rows.length} evento${rows.length === 1 ? '' : 's'}`;

      if (rows.length === 0) {
        historyTableBody.innerHTML = '<tr><td colspan="6" class="history-empty">Sin eventos para estos filtros.</td></tr>';
        return;
      }

      historyTableBody.innerHTML = rows.map((r) => `
        <tr>
          <td>${new Date(r.ts).toLocaleString('es-MX')}</td>
          <td>${escapeHtml(r.siteName)}</td>
          <td>${escapeHtml(r.ip)}</td>
          <td><span class="history-badge ${r.to}">${HISTORY_TYPE_LABEL[r.to] || r.to}</span></td>
          <td>${r.durationMs != null ? formatDurationClient(r.durationMs) : '—'}</td>
          <td>
            <button class="note-btn ${r.note ? 'has-note' : ''}" data-event-id="${escapeHtml(r.id)}" data-current-note="${escapeHtml(r.note || '')}" title="${r.note ? escapeHtml(r.note) : 'Agregar nota'}">
              ${r.note ? '📝 ' + escapeHtml(r.note.slice(0, 24)) + (r.note.length > 24 ? '…' : '') : '+ nota'}
            </button>
          </td>
        </tr>
      `).join('');

      historyTableBody.querySelectorAll('.note-btn').forEach((btn) => {
        btn.addEventListener('click', async () => {
          const eventId = btn.getAttribute('data-event-id');
          const current = btn.getAttribute('data-current-note');
          const next = prompt('Nota para este evento (causa, quién lo atendió, etc.):', current);
          if (next === null) return; // canceló
          try {
            await fetch(`/api/events/${encodeURIComponent(eventId)}/note`, {
              method: 'PUT',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ note: next.trim() }),
            });
            refreshHistoryView();
          } catch (_) { /* no crítico */ }
        });
      });
    } catch (_) {
      historyTableBody.innerHTML = '<tr><td colspan="6" class="history-empty">No se pudo cargar el historial.</td></tr>';
    }
  }

  function formatDurationClient(ms) {
    const totalMin = Math.round(ms / 60000);
    if (totalMin < 1) return '<1 min';
    if (totalMin < 60) return `${totalMin} min`;
    const h = Math.floor(totalMin / 60);
    const m = totalMin % 60;
    return m ? `${h}h ${m}min` : `${h}h`;
  }

  function updateHistoryExportLink() {
    historyExportBtn.href = `/api/export/events.csv?${buildHistoryQuery(true)}`;
  }

  function refreshHistoryView() {
    loadHistoryTable();
    updateHistoryExportLink();
  }

  openHistoryBtn.addEventListener('click', () => {
    populateHistorySiteOptions();
    historyModalBackdrop.classList.add('open');
    refreshHistoryView();
  });
  historyCloseBtn.addEventListener('click', () => {
    historyModalBackdrop.classList.remove('open');
    if (document.fullscreenElement === historyModalEl) document.exitFullscreen().catch(() => {});
  });
  historyModalBackdrop.addEventListener('click', (e) => {
    if (e.target === historyModalBackdrop) historyModalBackdrop.classList.remove('open');
  });

  // ---------- Expandir historial ----------

  const historyExpandBtn = document.getElementById('historyExpandBtn');
  const historyModalEl = historyModalBackdrop.querySelector('.modal-wide');

  function setHistoryExpandLabel(isExpanded) {
    historyExpandBtn.innerHTML = isExpanded ? '⤡ Reducir' : '⛶ Expandir';
  }

  historyExpandBtn.addEventListener('click', () => {
    if (document.fullscreenElement) {
      document.exitFullscreen().catch(() => {});
    } else if (historyModalEl.requestFullscreen) {
      historyModalEl.requestFullscreen().catch(() => {
        historyModalEl.classList.toggle('expanded');
        setHistoryExpandLabel(historyModalEl.classList.contains('expanded'));
      });
    } else {
      historyModalEl.classList.toggle('expanded');
      setHistoryExpandLabel(historyModalEl.classList.contains('expanded'));
    }
  });

  document.addEventListener('fullscreenchange', () => {
    if (document.fullscreenElement === historyModalEl) {
      setHistoryExpandLabel(true);
    } else if (!document.fullscreenElement) {
      setHistoryExpandLabel(false);
      historyModalEl.classList.remove('expanded');
    }
  });

  historySite.addEventListener('change', refreshHistoryView);
  historyType.addEventListener('change', refreshHistoryView);
  let searchDebounce = null;
  historySearch.addEventListener('input', () => {
    clearTimeout(searchDebounce);
    searchDebounce = setTimeout(refreshHistoryView, 250);
  });

  document.querySelectorAll('.preset-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      presetBtns().forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');
      historyDaysFilter = parseInt(btn.dataset.days, 10);
      refreshHistoryView();
    });
  });

  // ---------- Agrupación por zona / ciudad ----------

  function regroupGrid() {
    grid.querySelectorAll('.group-header').forEach((h) => h.remove());
    const groupBy = groupBySelect.value;

    const sortByName = (a, b) =>
      a.el.querySelector('.site-name').textContent.localeCompare(b.el.querySelector('.site-name').textContent);

    if (groupBy === 'none') {
      Array.from(cards.values()).sort(sortByName).forEach((c) => grid.appendChild(c.el));
      return;
    }

    const groups = new Map();
    cards.forEach((card) => {
      const site = card.lastSite || {};
      const key = (groupBy === 'group' ? site.group : site.city) || 'Sin asignar';
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(card);
    });

    Array.from(groups.keys()).sort().forEach((key) => {
      const header = document.createElement('div');
      header.className = 'group-header';
      const list = groups.get(key).sort(sortByName);
      header.innerHTML = `<span>${escapeHtml(key)}</span><span class="group-count">${list.length} sitio${list.length === 1 ? '' : 's'}</span>`;
      grid.appendChild(header);
      list.forEach((c) => grid.appendChild(c.el));
    });
  }

  groupBySelect.addEventListener('change', regroupGrid);

  // ---------- Mapa ----------

  async function loadUptime7d() {
    try {
      const resp = await fetch('/api/ranking?days=7');
      const rows = await resp.json();
      uptime7dBySite = Object.fromEntries(rows.map((r) => [r.id, r.uptimePct]));
    } catch (_) {
      uptime7dBySite = {};
    }
  }

  function uptimeRingClass(uptimePct) {
    if (uptimePct == null) return 'ring-unknown';
    if (uptimePct >= 99) return 'ring-good';
    if (uptimePct >= 95) return 'ring-warn';
    return 'ring-bad';
  }

  async function checkStorm(site, atTs) {
    if (!site.city) return null;
    const hourBucket = Math.floor(atTs / (60 * 60 * 1000));
    const key = `${site.city}|${hourBucket}`;
    if (stormCache.has(key)) return stormCache.get(key);
    try {
      const resp = await fetch(`/api/weather/storm-check?city=${encodeURIComponent(site.city)}&ts=${atTs}`);
      const data = await resp.json();
      stormCache.set(key, data);
      return data;
    } catch (_) {
      return null;
    }
  }

  function jitter(siteId, base) {
    // Pequeño desplazamiento determinístico para que sitios en la misma
    // ciudad no queden exactamente encimados — radio chico (unos cientos de
    // metros) para que no se salgan del terreno real (aeropuerto, parque
    // industrial, etc.) hacia el mar u otras zonas sin sentido.
    let hash = 0;
    for (let i = 0; i < siteId.length; i++) hash = (hash * 31 + siteId.charCodeAt(i)) % 10000;
    const angle = (hash / 10000) * Math.PI * 2;
    const radius = 0.003 + (hash % 5) * 0.0015;
    return base + Math.cos(angle) * radius;
  }

  const MAINT_MAP_CLASS = { mantenimiento: 'maintenance', fuera_operacion: 'outofservice', sin_comunicacion: 'knownissue' };

  function statusColorClass(status, maintenance) {
    if (maintenance) return MAINT_MAP_CLASS[maintenance.type] || 'maintenance';
    return ['online', 'offline', 'intermittent'].includes(status) ? status : 'unknown';
  }

  async function loadWeather() {
    try {
      const resp = await fetch('/api/weather');
      weatherByCity = await resp.json();
    } catch (_) {
      weatherByCity = {};
    }
  }

  function updateMapStats() {
    let online = 0, offline = 0, intermittent = 0, total = 0;
    cards.forEach((card) => {
      if (!card.lastSite || card.lastSite.lat == null) return;
      total++;
      if (card.lastSite.status === 'online') online++;
      else if (card.lastSite.status === 'offline') offline++;
      else if (card.lastSite.status === 'intermittent') intermittent++;
    });
    const statsEl = document.getElementById('mapStatsBar');
    if (statsEl) {
      statsEl.innerHTML = `
        <span class="map-stat grid-live-stat">⚡ ${online} interconectados a la microred SkySense</span>
        <span class="map-stat">${total} sitios en el mapa</span>
        <span class="map-stat intermittent"><b>${intermittent}</b> intermitentes</span>
        <span class="map-stat offline"><b>${offline}</b> desconectados</span>
      `;
    }
  }

  function tileUrlForTheme(theme) {
    return theme === 'light'
      ? 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png'
      : 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png';
  }

  function setMapTheme(theme) {
    if (!leafletMap || !mapTileLayer) return; // el mapa aún no se ha abierto, no hay nada que cambiar
    mapTileLayer.setUrl(tileUrlForTheme(theme));
  }

  async function openMapModal() {
    mapModalBackdrop.classList.add('open');
    await Promise.all([loadWeather(), loadUptime7d()]);
    setTimeout(() => {
      if (!leafletMap) {
        leafletMap = L.map('mapContainer', { zoomControl: true }).setView([23.6345, -102.5528], 5);
        mapTileLayer = L.tileLayer(tileUrlForTheme(currentTheme), {
          attribution: '© OpenStreetMap, © CARTO',
          maxZoom: 18,
        }).addTo(leafletMap);
      }
      leafletMap.invalidateSize();
      renderMapMarkers();
      updateMapStats();
    }, 50);
  }

  const WEATHER_ICONS = {
    'Despejado': '☀️', 'Mayormente despejado': '🌤', 'Parcialmente nublado': '⛅', 'Nublado': '☁️',
    'Neblina': '🌫', 'Neblina helada': '🌫',
    'Llovizna ligera': '🌦', 'Llovizna': '🌦', 'Llovizna densa': '🌧',
    'Lluvia ligera': '🌧', 'Lluvia': '🌧', 'Lluvia fuerte': '🌧',
    'Nieve ligera': '🌨', 'Nieve': '❄️', 'Nieve fuerte': '❄️',
    'Chubascos ligeros': '🌦', 'Chubascos': '🌧', 'Chubascos fuertes': '⛈',
    'Tormenta': '⛈', 'Tormenta con granizo': '⛈', 'Tormenta fuerte con granizo': '⛈',
  };

  const GROUP_BADGE_CLASS = { ASUR: 'badge-asur', OMA: 'badge-oma', Industria: 'badge-industria' };

  let mapRenderInProgress = false;
  let mapRenderQueued = false;

  async function renderMapMarkers() {
    if (!leafletMap) return;
    if (mapRenderInProgress) {
      // Ya hay un redibujado en curso (esperando datos de clima/tormenta) —
      // en vez de encimarse y dejar marcadores duplicados, se marca que hace
      // falta uno más después de que termine este.
      mapRenderQueued = true;
      return;
    }
    mapRenderInProgress = true;
    try {
      await renderMapMarkersInner();
    } finally {
      mapRenderInProgress = false;
      if (mapRenderQueued) {
        mapRenderQueued = false;
        renderMapMarkers();
      }
    }
  }

  async function renderMapMarkersInner() {
    mapMarkers.forEach((m) => leafletMap.removeLayer(m));
    mapMarkers.clear();
    energyLayers.forEach((l) => leafletMap.removeLayer(l));
    energyLayers = [];

    const siteList = Array.from(cards.values()).map((c) => c.lastSite).filter((s) => s && s.lat != null);

    // Para los sitios caídos, se revisa por adelantado si había tormenta en
    // su zona en el momento en que se cayeron (usa el historial reciente).
    const stormBySite = {};
    await Promise.all(siteList
      .filter((s) => s.status === 'offline')
      .map(async (s) => {
        const evResp = await fetch(`/api/events?siteId=${s.id}&type=offline&limit=1`).catch(() => null);
        if (!evResp || !evResp.ok) return;
        const evs = await evResp.json();
        if (!evs.length) return;
        stormBySite[s.id] = await checkStorm(s, evs[0].ts);
      })
    );

    siteList.forEach((site) => {
      const lat = site.exactLocation ? site.lat : jitter(site.id + 'a', site.lat);
      const lng = site.exactLocation ? site.lng : jitter(site.id + 'b', site.lng);
      const statusClass = statusColorClass(site.status, site.maintenance);
      const ringClass = uptimeRingClass(uptime7dBySite[site.id]);
      const w = weatherByCity[site.city];
      const tempBadge = (w && w.tempC != null)
        ? `<div class="map-marker-temp">${WEATHER_ICONS[w.description] || '🌡'} ${w.tempC}°C</div>`
        : '';
      const icon = L.divIcon({
        className: '',
        html: `<div class="map-marker-ring ${ringClass}" style="position:relative;">${tempBadge}${statusClass === 'online' ? '<div class="map-marker-halo"></div>' : ''}<div class="map-marker ${statusClass}"></div></div>`,
        iconSize: [22, 22],
      });

      const weatherRow = w && w.tempC != null
        ? `<div class="popup-row popup-weather">
             <span>${WEATHER_ICONS[w.description] || '🌡'} ${w.tempC}°C</span>
             <span class="popup-dim">${escapeHtml(w.description || '')}</span>
           </div>`
        : '';

      const storm = stormBySite[site.id];
      const stormRow = storm && storm.stormy
        ? `<div class="popup-row popup-storm">⛈ Se cayó durante clima adverso en la zona${storm.windKph ? ` (viento ${storm.windKph} km/h)` : ''}</div>`
        : (site.status === 'offline' && storm
          ? `<div class="popup-row popup-dim">El clima estaba normal cuando se cayó — probable falla del sitio</div>`
          : '');

      const uptime7d = uptime7dBySite[site.id];
      const groupClass = GROUP_BADGE_CLASS[site.group] || 'badge-default';
      const groupBadge = site.group ? `<span class="popup-badge ${groupClass}">${escapeHtml(site.group)}</span>` : '';
      const locationLine = site.address
        ? `<div class="popup-row popup-address">📍 ${escapeHtml(site.address)}</div>`
        : (site.exactLocation ? `<div class="popup-row popup-dim">📍 ${site.lat.toFixed(5)}, ${site.lng.toFixed(5)}</div>` : '');

      const marker = L.marker([lat, lng], { icon, riseOnHover: true })
        .addTo(leafletMap)
        .on('click', () => {
          mapModalBackdrop.classList.remove('open');
          openSiteDetailModal(cards.get(site.id).lastSite);
        });

      marker.bindTooltip(`
        <div class="map-popup status-${statusClass}">
          <div class="popup-header">
            <b>${escapeHtml(site.name)}</b>
            <span class="popup-status-pill ${statusClass}">${STATUS_TEXT[site.status] || site.status}</span>
          </div>
          <div class="popup-row">
            <span>${escapeHtml(site.city || '')}</span>
            ${groupBadge}
          </div>
          <div class="popup-row popup-dim">${escapeHtml(site.ip)}</div>
          ${locationLine}
          <div class="popup-row popup-metrics">
            <span>📶 ${site.latencyMs != null ? Math.round(site.latencyMs) + ' ms' : '—'}</span>
            <span>📈 ${uptime7d != null ? uptime7d + '%' : '—'} en 7 días</span>
          </div>
          ${stormRow}
          ${weatherRow}
        </div>
      `, { direction: 'top', offset: [0, -12] });

      mapMarkers.set(site.id, marker);
    });

    // ---------- Microred: hub central SkySense + líneas de energía ----------
    const hubIcon = L.divIcon({
      className: '',
      html: `
        <div class="grid-hub-icon">
          <div class="grid-hub-ring r1"></div>
          <div class="grid-hub-ring r2"></div>
          <div class="grid-hub-ring r3"></div>
          <div class="grid-hub-core"></div>
          <div class="grid-hub-label">${GRID_HUB.label}</div>
        </div>`,
      iconSize: [16, 16],
    });
    const hubMarker = L.marker([GRID_HUB.lat, GRID_HUB.lng], { icon: hubIcon, interactive: false, zIndexOffset: 1000 }).addTo(leafletMap);
    energyLayers.push(hubMarker);

    siteList.forEach((site) => {
      const lat = site.exactLocation ? site.lat : jitter(site.id + 'a', site.lat);
      const lng = site.exactLocation ? site.lng : jitter(site.id + 'b', site.lng);
      const statusClass = statusColorClass(site.status, site.maintenance);
      const points = [[GRID_HUB.lat, GRID_HUB.lng], [lat, lng]];

      // Halo difuso detrás, para que la línea se sienta "energizada" y no plana.
      const glowLine = L.polyline(points, { className: 'energy-line-glow', interactive: false }).addTo(leafletMap);
      // Línea nítida encima, con el flujo animado.
      const flowLine = L.polyline(points, { className: `energy-line status-${statusClass}`, interactive: false }).addTo(leafletMap);
      energyLayers.push(glowLine, flowLine);
    });
  }


  // ---------- Línea de tiempo con reproducción ----------

  const PLAYBACK_WINDOW_MS = 24 * 60 * 60 * 1000; // 24 horas
  const PLAYBACK_STEPS = 288; // cada 5 minutos
  let playbackEventsBySite = null;
  let playbackWindowStart = null;
  let playbackTimer = null;

  function computeStatusAtTime(siteId, targetTs) {
    const evs = (playbackEventsBySite && playbackEventsBySite[siteId]) || [];
    let status = null;
    for (const e of evs) {
      if (e.ts > targetTs) break;
      status = e.to;
    }
    return status; // null = sin dato conocido para ese momento
  }

  async function loadPlaybackEvents() {
    playbackWindowStart = Date.now() - PLAYBACK_WINDOW_MS;
    try {
      const resp = await fetch(`/api/events?from=${playbackWindowStart}&limit=5000`);
      const events = await resp.json();
      playbackEventsBySite = {};
      events.forEach((e) => {
        (playbackEventsBySite[e.siteId] = playbackEventsBySite[e.siteId] || []).push(e);
      });
      Object.values(playbackEventsBySite).forEach((list) => list.sort((a, b) => a.ts - b.ts));
    } catch (_) {
      playbackEventsBySite = {};
    }
  }

  function formatPlaybackTime(ts) {
    return new Date(ts).toLocaleString('es-MX', { weekday: 'short', hour: '2-digit', minute: '2-digit' });
  }

  function applyPlaybackFrame(sliderValue) {
    const isLive = Number(sliderValue) >= PLAYBACK_STEPS;
    mapPlaybackWrap.classList.toggle('time-traveling', !isLive);

    if (isLive) {
      playbackTimeLabel.textContent = 'En vivo';
      renderMapMarkers(); // vuelve a los datos reales actuales
      return;
    }

    const targetTs = playbackWindowStart + (sliderValue / PLAYBACK_STEPS) * PLAYBACK_WINDOW_MS;
    playbackTimeLabel.textContent = formatPlaybackTime(targetTs);

    mapMarkers.forEach((marker, siteId) => {
      const card = cards.get(siteId);
      if (!card || !card.lastSite) return;
      const historicalStatus = computeStatusAtTime(siteId, targetTs);
      const statusClass = historicalStatus ? statusColorClass(historicalStatus) : 'unknown';
      marker.setIcon(L.divIcon({
        className: '',
        html: `<div class="map-marker-ring ring-unknown"><div class="map-marker ${statusClass}"></div></div>`,
        iconSize: [22, 22],
      }));
    });
  }

  playbackToggleBtn.addEventListener('click', async () => {
    const opening = playbackControls.style.display === 'none';
    if (opening) {
      playbackToggleBtn.textContent = 'Cargando historial…';
      await loadPlaybackEvents();
      playbackControls.style.display = 'flex';
      playbackToggleBtn.textContent = '🕐 Ocultar línea de tiempo';
      playbackSlider.value = PLAYBACK_STEPS;
      applyPlaybackFrame(PLAYBACK_STEPS);
    } else {
      playbackControls.style.display = 'none';
      playbackToggleBtn.textContent = '🕐 Ver el pasado (últimas 24h)';
      clearInterval(playbackTimer);
      playbackTimer = null;
      playbackPlayBtn.textContent = '▶';
      applyPlaybackFrame(PLAYBACK_STEPS);
    }
  });

  playbackSlider.addEventListener('input', () => {
    clearInterval(playbackTimer);
    playbackTimer = null;
    playbackPlayBtn.textContent = '▶';
    applyPlaybackFrame(playbackSlider.value);
  });

  playbackPlayBtn.addEventListener('click', () => {
    if (playbackTimer) {
      clearInterval(playbackTimer);
      playbackTimer = null;
      playbackPlayBtn.textContent = '▶';
      return;
    }
    playbackPlayBtn.textContent = '⏸';
    playbackTimer = setInterval(() => {
      let v = Number(playbackSlider.value) + 1;
      if (v > PLAYBACK_STEPS) v = 0; // vuelve a empezar desde hace 24h
      playbackSlider.value = v;
      applyPlaybackFrame(v);
    }, 120); // ~35 seg para recorrer las 24h completas
  });

  playbackLiveBtn.addEventListener('click', () => {
    clearInterval(playbackTimer);
    playbackTimer = null;
    playbackPlayBtn.textContent = '▶';
    playbackSlider.value = PLAYBACK_STEPS;
    applyPlaybackFrame(PLAYBACK_STEPS);
  });

  mapViewBtn.addEventListener('click', openMapModal);
  mapCloseBtn.addEventListener('click', () => {
    mapModalBackdrop.classList.remove('open');
    clearInterval(playbackTimer);
    playbackTimer = null;
    if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
  });
  mapModalBackdrop.addEventListener('click', (e) => {
    if (e.target === mapModalBackdrop) mapModalBackdrop.classList.remove('open');
  });

  // ---------- Expandir mapa ----------

  const mapExpandBtn = document.getElementById('mapExpandBtn');
  const modalMapEl = document.querySelector('.modal-map');

  function setMapExpandLabel(isExpanded) {
    mapExpandBtn.innerHTML = isExpanded ? '⤡ Reducir' : '⛶ Expandir';
  }

  mapExpandBtn.addEventListener('click', () => {
    // Preferimos pantalla completa real del navegador (mejor para modo TV /
    // sala de control); si el navegador la bloquea (algunos entornos
    // corporativos lo hacen), caemos al modo "maximizado" solo con CSS.
    if (document.fullscreenElement) {
      document.exitFullscreen().catch(() => {});
    } else if (modalMapEl.requestFullscreen) {
      modalMapEl.requestFullscreen().catch(() => {
        modalMapEl.classList.toggle('expanded');
        setMapExpandLabel(modalMapEl.classList.contains('expanded'));
        setTimeout(() => leafletMap && leafletMap.invalidateSize(), 260);
      });
    } else {
      modalMapEl.classList.toggle('expanded');
      setMapExpandLabel(modalMapEl.classList.contains('expanded'));
      setTimeout(() => leafletMap && leafletMap.invalidateSize(), 260);
    }
  });

  document.addEventListener('fullscreenchange', () => {
    const isFs = document.fullscreenElement === modalMapEl;
    setMapExpandLabel(isFs);
    if (!isFs) modalMapEl.classList.remove('expanded');
    setTimeout(() => leafletMap && leafletMap.invalidateSize(), 150);
  });

  // ---------- Modo pantalla de TV ----------

  let tvModeActive = false;
  let tvCycleTimer = null;
  let tvExitArmed = false;

  const TV_CYCLE_MS = 25000; // 25 segundos por vista

  function tvShowGrid() {
    if (mapModalBackdrop.classList.contains('open')) {
      clearInterval(playbackTimer);
      playbackTimer = null;
      mapModalBackdrop.classList.remove('open');
    }
  }

  function tvShowMap() {
    if (!mapModalBackdrop.classList.contains('open')) {
      openMapModal();
    }
  }

  function tvCycleStep() {
    if (mapModalBackdrop.classList.contains('open')) {
      tvShowGrid();
    } else {
      tvShowMap();
    }
  }

  function exitTvMode() {
    if (!tvModeActive) return;
    tvModeActive = false;
    tvExitArmed = false;
    clearInterval(tvCycleTimer);
    tvCycleTimer = null;
    tvShowGrid();
    document.body.classList.remove('tv-mode');
    if (document.fullscreenElement) {
      document.exitFullscreen().catch(() => {});
    }
    document.removeEventListener('mousemove', handleTvInteraction);
    document.removeEventListener('mousedown', handleTvInteraction);
    document.removeEventListener('keydown', handleTvInteraction);
    document.removeEventListener('touchstart', handleTvInteraction);
  }

  function handleTvInteraction() {
    if (!tvExitArmed) return; // ignora el primer instante para no salirse con el mismo clic que lo prendió
    exitTvMode();
  }

  function enterTvMode() {
    tvModeActive = true;
    document.body.classList.add('tv-mode');
    document.documentElement.requestFullscreen?.().catch(() => {});

    tvShowGrid(); // arranca en la vista de sitios
    tvCycleTimer = setInterval(tvCycleStep, TV_CYCLE_MS);

    // Da medio segundo antes de "armar" la salida, para que el clic que
    // prendió el modo TV no lo apague de inmediato.
    setTimeout(() => { tvExitArmed = true; }, 800);
    document.addEventListener('mousemove', handleTvInteraction);
    document.addEventListener('mousedown', handleTvInteraction);
    document.addEventListener('keydown', handleTvInteraction);
    document.addEventListener('touchstart', handleTvInteraction);
  }

  tvModeBtn.addEventListener('click', enterTvMode);

  // Si alguien sale de pantalla completa con Esc, se sale del modo TV también.
  document.addEventListener('fullscreenchange', () => {
    if (!document.fullscreenElement && tvModeActive) exitTvMode();
  });

  // ---------- Sesión y usuarios ----------

  let currentUserRole = null;

  async function loadSession() {
    try {
      const resp = await fetch('/api/session');
      if (!resp.ok) { window.location.href = '/login.html'; return; }
      const data = await resp.json();
      currentUserRole = data.role;
      sessionUser.textContent = `👤 ${data.username}${data.role === 'admin' ? '' : ' (invitado)'}`;
      if (data.role === 'admin') {
        usersBtn.style.display = '';
        manageSitesBtn.style.display = '';
      } else {
        // Los invitados no pueden tocar configuración: se ocultan esos controles.
        settingsBtn.style.display = 'none';
      }
    } catch (_) { /* si falla, se queda sin mostrar usuario; no bloquea el resto */ }
  }
  loadSession();

  logoutBtn.addEventListener('click', async () => {
    await fetch('/api/logout', { method: 'POST' }).catch(() => {});
    window.location.href = '/login.html';
  });

  async function loadUsersList() {
    usersStatus.textContent = '';
    try {
      const resp = await fetch('/api/users');
      const list = await resp.json();
      usersList.innerHTML = list.map((u) => `
        <div class="user-row">
          <span class="u-name">${escapeHtml(u.username)}</span>
          <span class="u-role ${u.role}">${u.role === 'admin' ? 'Administrador' : 'Invitado'}</span>
          <button class="u-remove" data-toggle-role="${escapeHtml(u.username)}" data-current-role="${u.role}" title="${u.role === 'admin' ? 'Bajar a invitado' : 'Subir a administrador'}">${u.role === 'admin' ? '⬇' : '⬆'}</button>
          <button class="u-remove" data-remove-user="${escapeHtml(u.username)}" title="Quitar">🗑</button>
        </div>
      `).join('');
      usersList.querySelectorAll('[data-toggle-role]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          const username = btn.getAttribute('data-toggle-role');
          const current = btn.getAttribute('data-current-role');
          const newRole = current === 'admin' ? 'viewer' : 'admin';
          try {
            const r = await fetch(`/api/users/${encodeURIComponent(username)}/role`, {
              method: 'PUT',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ role: newRole }),
            });
            if (!r.ok) { const d = await r.json(); usersStatus.textContent = d.error || 'No se pudo cambiar el rango.'; return; }
            loadUsersList();
          } catch (_) { usersStatus.textContent = 'No se pudo cambiar el rango.'; }
        });
      });
      usersList.querySelectorAll('[data-remove-user]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          const username = btn.getAttribute('data-remove-user');
          if (!confirm(`¿Quitar el acceso de "${username}"?`)) return;
          try {
            const r = await fetch(`/api/users/${encodeURIComponent(username)}`, { method: 'DELETE' });
            if (!r.ok) { const d = await r.json(); usersStatus.textContent = d.error || 'No se pudo quitar.'; return; }
            loadUsersList();
          } catch (_) { usersStatus.textContent = 'No se pudo quitar.'; }
        });
      });
    } catch (_) {
      usersList.innerHTML = '<p style="color:var(--text-faint);font-size:11.5px;">No se pudo cargar la lista.</p>';
    }
  }

  usersBtn.addEventListener('click', () => {
    usersModalBackdrop.classList.add('open');
    loadUsersList();
  });
  usersCloseBtn.addEventListener('click', () => usersModalBackdrop.classList.remove('open'));
  usersModalBackdrop.addEventListener('click', (e) => {
    if (e.target === usersModalBackdrop) usersModalBackdrop.classList.remove('open');
  });

  addUserBtn.addEventListener('click', async () => {
    const username = newUserName.value.trim();
    const password = newUserPass.value;
    const role = newUserRole.value;
    if (!username || password.length < 4) {
      usersStatus.textContent = 'Escribe un usuario y una contraseña de al menos 4 caracteres.';
      return;
    }
    usersStatus.textContent = 'Agregando…';
    try {
      const resp = await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password, role }),
      });
      const data = await resp.json();
      if (!resp.ok) { usersStatus.textContent = data.error || 'No se pudo agregar.'; return; }
      newUserName.value = '';
      newUserPass.value = '';
      usersStatus.textContent = `Usuario "${username}" agregado ✓`;
      loadUsersList();
    } catch (_) {
      usersStatus.textContent = 'No se pudo agregar.';
    }
  });

  // ---------- Gestión de sitios ----------

  let editingSiteId = null;
  let knownCities = {};

  async function loadCitiesIntoSelect() {
    try {
      const resp = await fetch('/api/cities');
      knownCities = await resp.json();
    } catch (_) { knownCities = {}; }
    const current = siteFormCity.value;
    const opts = ['<option value="">Ciudad…</option>'];
    Object.keys(knownCities).sort().forEach((c) => opts.push(`<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`));
    opts.push('<option value="__new__">+ Nueva ciudad…</option>');
    siteFormCity.innerHTML = opts.join('');
    if (current) siteFormCity.value = current;
  }

  siteFormCity.addEventListener('change', () => {
    siteFormNewCityRow.style.display = siteFormCity.value === '__new__' ? 'flex' : 'none';
  });

  function resetSiteForm() {
    editingSiteId = null;
    siteFormName.value = '';
    siteFormIp.value = '';
    siteFormPort.value = '';
    siteFormGroup.value = '';
    siteFormCity.value = '';
    siteFormNewCityRow.style.display = 'none';
    siteFormNewCityName.value = '';
    siteFormNewCityLat.value = '';
    siteFormNewCityLng.value = '';
    siteFormAddress.value = '';
    siteFormLat.value = '';
    siteFormLng.value = '';
    siteFormNotes.value = '';
    siteFormSaveBtn.textContent = '+ Agregar sitio';
    siteFormCancelBtn.style.display = 'none';
    siteFormStatus.textContent = '';
  }

  function renderSitesTable() {
    const rows = Array.from(cards.values())
      .map((c) => c.lastSite)
      .filter(Boolean)
      .sort((a, b) => a.name.localeCompare(b.name));

    sitesTableBody.innerHTML = rows.map((s) => `
      <tr>
        <td>${escapeHtml(s.name)}</td>
        <td>${escapeHtml(s.ip)}${s.port ? ':' + s.port : ''}</td>
        <td>${escapeHtml(s.group || '—')}</td>
        <td>${escapeHtml(s.city || '—')}</td>
        <td>${escapeHtml(s.notes || '')}</td>
        <td style="white-space:nowrap;">
          <button class="site-row-edit-btn" data-edit-site="${s.id}" title="Editar">✏️</button>
          <button class="site-row-delete-btn" data-delete-site="${s.id}" title="Quitar">🗑</button>
        </td>
      </tr>
    `).join('');

    sitesTableBody.querySelectorAll('[data-edit-site]').forEach((btn) => {
      btn.addEventListener('click', () => startEditSite(btn.getAttribute('data-edit-site')));
    });
    sitesTableBody.querySelectorAll('[data-delete-site]').forEach((btn) => {
      btn.addEventListener('click', () => deleteSite(btn.getAttribute('data-delete-site')));
    });
  }

  function startEditSite(siteId) {
    const card = cards.get(siteId);
    if (!card || !card.lastSite) return;
    const s = card.lastSite;
    editingSiteId = siteId;
    siteFormName.value = s.name;
    siteFormIp.value = s.ip;
    siteFormPort.value = s.port || '';
    siteFormGroup.value = s.group || '';
    siteFormCity.value = s.city || '';
    siteFormNewCityRow.style.display = 'none';
    siteFormAddress.value = s.address || '';
    siteFormLat.value = s.exactLocation ? s.lat : '';
    siteFormLng.value = s.exactLocation ? s.lng : '';
    siteFormNotes.value = s.notes || '';
    siteFormSaveBtn.textContent = '💾 Guardar cambios';
    siteFormCancelBtn.style.display = '';
    siteFormStatus.textContent = `Editando "${s.name}"…`;
    siteFormName.focus();
  }

  siteFormCancelBtn.addEventListener('click', resetSiteForm);

  siteFormGeocodeBtn.addEventListener('click', async () => {
    const address = siteFormAddress.value.trim();
    if (!address) {
      siteFormStatus.textContent = 'Escribe una dirección antes de buscar coordenadas.';
      return;
    }
    siteFormStatus.textContent = 'Buscando coordenadas…';
    try {
      const resp = await fetch('/api/geocode', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ address }),
      });
      const data = await resp.json();
      if (!resp.ok) { siteFormStatus.textContent = data.error || 'No se encontró esa dirección.'; return; }
      siteFormLat.value = data.lat;
      siteFormLng.value = data.lng;
      siteFormStatus.textContent = `Encontrado: ${data.matchedAddress}`;
    } catch (_) {
      siteFormStatus.textContent = 'No se pudo buscar la dirección.';
    }
  });

  async function deleteSite(siteId) {
    const card = cards.get(siteId);
    const name = card && card.lastSite ? card.lastSite.name : siteId;
    if (!confirm(`¿Quitar "${name}" del monitoreo? Esto no se puede deshacer.`)) return;
    try {
      const resp = await fetch(`/api/sites/${siteId}`, { method: 'DELETE' });
      if (!resp.ok) { const d = await resp.json().catch(() => ({})); siteFormStatus.textContent = d.error || 'No se pudo quitar.'; return; }
      siteFormStatus.textContent = `"${name}" fue quitado.`;
    } catch (_) {
      siteFormStatus.textContent = 'No se pudo quitar.';
    }
  }

  siteFormSaveBtn.addEventListener('click', async () => {
    const name = siteFormName.value.trim();
    const ip = siteFormIp.value.trim();
    const port = siteFormPort.value.trim();
    const group = siteFormGroup.value;
    let city = siteFormCity.value;
    const notes = siteFormNotes.value.trim();

    if (!name || !ip) {
      siteFormStatus.textContent = 'El nombre y la IP son obligatorios.';
      return;
    }

    if (city === '__new__') {
      const newName = siteFormNewCityName.value.trim();
      const lat = parseFloat(siteFormNewCityLat.value);
      const lng = parseFloat(siteFormNewCityLng.value);
      if (!newName || Number.isNaN(lat) || Number.isNaN(lng)) {
        siteFormStatus.textContent = 'Completa nombre, latitud y longitud de la ciudad nueva.';
        return;
      }
      try {
        await fetch('/api/cities', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name: newName, lat, lng }),
        });
        city = newName;
        await loadCitiesIntoSelect();
      } catch (_) {
        siteFormStatus.textContent = 'No se pudo guardar la ciudad nueva.';
        return;
      }
    }

    const payload = {
      name, ip,
      port: port ? parseInt(port, 10) : null,
      group: group || null,
      city: city || null,
      notes: notes || '',
      address: siteFormAddress.value.trim() || null,
      exactLat: siteFormLat.value.trim() || null,
      exactLng: siteFormLng.value.trim() || null,
    };

    siteFormStatus.textContent = editingSiteId ? 'Guardando cambios…' : 'Agregando…';
    try {
      const url = editingSiteId ? `/api/sites/${editingSiteId}` : '/api/sites';
      const method = editingSiteId ? 'PUT' : 'POST';
      const resp = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await resp.json();
      if (!resp.ok) { siteFormStatus.textContent = data.error || 'No se pudo guardar.'; return; }
      siteFormStatus.textContent = `"${name}" guardado ✓`;
      resetSiteForm();
    } catch (_) {
      siteFormStatus.textContent = 'No se pudo guardar.';
    }
  });

  manageSitesBtn.addEventListener('click', async () => {
    resetSiteForm();
    await loadCitiesIntoSelect();
    renderSitesTable();
    sitesModalBackdrop.classList.add('open');
  });
  sitesCloseBtn.addEventListener('click', () => sitesModalBackdrop.classList.remove('open'));
  sitesModalBackdrop.addEventListener('click', (e) => {
    if (e.target === sitesModalBackdrop) sitesModalBackdrop.classList.remove('open');
  });

  // ---------- Re-verificación masiva de coordenadas ----------

  const bulkGeocodeBtn = document.getElementById('bulkGeocodeBtn');
  const bulkGeocodeResults = document.getElementById('bulkGeocodeResults');

  function haversineMeters(lat1, lng1, lat2, lng2) {
    const R = 6371000;
    const toRad = (d) => (d * Math.PI) / 180;
    const dLat = toRad(lat2 - lat1);
    const dLng = toRad(lng2 - lng1);
    const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  }

  function renderBulkGeocodeResults(results, statusText) {
    const rowsHtml = results.map((r) => {
      if (!r.hasAddress) {
        return `<tr class="no-address"><td>${escapeHtml(r.name)}</td><td colspan="3">Sin dirección guardada — no se puede verificar</td></tr>`;
      }
      if (r.error) {
        return `<tr class="no-address"><td>${escapeHtml(r.name)}</td><td colspan="3">⚠ ${escapeHtml(r.error)}</td></tr>`;
      }
      const distClass = r.distanceM > 150 ? 'moved-far' : 'moved-little';
      const distLabel = r.distanceM >= 1000 ? `${(r.distanceM / 1000).toFixed(1)} km` : `${Math.round(r.distanceM)} m`;
      return `
        <tr>
          <td><label style="display:flex;align-items:center;gap:6px;">
            <input type="checkbox" data-apply-id="${r.id}" ${r.distanceM > 150 ? 'checked' : ''} />
            ${escapeHtml(r.name)}
          </label></td>
          <td class="${distClass}">${distLabel} de diferencia</td>
          <td class="popup-dim">${escapeHtml(r.matchedAddress || '')}</td>
        </tr>`;
    }).join('');

    bulkGeocodeResults.innerHTML = `
      <div class="bulk-geocode-progress">${statusText}</div>
      <table class="bulk-geocode-table">
        <thead><tr><th>Sitio</th><th>Diferencia</th><th>Dirección encontrada</th></tr></thead>
        <tbody>${rowsHtml}</tbody>
      </table>
      <div class="bulk-geocode-actions">
        <span class="modal-status" id="bulkGeocodeApplyStatus"></span>
        <button id="bulkGeocodeApplyBtn" class="modal-btn primary" type="button">💾 Aplicar seleccionados</button>
      </div>
    `;

    const applyBtn = document.getElementById('bulkGeocodeApplyBtn');
    const applyStatus = document.getElementById('bulkGeocodeApplyStatus');
    applyBtn.addEventListener('click', async () => {
      const checked = Array.from(bulkGeocodeResults.querySelectorAll('[data-apply-id]:checked'));
      if (!checked.length) { applyStatus.textContent = 'No marcaste ningún sitio.'; return; }
      applyBtn.disabled = true;
      let done = 0;
      for (const box of checked) {
        const id = box.getAttribute('data-apply-id');
        const r = results.find((x) => x.id === id);
        applyStatus.textContent = `Guardando ${++done}/${checked.length}…`;
        try {
          await fetch(`/api/sites/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ exactLat: r.newLat, exactLng: r.newLng }),
          });
        } catch (_) { /* seguimos con los demás aunque uno falle */ }
      }
      applyStatus.textContent = `✅ ${checked.length} sitio(s) actualizado(s).`;
      renderSitesTable();
      if (mapModalBackdrop.classList.contains('open')) renderMapMarkers();
    });
  }

  bulkGeocodeBtn.addEventListener('click', async () => {
    const siteList = Array.from(cards.values()).map((c) => c.lastSite).filter(Boolean).sort((a, b) => a.name.localeCompare(b.name));
    bulkGeocodeBtn.disabled = true;
    bulkGeocodeResults.style.display = '';
    const results = [];
    for (let i = 0; i < siteList.length; i++) {
      const s = siteList[i];
      bulkGeocodeResults.innerHTML = `<div class="bulk-geocode-progress">Verificando ${i + 1}/${siteList.length}: ${escapeHtml(s.name)}…</div>`;
      if (!s.address) {
        results.push({ id: s.id, name: s.name, hasAddress: false });
        continue;
      }
      try {
        const resp = await fetch('/api/geocode', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ address: s.address }),
        });
        const data = await resp.json();
        if (!resp.ok) {
          results.push({ id: s.id, name: s.name, hasAddress: true, error: data.error || 'no encontrado' });
        } else {
          const distanceM = (s.lat != null && s.lng != null) ? haversineMeters(s.lat, s.lng, data.lat, data.lng) : Infinity;
          results.push({
            id: s.id, name: s.name, hasAddress: true,
            newLat: data.lat, newLng: data.lng, matchedAddress: data.matchedAddress, distanceM,
          });
        }
      } catch (_) {
        results.push({ id: s.id, name: s.name, hasAddress: true, error: 'no se pudo consultar' });
      }
      // Nominatim pide máximo ~1 solicitud por segundo — respetamos esa pausa
      // entre cada sitio para no saturar el servicio gratuito.
      await new Promise((res) => setTimeout(res, 1100));
    }
    bulkGeocodeBtn.disabled = false;
    const changedCount = results.filter((r) => r.hasAddress && !r.error && r.distanceM > 150).length;
    renderBulkGeocodeResults(results, `Listo — ${changedCount} sitio(s) con una diferencia mayor a 150m respecto a lo guardado (marcados abajo).`);
  });

  // ---------- Pestañas de móvil (Sitios / Actividad) ----------

  mobileTabs.querySelectorAll('.mobile-tab').forEach((btn) => {
    btn.addEventListener('click', () => {
      mobileTabs.querySelectorAll('.mobile-tab').forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');
      mainLayout.classList.toggle('show-events', btn.dataset.tab === 'events');
    });
  });

  // ---------- Resumen / filtro ----------

  function updateSummary() {
    let online = 0, intermittent = 0, offline = 0, unknown = 0, maintenance = 0;
    for (const card of cards.values()) {
      const s = card.el.dataset.status;
      if (s === 'online') online++;
      else if (s === 'intermittent') intermittent++;
      else if (s === 'offline') offline++;
      else if (s === 'maintenance' || s === 'outofservice' || s === 'knownissue') maintenance++;
      else unknown++;
    }
    document.getElementById('countOnline').textContent = online;
    document.getElementById('countIntermittent').textContent = intermittent;
    document.getElementById('countOffline').textContent = offline;
    document.getElementById('countUnknown').textContent = unknown;
    const maintChip = document.getElementById('countMaintenanceChip');
    if (maintChip) {
      maintChip.style.display = maintenance > 0 ? '' : 'none';
      document.getElementById('countMaintenance').textContent = maintenance;
    }
  }

  function applyFilterToCard(card) {
    const match = !searchTerm || (card._searchBlob || '').includes(searchTerm);
    card.el.style.display = match ? '' : 'none';
  }

  function applyFilter() {
    for (const card of cards.values()) applyFilterToCard(card);
  }

  searchBox.addEventListener('input', (e) => {
    searchTerm = e.target.value.trim().toLowerCase();
    applyFilter();
  });

  // ---------- Utilidades ----------

  function timeAgo(ts) {
    const s = Math.floor((Date.now() - ts) / 1000);
    if (s < 5) return 'ahora';
    if (s < 60) return `hace ${s}s`;
    const m = Math.floor(s / 60);
    if (m < 60) return `hace ${m}m`;
    const h = Math.floor(m / 60);
    return `hace ${h}h`;
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

})();
