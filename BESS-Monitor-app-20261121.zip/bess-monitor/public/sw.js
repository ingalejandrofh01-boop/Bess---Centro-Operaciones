// Service worker mínimo — su único propósito es que Chrome/Android
// reconozca esta página como "instalable". No cachea nada: como es un
// panel de monitoreo en vivo, siempre queremos datos frescos de la red,
// nunca una versión guardada.

self.addEventListener('install', (event) => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  // Deja pasar todo directo a la red, sin interceptar ni cachear. Si la
  // red falla (WiFi intermitente, etc.), se responde con un error de
  // red "controlado" en vez de dejar la promesa sin manejar (eso era lo
  // que llenaba la consola de errores "Failed to fetch").
  event.respondWith(
    fetch(event.request).catch(() => new Response(null, { status: 503, statusText: 'Sin conexión' }))
  );
});
