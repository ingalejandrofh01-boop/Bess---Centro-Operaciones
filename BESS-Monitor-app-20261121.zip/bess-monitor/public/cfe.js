/* ══════════════════════════════════════════════════════════════════════
   Periodos horarios CFE (Base · Intermedia · Punta) — GDMTH / DIST
   Se usa en el servidor (require) y en el navegador (window.CFE).
   ──────────────────────────────────────────────────────────────────────
   Tabla de las regiones Central, Noreste, Noroeste, Norte, Peninsular y
   Sur (todas las de los sitios actuales). Horas LOCALES del sitio.
   Verano = primer domingo de abril → sábado anterior al último domingo de
   octubre (misma regla que usa Centro BESS). Festivos = como domingo.
   DIST usa por default la misma tabla; si algún sitio tuviera otra, se
   agrega aquí en TABLAS y se asigna en config/supervisor-sitios.json
   ("tarifa": "DIST" / "region": …).
   ══════════════════════════════════════════════════════════════════════ */
(function (root) {
  'use strict';
  const H = (h, m) => h * 60 + (m || 0);
  // cada día: lista de [desde, hasta, periodo] en minutos locales
  const GENERAL = {
    verano: {
      lv: [[H(0), H(6), 'B'], [H(6), H(20), 'I'], [H(20), H(22), 'P'], [H(22), H(24), 'I']],
      sab: [[H(0), H(7), 'B'], [H(7), H(24), 'I']],
      dom: [[H(0), H(19), 'B'], [H(19), H(24), 'I']],
    },
    invierno: {
      lv: [[H(0), H(6), 'B'], [H(6), H(18), 'I'], [H(18), H(22), 'P'], [H(22), H(24), 'I']],
      sab: [[H(0), H(8), 'B'], [H(8), H(19), 'I'], [H(19), H(21), 'P'], [H(21), H(24), 'I']],
      dom: [[H(0), H(18), 'B'], [H(18), H(24), 'I']],
    },
  };
  /* DIST / DIT (subtransmisión/transmisión horaria): la PUNTA de verano L-V empieza una hora antes (19:00, "7 a 10")
     que la GDMTH Central (20:00). Invierno L-V 18-22. Verificado contra recibo (Resideo/LG). */
  const DIST = {
    verano: {
      lv: [[H(0), H(6), 'B'], [H(6), H(19), 'I'], [H(19), H(22), 'P'], [H(22), H(24), 'I']],
      sab: [[H(0), H(7), 'B'], [H(7), H(24), 'I']],
      dom: [[H(0), H(19), 'B'], [H(19), H(24), 'I']],
    },
    invierno: {
      lv: [[H(0), H(6), 'B'], [H(6), H(18), 'I'], [H(18), H(22), 'P'], [H(22), H(24), 'I']],
      sab: [[H(0), H(8), 'B'], [H(8), H(19), 'I'], [H(19), H(21), 'P'], [H(21), H(24), 'I']],
      dom: [[H(0), H(18), 'B'], [H(18), H(24), 'I']],
    },
  };
  const TABLAS = { GDMTH: GENERAL, DIST: DIST, DIT: DIST };
  const NOMBRE = { B: 'Base', I: 'Intermedia', P: 'Punta' };
  const COLOR = { B: '#0ea5e9', I: '#eda100', P: '#4a3aa7' };

  function season(d) {
    const y = d.getFullYear();
    const apr1 = new Date(y, 3, 1);
    const firstSunApr = new Date(y, 3, 1 + (7 - apr1.getDay()) % 7);
    const oct31 = new Date(y, 10, 0);
    const lastSatOct = new Date(y, 10, 0 - ((oct31.getDay() - 6 + 7) % 7));
    const t = new Date(y, d.getMonth(), d.getDate());
    return t >= firstSunApr && t <= lastSatOct ? 'verano' : 'invierno';
  }
  const nth = (y, m, wd, n) => { const d = new Date(y, m, 1); const add = (wd - d.getDay() + 7) % 7; return new Date(y, m, 1 + add + 7 * (n - 1)).getDate(); };
  function festivo(d) {
    const y = d.getFullYear(), m = d.getMonth(), dd = d.getDate();
    return (m === 0 && dd === 1) || (m === 1 && dd === nth(y, 1, 1, 1)) || (m === 2 && dd === nth(y, 2, 1, 3)) ||
      (m === 4 && dd === 1) || (m === 8 && dd === 16) || (m === 10 && dd === nth(y, 10, 1, 3)) || (m === 11 && dd === 25);
  }
  function dayType(d) { if (festivo(d)) return 'dom'; const w = d.getDay(); return w === 0 ? 'dom' : w === 6 ? 'sab' : 'lv'; }
  /* tramos del día (hora local del sitio) */
  function tramos(d, tarifa) {
    const t = TABLAS[String(tarifa || 'GDMTH').toUpperCase()] || GENERAL;
    return t[season(d)][dayType(d)];
  }
  /* periodo para una fecha (hora local del sitio) */
  function periodo(d, tarifa) {
    const m = d.getHours() * 60 + d.getMinutes();
    const tr = tramos(d, tarifa).find((x) => m >= x[0] && m < x[1]);
    return tr ? tr[2] : 'B';
  }
  /* El monitor corre en hora del centro (CDMX). tzMin = minutos que el sitio va ADELANTE (Cancún/Cozumel = 60) */
  function periodoMonitor(dMonitor, tarifa, tzMin) {
    return periodo(new Date(dMonitor.getTime() + (tzMin || 0) * 60000), tarifa);
  }
  /* Tramos de Punta de un día expresados en hora del MONITOR (minutos desde 00:00 del día del monitor) */
  function puntaMonitor(dayDate, tarifa, tzMin) {
    return tramos(dayDate, tarifa).filter((x) => x[2] === 'P').map((x) => [x[0] - (tzMin || 0), x[1] - (tzMin || 0)]);
  }
  const api = { season, festivo, dayType, tramos, periodo, periodoMonitor, puntaMonitor, NOMBRE, COLOR, TABLAS };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.CFE = api;
})(typeof window !== 'undefined' ? window : this);
