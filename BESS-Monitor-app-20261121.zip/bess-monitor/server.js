'use strict';

const path = require('path');
const fs = require('fs');
const { readTextSmart } = require('./lib/text-encoding');
const express = require('express');
const session = require('express-session');
const http = require('http');
const https = require('https');
const net = require('net');
const tls = require('tls');
const tlsCert = require('./lib/tls-cert');
const { Server } = require('socket.io');

const { checkSite } = require('./lib/checker');
const store = require('./lib/store');
const { sendTeamsAlert, sendTeamsText } = require('./lib/notifiers');
const vision = require('./lib/vision');
const auth = require('./lib/auth');
const weather = require('./lib/weather');
const geocode = require('./lib/geocode');
const supervisor = require('./lib/supervisor'); // ← SUPERVISOR EN VIVO
const jmobile = require('./lib/jmobile');
const historian = require('./lib/historian'); // ← SUPERVISOR: histórico por minuto de cada sitio
const deephist = require('./lib/deephist');   // ← histórico profundo: racks / celdas / PCS (cada ~30 s)
const equiposLib = require('./lib/equipos');

/**
 * Escribe un archivo de config con un par de reintentos si Windows lo
 * reporta como "ocupado" (OneDrive sincronizando, antivirus escaneándolo,
 * o el archivo abierto en otro programa) — en vez de fallar de inmediato.
 */
function writeFileWithRetry(filePath, content, attempts = 5) {
  for (let attempt = 1; attempt <= attempts; attempt++) {
    try {
      fs.writeFileSync(filePath, content);
      return;
    } catch (err) {
      const isLocked = err.code === 'EBUSY' || err.code === 'EPERM' || err.code === 'EACCES';
      if (!isLocked || attempt === attempts) {
        if (isLocked) {
          throw new Error(
            `No se pudo guardar ${path.basename(filePath)} porque otro programa lo tiene abierto ` +
            `(OneDrive sincronizando, un antivirus, o un editor de texto). Cierra esos programas e ` +
            `intenta de nuevo.`
          );
        }
        throw err;
      }
      const until = Date.now() + attempt * 150;
      while (Date.now() < until) { /* espera breve antes de reintentar */ }
    }
  }
}

const CONFIG_FILE = path.join(__dirname, 'config', 'sites.json');
const ALERTS_CONFIG_FILE = path.join(__dirname, 'config', 'alerts.json');
const VISION_CONFIG_FILE = path.join(__dirname, 'config', 'vision.json');
const SCADA_AUTH_FILE = path.join(__dirname, 'config', 'scada-auth.json');
const CITIES_FILE = path.join(__dirname, 'config', 'mexico-cities.json');
const VISION_INTERVAL_MS = parseInt(process.env.VISION_INTERVAL_MS || '45000', 10);
// La VISIÓN (OCR) abre Chrome con puppeteer. APAGADA por defecto: si una pantalla fallaba, el servidor
// abría Chrome una y otra vez y saturaba la PC (no dejaba abrir Chrome ni otras apps). Se enciende solo
// con AUTO_VISION=1 cuando de verdad haga falta leer un sitio por imagen.
const AUTO_VISION = process.env.AUTO_VISION === '1';
const PING_INTERVAL_MS = parseInt(process.env.PING_INTERVAL_MS || '10000', 10);
const SCADA_INTERVAL_MS = parseInt(process.env.SCADA_INTERVAL_MS || '30000', 10);
const PORT = parseInt(process.env.PORT || '3000', 10);
const FAILS_FOR_OFFLINE = 5;
const INTERMITTENT_FAILS = 2;

// Niveles de alerta según cuánto tiempo lleva un sitio sin comunicación.
// Configurable por variable de entorno si algún día quieren otros tiempos.
const ESCALATION_LEVELS = [
  { level: 1, minutes: parseInt(process.env.ESCALATION_MIN_1 || '10', 10), label: 'Aviso', code: 'aviso' },
  { level: 2, minutes: parseInt(process.env.ESCALATION_MIN_2 || '20', 10), label: 'Alerta', code: 'alerta' },
  { level: 3, minutes: parseInt(process.env.ESCALATION_MIN_3 || '30', 10), label: 'Contactar personal', code: 'contactar' },
  { level: 4, minutes: parseInt(process.env.ESCALATION_MIN_4 || '60', 10), label: 'Urgencia — acudir a sitio', code: 'urgencia' },
];

let cityCoords = {};
try {
  cityCoords = JSON.parse(readTextSmart(CITIES_FILE));
} catch (_) {
  cityCoords = {};
}

const WEATHER_TTL_MS = 30 * 60 * 1000; // 30 minutos
const weatherCache = new Map(); // ciudad -> { data, fetchedAt }

async function getWeatherForCity(city) {
  const coords = cityCoords[city];
  if (!coords) return null;
  const cached = weatherCache.get(city);
  if (cached && Date.now() - cached.fetchedAt < WEATHER_TTL_MS) return cached.data;
  try {
    const data = await weather.fetchWeather(coords.lat, coords.lng);
    weatherCache.set(city, { data, fetchedAt: Date.now() });
    return data;
  } catch (err) {
    console.error(`[clima] No se pudo obtener el clima de "${city}": ${err.message}`);
    return cached ? cached.data : null; // si falla, mejor devolver lo último conocido que nada
  }
}

const HOURLY_HISTORY_TTL_MS = 3 * 60 * 60 * 1000; // 3 horas
const hourlyHistoryCache = new Map(); // ciudad -> { data, fetchedAt }

async function getHourlyHistoryForCity(city) {
  const coords = cityCoords[city];
  if (!coords) return null;
  const cached = hourlyHistoryCache.get(city);
  if (cached && Date.now() - cached.fetchedAt < HOURLY_HISTORY_TTL_MS) return cached.data;
  try {
    const data = await weather.fetchHourlyHistory(coords.lat, coords.lng);
    hourlyHistoryCache.set(city, { data, fetchedAt: Date.now() });
    return data;
  } catch (err) {
    return cached ? cached.data : null;
  }
}

// ---------- Carga / guardado de configuración de sitios ----------

function loadSites() {
  const raw = readTextSmart(CONFIG_FILE);
  const list = JSON.parse(raw);
  return list.map((s) => ({
    id: s.id,
    name: s.name,
    ip: s.ip,
    port: s.port || null,
    scadaEndpoint: s.scadaEndpoint || null,
    notes: s.notes || '',
    city: s.city || null,
    group: s.group || null,
    address: s.address || null,
    exactLat: s.exactLat != null ? Number(s.exactLat) : null,
    exactLng: s.exactLng != null ? Number(s.exactLng) : null,
  }));
}

function persistSites(list) {
  writeFileWithRetry(CONFIG_FILE, JSON.stringify(list, null, 2));
}

let sites = loadSites();

// Si alguien edita config/sites.json a mano (o se reemplaza el archivo al
// actualizar), se recarga solo — no hace falta reiniciar el servidor.
let reloadDebounce = null;
fs.watch(CONFIG_FILE, () => {
  clearTimeout(reloadDebounce);
  reloadDebounce = setTimeout(() => {
    try {
      const fresh = loadSites();
      const oldIds = new Set(sites.map((s) => s.id));
      sites.length = 0;
      sites.push(...fresh);
      sites.forEach((site, idx) => {
        if (!oldIds.has(site.id)) initState(site);
        ensureSiteScheduled(site, idx);
      });
      const newIds = new Set(sites.map((s) => s.id));
      for (const id of Array.from(state.keys())) {
        if (!newIds.has(id)) state.delete(id);
      }
      io.emit('sites:changed', sites.map(publicSiteView));
      console.log(`[sites] config/sites.json cambió en disco — recargado (${sites.length} sitios).`);
    } catch (err) {
      console.error('[sites] No se pudo recargar sites.json tras el cambio:', err.message);
    }
  }, 300); // pequeña espera para no recargar a medias mientras se escribe el archivo
});

function loadAlertsConfig() {
  try {
    return JSON.parse(readTextSmart(ALERTS_CONFIG_FILE));
  } catch (_) {
    return { teamsWebhookUrl: null, notifyOnOffline: true, notifyOnRecovery: true, notifyOnIntermittent: false };
  }
}

function persistAlertsConfig(cfg) {
  writeFileWithRetry(ALERTS_CONFIG_FILE, JSON.stringify(cfg, null, 2));
}

let alertsConfig = loadAlertsConfig();

function loadVisionConfig() {
  try {
    return JSON.parse(readTextSmart(VISION_CONFIG_FILE));
  } catch (_) {
    return {};
  }
}
function persistVisionConfig(cfg) {
  writeFileWithRetry(VISION_CONFIG_FILE, JSON.stringify(cfg, null, 2));
}
let visionConfig = loadVisionConfig(); // { [siteId]: { socRegion?, tempRegion? } }

function loadScadaAuth() {
  try {
    return JSON.parse(readTextSmart(SCADA_AUTH_FILE));
  } catch (_) {
    return { username: null, password: null };
  }
}
function persistScadaAuth(cfg) {
  writeFileWithRetry(SCADA_AUTH_FILE, JSON.stringify(cfg, null, 2));
}
let scadaAuth = loadScadaAuth();

// Estado en memoria por sitio
const state = new Map(); // id -> { status, consecutiveFails, consecutiveOK, latencyMs, lastCheck, scada }

function initState(site) {
  if (!state.has(site.id)) {
    state.set(site.id, {
      status: 'unknown',
      consecutiveFails: 0,
      consecutiveOK: 0,
      latencyMs: null,
      lastCheck: null,
      scada: null,
      scadaError: null,
      scadaUpdatedAt: null,
      offlineSince: null,
      escalationLevel: 0,
    });
  }
}
sites.forEach(initState);

// ---------- App / servidor ----------

const app = express();
let server, io, dualServer = null, fusionMgr = null, pvMgr = null, reporteCorreo = null, fusionEssMgr = null; // se crean hasta abajo, después de cargar el certificado (es async)

const SESSION_SECRET_FILE = path.join(__dirname, 'config', 'session-secret.json');
function loadOrCreateSessionSecret() {
  try {
    return JSON.parse(readTextSmart(SESSION_SECRET_FILE)).secret;
  } catch (_) {
    const secret = require('crypto').randomBytes(32).toString('hex');
    fs.writeFileSync(SESSION_SECRET_FILE, JSON.stringify({ secret }, null, 2));
    return secret;
  }
}

app.use(express.json());
app.use(session({
  secret: loadOrCreateSessionSecret(),
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 30 * 24 * 60 * 60 * 1000, secure: process.env.BEHIND_PROXY === '1' ? 'auto' : false }, // 30 días · v16: sin 'Secure' en local para que la misma sesión sirva en http:// y https://localhost:3000
}));

function requireAuth(req, res, next) {
  if (req.session && req.session.user) return next();
  return res.redirect('/login.html');
}
function requireApiAuth(req, res, next) {
  if (req.session && req.session.user) return next();
  return res.status(401).json({ error: 'No has iniciado sesión' });
}
function requireAdmin(req, res, next) {
  if (req.session && req.session.user && req.session.user.role === 'admin') return next();
  return res.status(403).json({ error: 'Necesitas permisos de administrador para esto' });
}

// ---------- Autenticación ----------

app.get('/api/first-run', (req, res) => {
  res.json({ needsSetup: auth.loadUsers().length === 0 });
});

app.post('/api/first-run', (req, res) => {
  if (auth.loadUsers().length > 0) return res.status(400).json({ error: 'Ya existe al menos un usuario' });
  const { username, password } = req.body || {};
  if (!username || !password || password.length < 4) {
    return res.status(400).json({ error: 'Usuario y contraseña (mínimo 4 caracteres) son obligatorios' });
  }
  auth.createUser(username, password, 'admin');
  req.session.user = { username, role: 'admin' };
  res.json({ ok: true });
});

app.post('/api/register', (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password || password.length < 4) {
    return res.status(400).json({ error: 'Usuario y contraseña (mínimo 4 caracteres) son obligatorios' });
  }
  try {
    // El auto-registro siempre crea cuentas de "invitado" — nunca admin,
    // eso evita que cualquiera se pueda dar permisos de administrador solo
    // por registrarse. Un admin puede subir de rango a alguien después
    // desde el panel de Usuarios.
    auth.createUser(username, password, 'viewer');
    req.session.user = { username, role: 'viewer' };
    res.json({ ok: true, role: 'viewer' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.post('/api/login', (req, res) => {
  const { username, password } = req.body || {};
  const user = auth.findUser(username || '');
  if (!user || !auth.verifyPassword(password || '', user.salt, user.hash)) {
    return res.status(401).json({ error: 'Usuario o contraseña incorrectos' });
  }
  req.session.user = { username: user.username, role: user.role };
  res.json({ ok: true, role: user.role });
});

app.post('/api/logout', (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get('/api/session', (req, res) => {
  if (req.session && req.session.user) return res.json({ authenticated: true, ...req.session.user });
  res.status(401).json({ authenticated: false });
});

app.get('/api/users', requireApiAuth, requireAdmin, (req, res) => {
  res.json(auth.loadUsers().map((u) => ({ username: u.username, role: u.role })));
});
app.post('/api/users', requireApiAuth, requireAdmin, (req, res) => {
  const { username, password, role } = req.body || {};
  if (!username || !password || password.length < 4) {
    return res.status(400).json({ error: 'Usuario y contraseña (mínimo 4 caracteres) son obligatorios' });
  }
  try {
    auth.createUser(username, password, role);
    res.status(201).json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
app.delete('/api/users/:username', requireApiAuth, requireAdmin, (req, res) => {
  try {
    auth.deleteUser(req.params.username);
    res.status(204).end();
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.put('/api/users/:username/role', requireApiAuth, requireAdmin, (req, res) => {
  try {
    auth.setUserRole(req.params.username, req.body?.role);
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.get('/reporte.html', requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'reporte.html'));
});

// v16: app instalable (manifest + íconos + service worker mínimo) en todas las pantallas del monitor
const PWA_HEAD = '<link rel="manifest" href="/monitor.webmanifest"><meta name="theme-color" content="#0b111b"><link rel="apple-touch-icon" href="/monitor-192.png">' +
  '<script>if("serviceWorker" in navigator&&(location.protocol==="http:"||location.protocol==="https:")){addEventListener("load",function(){navigator.serviceWorker.register("/monitor-sw.js",{scope:"/"}).catch(function(){})})}</script>';
function conPWA(html) { if (/monitor\.webmanifest/.test(html)) return html; return /<\/head>/i.test(html) ? html.replace(/<\/head>/i, PWA_HEAD + '</head>') : PWA_HEAD + html; }
function enviarPagina(res, file) {
  try { res.type('html').set('Cache-Control', 'no-cache').send(conPWA(readTextSmart(path.join(__dirname, 'public', file)))); }
  catch (_) { res.sendFile(path.join(__dirname, 'public', file)); }
}
app.get('/monitor.webmanifest', (req, res) => res.type('application/manifest+json').set('Cache-Control', 'no-cache').sendFile(path.join(__dirname, 'public', 'monitor.webmanifest')));
app.get('/monitor-sw.js', (req, res) => res.type('text/javascript').set({ 'Cache-Control': 'no-cache', 'Service-Worker-Allowed': '/' }).sendFile(path.join(__dirname, 'public', 'monitor-sw.js')));

// ---------- SUPERVISOR EN VIVO ----------
// Pantalla (requiere sesión, igual que el reporte)
app.get(['/supervisor', '/supervisor.html'], requireAuth, (req, res) => {
  enviarPagina(res, 'supervisor.html');
});
// Histórico / dashboard / exportación por sitio
app.get(['/historico', '/historico.html'], requireAuth, (req, res) => {
  enviarPagina(res, 'historico.html');
});
app.get(['/supervisor/respaldos', '/archivador.html'], requireAuth, (req, res) => enviarPagina(res, 'archivador.html'));
app.get(['/supervisor/pv/ess', '/ess.html'], requireAuth, (req, res) => enviarPagina(res, 'ess.html'));
// Entrada de datos externa (Tampermonkey, script Modbus, etc.). Usa un token
// en vez de sesión porque llega desde otra página. El token está en
// config/supervisor.json → "ingestToken".
app.options('/api/supervisor/ingest', (req, res) => {
  res.set({
    'Access-Control-Allow-Origin': req.headers.origin || '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, X-Ingest-Token',
    'Access-Control-Allow-Private-Network': 'true',
  });
  res.status(204).end();
});
app.post('/api/supervisor/ingest', (req, res) => {
  res.set({ 'Access-Control-Allow-Origin': req.headers.origin || '*', 'Access-Control-Allow-Private-Network': 'true' });
  const token = req.get('X-Ingest-Token') || (req.body && req.body.token);
  if (!supervisor.checkToken(token)) return res.status(401).json({ error: 'token inválido' });
  res.json({ ok: true, updated: supervisorIngestItems(req.body) });
});
function supervisorIngestItems(body) {
  const list = Array.isArray(body && body.sites) ? body.sites : [body || {}];
  let n = 0;
  list.forEach((item) => {
    const key = String(item.siteId || item.site || item.name || '').toLowerCase();
    const host = String(item.host || '');
    const site = sites.find((s) => (host && `${s.ip}:${s.port}` === host) || s.id.toLowerCase() === key || String(s.name).toLowerCase() === key || (item.ip && s.ip === item.ip));
    if (!site) return;
    if (item.alarmas && !item.data) return;   // envío SOLO de alarmas del HMI (lo atiende ingestHmiAlarms, no son lecturas de sitio)
    if (item.diag && !((item.data || {}).fields || []).length) return;   // latido de diagnóstico del Relay (sin lecturas)
    supervisor.ingest(site.id, item.data || item, item.source || 'ingest');
    n++;
  });
  return n;
}

app.use(express.static(path.join(__dirname, 'public'), { index: false }));

app.get('/', requireAuth, (req, res) => {
  // Se inyecta el botón "Supervisor en vivo" en la pantalla principal sin tocar index.html
  try {
    const html = readTextSmart(path.join(__dirname, 'public', 'index.html'));
    const tag = '<script src="/supervisor-link.js" defer></script>';
    res.type('html').set('Cache-Control', 'no-cache').send(conPWA(html.includes('</body>') ? html.replace('</body>', tag + '</body>') : html + tag));
  } catch (_) {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
  }
});

// Todo lo demás bajo /api requiere haber iniciado sesión (los endpoints de
// arriba — login, first-run, session — ya respondieron antes de llegar aquí).
app.use('/api', requireApiAuth);

function publicSiteView(site) {
  const st = state.get(site.id);
  const cityFallback = site.city ? cityCoords[site.city] : null;
  const hasExact = site.exactLat != null && site.exactLng != null;
  const lat = hasExact ? site.exactLat : (cityFallback ? cityFallback.lat : null);
  const lng = hasExact ? site.exactLng : (cityFallback ? cityFallback.lng : null);
  return {
    id: site.id,
    name: site.name,
    ip: site.ip,
    port: site.port,
    notes: site.notes,
    city: site.city,
    group: site.group,
    address: site.address,
    lat,
    lng,
    exactLocation: hasExact,
    hasScada: Boolean(site.scadaEndpoint),
    status: st.status,
    latencyMs: st.latencyMs,
    lastCheck: st.lastCheck,
    offlineSince: st.offlineSince,
    escalationLevel: st.escalationLevel || 0,
    maintenance: store.getMaintenance(site.id),
    assignment: store.getAssignment(site.id),
    uptimePct: store.uptimePercent(site.id),
    scada: st.scada,
    scadaError: st.scadaError,
    scadaUpdatedAt: st.scadaUpdatedAt,
  };
}

app.get('/api/sites', (req, res) => {
  res.json(sites.map(publicSiteView));
});

// ---------- SUPERVISOR EN VIVO (API) ----------
// ---------- HISTÓRICO (API) ----------
const isDay = (d) => /^\d{4}-\d{2}-\d{2}$/.test(String(d || ''));
// Precios CFE para el recibo estimado (config/tarifas-cfe.json)
const TARIFAS_FILE = path.join(__dirname, 'config', 'tarifas-cfe.json');
function leerTarifas() { try { return JSON.parse(fs.readFileSync(TARIFAS_FILE, 'utf-8')); } catch (_) { return { default: {}, porSitio: {} }; } }
app.get('/api/historico/tarifas', (req, res) => { const t = leerTarifas(); const own = (t.porSitio || {})[req.query.site] || null; let tf = null; try { const st = supervisor.findSite(req.query.site); tf = st ? supervisor.sitioCfg(st.id).tarifa : null; } catch (_) {} const porT = (tf && (t.porTarifa || {})[String(tf).toUpperCase()]) || {}; res.json({ precios: Object.assign({}, t.default || {}, porT, own || {}), propio: !!own, nota: t._nota || '' }); });
app.put('/api/historico/tarifas', (req, res) => {
  if (!req.session || !req.session.user || req.session.user.role !== 'admin') return res.status(403).json({ error: 'Solo un administrador puede cambiar los precios' });
  const t = leerTarifas(), b = req.body || {}, clean = {};
  Object.keys(b.precios || {}).forEach((k) => { const v = Number(b.precios[k]); if (Number.isFinite(v)) clean[k] = v; });
  if (b.site && b.site !== '__default') { t.porSitio = t.porSitio || {}; t.porSitio[b.site] = clean; } else t.default = Object.assign({}, t.default || {}, clean);
  try { fs.writeFileSync(TARIFAS_FILE, JSON.stringify(t, null, 1)); res.json({ ok: true }); } catch (err) { res.status(500).json({ error: err.message }); }
});
// serie de alta resolución (cada 5 s) para el zoom fino de la gráfica
app.get('/api/historico/detalle/:siteId', (req, res) => {
  const site = supervisor.findSite(req.params.siteId); if (!site) return res.status(404).json({ error: 'Sitio no encontrado' });
  const t0 = Number(req.query.t0), t1 = Number(req.query.t1); if (!Number.isFinite(t0) || !Number.isFinite(t1) || t1 <= t0) return res.status(400).json({ error: 'Rango inválido' });
  res.json(historian.detalle(site.id, t0, t1));
});
app.get('/api/historico/sitios', (req, res) => res.json(supervisor.allSites().map((s) => ({ id: s.id, name: s.name, group: s.group || null }))));
app.get('/api/historico/dias', (req, res) => res.json(historian.availableDays(req.query.site || null)));
app.get('/api/historico/sitio/:siteId', (req, res) => {
  const { from, to } = req.query;
  if (!isDay(from) || !isDay(to) || from > to) return res.status(400).json({ error: 'Rango de fechas inválido' });
  const site = supervisor.findSite(req.params.siteId); // incluye sitios divididos (ej. RegioPet 1/2/3)
  if (!site) return res.status(404).json({ error: 'Sitio no encontrado' });
  try {
    const sc = supervisor.sitioCfg(site.id);
    const q = historian.query(site.id, from, to, req.query.res, { tarifa: sc.tarifa, tzMin: sc.tzMin });
    q.siteName = site.name;
    const v = supervisor.view(site.id) || {};
    // ventana de descarga de cada día del rango (CFE punta + desfase del medidor)
    const ventanas = {}; q.daily.forEach((d) => { const [y, m, dd] = d.day.split('-').map(Number); ventanas[d.day] = supervisor.ventanasDia(site.id, new Date(y, m - 1, dd, 12)); });
    q.info = { dc: sc.dc || v.dc || null, tarifa: sc.tarifa, tzMin: sc.tzMin, microred: sc.microred || !!v.microred, horaEntradaCDMX: sc.horaEntradaCDMX, bess: v.bess ? v.bess.length : null, centroBess: v.centroBess || null, ventanas, live: v.t ? { t: v.t, red: v.red, consumo: v.consumo, bess: v.bess, gen: v.gen, solar: v.solar, gens: v.gens } : null };
    res.json(q);
  } catch (err) { res.status(500).json({ error: err.message }); }
});
// Resumen de TODOS los sitios en un rango (para la vista general)
app.get('/api/historico/resumen', (req, res) => {
  const { from, to } = req.query;
  if (!isDay(from) || !isDay(to) || from > to) return res.status(400).json({ error: 'Rango de fechas inválido' });
  res.json(supervisor.allSites().map((s) => { const sc = supervisor.sitioCfg(s.id); const q = historian.query(s.id, from, to, 60, { tarifa: sc.tarifa, tzMin: sc.tzMin, picos5: false }); return { id: s.id, name: s.name, dc: sc.dc, totals: q.totals }; }));
});

app.get('/api/supervisor/state', (req, res) => res.json(supervisor.allViews()));
app.get('/api/supervisor/status', (req, res) => res.json(supStatus()));
/* ── Equipos: racks / BMS, PCS, medidores (lectura completa) ── */
app.get('/api/supervisor/equipos/:id', (req, res) => {
  const base = String(req.params.id).split('~')[0], site = sites.find((x) => x.id === base);
  if (!site) return res.status(404).json({ error: 'sitio no encontrado' });
  deepWatch[base] = Date.now();
  const d = deepData[base];
  if (!jmobile.isJMobileSite(site) || Number(site.port) === 7010 || (vncMgr && vncMgr.has(base))) return res.json({ disponible: false, motivo: 'Este sitio no es una pantalla JMobile (VNC / SEL RTAC): solo se leen los datos principales.' });
  if (!supervisor.getConfig().lecturaDirecta) return res.json({ disponible: false, motivo: 'La lectura completa usa la sesión directa del Supervisor; está en modo "solo pestañas".' });
  if (!d || !d.values) return res.json({ disponible: true, cargando: true, err: d && d.err || null });
  res.json(Object.assign({ disponible: true, err: d.err || null }, require('./lib/equipos').parse(d.values, { at: d.at })));
});
/* ── Etiquetas CRUDAS de la pantalla (para dar de alta marcas nuevas de batería/PCS) ──
   Devuelve el mapa completo tag→valor tal cual lo lee la pantalla, más en qué página vive cada tag.
   El usuario descarga este JSON de un sitio de cada marca y así se extienden los patrones de lib/equipos.js. */
app.get('/api/supervisor/equipos/:id/raw', (req, res) => {
  const base = String(req.params.id).split('~')[0], site = sites.find((x) => x.id === base);
  if (!site) return res.status(404).json({ error: 'sitio no encontrado' });
  deepWatch[base] = Date.now();
  const d = deepData[base];
  if (!jmobile.isJMobileSite(site) || Number(site.port) === 7010 || (vncMgr && vncMgr.has(base))) return res.json({ disponible: false, motivo: 'Este sitio no es una pantalla JMobile.' });
  if (!supervisor.getConfig().lecturaDirecta) return res.json({ disponible: false, motivo: 'Lectura directa desactivada (modo solo pestañas).' });
  if (!d || !d.values) return res.json({ disponible: true, cargando: true, err: d && d.err || null });
  const sc = supervisor.sitioCfg(base) || {};
  res.json({ disponible: true, id: base, name: site.name, marca: sc.marca || null, pcsMarca: sc.pcsMarca || null,
    at: d.at, total: Object.keys(d.values).length, pageOf: d.pageOf || {}, values: d.values });
});
/* ── Histórico profundo: evolución de racks/celdas/PCS en el tiempo (para las gráficas del expand) ── */
app.get('/api/supervisor/equipos/:id/hist', (req, res) => {
  const base = String(req.params.id).split('~')[0], site = sites.find((x) => x.id === base);
  if (!site) return res.status(404).json({ error: 'sitio no encontrado' });
  const hours = Math.max(1, Math.min(24 * 90, parseInt(req.query.h || '24', 10) || 24));
  const q = deephist.query(base, { hours, maxPts: Math.max(200, Math.min(3000, parseInt(req.query.max || '1500', 10) || 1500)) });
  res.json(Object.assign({ id: base, name: site.name, hours }, q));
});
/* ── Diagnóstico: por qué un sitio no se ve "en vivo" (lo lee el servidor o depende de una pestaña) ── */
app.get('/api/supervisor/diag', (req, res) => {
  const shared = jmobile.sharedHosts();
  const esc = (x) => String(x == null ? '' : x).replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
  const ageS = (ms) => (ms == null || !isFinite(ms)) ? '∞' : Math.round(ms / 1000);
  const rows = sites.filter((s) => jmobile.isJMobileSite(s)).map((s) => {
    const v = supervisor.view(s.id) || {};
    const host = `${s.ip}:${s.port}`;
    const dS = supervisor.srcAge(s.id, 'directo'), nS = supervisor.srcAge(s.id, 'navegador');
    return { name: s.name, host, src: v.src || '—', dS: isFinite(dS) ? Math.round(dS / 1000) : Infinity, nS: isFinite(nS) ? Math.round(nS / 1000) : Infinity, shared: !!shared[host], err: v.lastErr || '' };
  }).sort((a, b) => b.dS - a.dS);   // los que el servidor lleva más sin leer, arriba
  const tr = rows.map((r) => {
    const malo = r.dS > 10;   // el servidor no lo lee hace >10 s
    return `<tr style="background:${malo ? '#2a1414' : '#0f1a12'}"><td>${esc(r.name)}</td><td>${esc(r.src)}</td><td style="text-align:right;color:${malo ? '#fca5a5' : '#86efac'}">${r.dS === Infinity ? '∞ (nunca)' : 'hace ' + r.dS + ' s'}</td><td style="text-align:right">${r.nS === Infinity ? '—' : 'hace ' + r.nS + ' s'}</td><td style="text-align:center">${r.shared ? '🌐 sí' : '—'}</td><td style="color:#fcd34d">${esc(r.err)}</td></tr>`;
  }).join('');
  res.type('html').send(`<meta charset="utf-8"><meta http-equiv="refresh" content="4"><title>Diagnóstico lectura</title><body style="font-family:system-ui;background:#0a0f16;color:#e5e7eb;padding:16px"><h2>¿Quién lee cada pantalla? (se refresca solo)</h2><p style="color:#94a3b8">Columna <b>Servidor</b> = hace cuánto el servidor leyó ese sitio. Si dice <b>∞ (nunca)</b> o un número grande, el servidor NO lo está leyendo (por eso tarda y se ve por "pestaña"). La columna <b>Error</b> dice por qué no pudo.</p><table border="1" cellpadding="6" style="border-collapse:collapse;font-size:13px"><tr style="background:#1e293b"><th>Pantalla</th><th>Fuente</th><th>Servidor (directo)</th><th>Pestaña (nav)</th><th>Cookie pestaña</th><th>Error del servidor</th></tr>${tr}</table></body>`);
});
/* ── Resumen de alarmas activas por sitio (para el símbolo en las tarjetas) ── */
app.get('/api/supervisor/alarmas', (req, res) => {
  const out = {}, now = Date.now(), ids = new Set([...Object.keys(deepAlarms), ...Object.keys(hmiAlarms)]);
  for (const id of ids) {
    const h = hmiAlarms[id], d = deepAlarms[id];
    // La lectura TAL CUAL del HMI gana mientras esté fresca (≤120 s). Si no hay HMI reciente, se usa la basada en etiquetas.
    const pick = (h && now - h.at < 120000) ? h : d;
    if (pick && (pick.items || []).length) out[id] = pick;
  }
  res.json(out);
});
/* ── Comunicación (estado + historial) ── */
let commsMgr = null;
app.get('/api/pv/estado', (req, res) => res.json(pvMgr ? pvMgr.estado() : { plantas: [], relays: {}, resumen: {} }));
app.get('/api/pv/historial/:key', (req, res) => res.json(pvMgr ? pvMgr.historial(req.params.key, req.query.d) : {}));
app.get('/api/pv/dia', (req, res) => res.json(pvMgr ? pvMgr.dia(req.query.d) : { plantas: [] }));
app.get('/api/pv/reporte', (req, res) => res.json(pvMgr ? pvMgr.reporte(req.query.desde, req.query.hasta) : { plantas: [] }));
app.post('/api/pv/filtro', requireAdmin, (req, res) => res.json(pvMgr ? pvMgr.setFiltro(!!(req.body && req.body.activo)) : {}));
app.get('/api/fusion/estado', (req, res) => res.json(fusionMgr ? fusionMgr.estado() : { plantas: [], relay: {} }));
app.get('/api/fusion/ess', (req, res) => res.json(fusionEssMgr ? fusionEssMgr.estado() : { plantas: [], resumen: {} }));
app.get('/api/fusion/historial/:dn', (req, res) => res.json(fusionMgr ? fusionMgr.historial(req.params.dn, req.query.d) : {}));
app.get('/api/fusion/dia', (req, res) => res.json(fusionMgr ? fusionMgr.dia(req.query.d) : { plantas: [] }));
app.get('/api/comm/estado', (req, res) => res.json(commsMgr ? commsMgr.estado() : {}));
app.get('/api/comm/sitio/:id', (req, res) => { if (!commsMgr) return res.json(null); const hoy = new Date(), k = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; const desde = isDay(req.query.desde) ? req.query.desde : k(new Date(Date.now() - 864e5)), hasta = isDay(req.query.hasta) ? req.query.hasta : k(hoy); res.json(commsMgr.historial(req.params.id, desde, hasta)); });
app.get('/api/comm/dia', (req, res) => { if (!commsMgr) return res.json(null); const d = isDay(req.query.d) ? req.query.d : (() => { const x = new Date(); return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-${String(x.getDate()).padStart(2, '0')}`; })(); res.json(commsMgr.dia(d)); });
app.get('/supervisor/comunicacion', requireAuth, (req, res) => enviarPagina(res, 'comunicacion.html'));
/* ── Respaldo completo / migración a otra PC ── */
app.get('/api/respaldo', requireAdmin, (req, res) => {
  try {
    const r = require('./lib/respaldo').respaldo(), d = new Date(), f = `respaldo-bess-monitor-${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}-${String(d.getHours()).padStart(2, '0')}${String(d.getMinutes()).padStart(2, '0')}.tar.gz`;
    res.set({ 'Content-Type': 'application/gzip', 'Content-Disposition': `attachment; filename="${f}"`, 'Content-Length': r.buf.length });
    res.end(r.buf);
  } catch (e) { res.status(500).json({ error: e.message }); }
});
app.post('/api/respaldo/restaurar', requireAdmin, express.raw({ type: '*/*', limit: '1gb' }), (req, res) => {
  try {
    const r = require('./lib/respaldo').restaurar(req.body);
    res.json(Object.assign({ ok: true, nota: 'Listo. Reinicia el BESS Monitor para que tome la configuración restaurada.' }, r));
  } catch (e) { res.status(400).json({ error: e.message }); }
});
/* ── Archivador automático por sitio (respaldo profesional a carpeta OneDrive/Drive) ── */
app.get('/api/archivador', requireApiAuth, (req, res) => { try { res.json(require('./lib/archivador').estado()); } catch (e) { res.json({ enabled: false, dir: '', error: e.message }); } });
app.post('/api/archivador', requireApiAuth, requireAdmin, (req, res) => {
  try {
    const arc = require('./lib/archivador'), cur = arc.leerCfg(), b = req.body || {};
    if (b.enabled !== undefined) cur.enabled = !!b.enabled;
    if (b.dir !== undefined) cur.dir = String(b.dir || '').trim();
    if (b.hora !== undefined) cur.hora = Math.max(0, Math.min(23, parseInt(b.hora, 10) || 0));
    if (b.minuto !== undefined) cur.minuto = Math.max(0, Math.min(59, parseInt(b.minuto, 10) || 0));
    if (b.incluir5s !== undefined) cur.incluir5s = !!b.incluir5s;
    if (b.formatos && typeof b.formatos === 'object') cur.formatos = Object.assign(cur.formatos || {}, b.formatos);
    arc.guardarCfg(cur); res.json(arc.estado());
  } catch (e) { res.status(400).json({ error: e.message }); }
});
app.post('/api/archivador/correr', requireApiAuth, requireAdmin, (req, res) => {
  try {
    const arc = require('./lib/archivador'); const b = req.body || {};
    const RE = /^\d{4}-\d{2}-\d{2}$/;
    const ayer = () => { const d = new Date(Date.now() - 864e5); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
    let from = b.from || b.day || null, to = b.to || b.day || null;
    if (!from) { from = to = ayer(); } else if (!to) { to = from; }
    if (!RE.test(from) || !RE.test(to)) return res.status(400).json({ error: 'fecha inválida (AAAA-MM-DD)' });
    const r = arc.tanda(from === to ? from : { from, to });
    res.json(Object.assign({ ok: true }, r || {}, { estado: arc.estado() }));
  } catch (e) { res.status(400).json({ error: e.message }); }
});
/* ── Sitios por VNC ── */
let vncMgr = null;
app.get('/api/vnc/estado', (req, res) => res.json(vncMgr ? vncMgr.status() : []));
app.get('/api/vnc/:id/config', (req, res) => res.json(vncMgr ? vncMgr.getConfig(req.params.id) : null));
app.put('/api/vnc/:id/config', requireAdmin, (req, res) => { if (!vncMgr) return res.status(503).json({ error: 'VNC no disponible' }); const r = vncMgr.setConfig(req.params.id, req.body || {}); if (!r) return res.status(404).json({ error: 'sitio no encontrado' }); res.json(r); });
app.get('/api/vnc/:id/frame.png', (req, res) => { const b = vncMgr && vncMgr.frame(req.params.id, Number(req.query.w) || 0); if (!b) return res.status(404).end(); res.set({ 'Content-Type': 'image/png', 'Cache-Control': 'no-store' }); res.end(b); });
app.post('/api/vnc/:id/probar', requireAdmin, async (req, res) => { try { res.json(await vncMgr.probar(req.params.id, (req.body && req.body.regiones) || [])); } catch (e) { res.status(400).json({ error: e.message }); } });
app.get('/supervisor/vnc', requireAuth, (req, res) => enviarPagina(res, 'vnc.html'));
app.get(['/supervisor/pv', '/supervisor/pv.html'], requireAuth, (req, res) => enviarPagina(res, 'pv.html'));
app.get(['/supervisor/pv/reportes', '/supervisor/pvrep.html'], requireAuth, (req, res) => enviarPagina(res, 'pvrep.html'));
app.get(['/supervisor/pv/validacion', '/supervisor/pvval.html'], requireAuth, (req, res) => enviarPagina(res, 'pvval.html'));
app.get('/api/pv/validacion', async (req, res) => {
  if (!pvMgr) return res.json({ plantas: [] });
  try {
    const v = pvMgr.validacion(req.query.dia || null);
    // clima del día por sitio (Open-Meteo) + veredicto de desempeño; en paralelo con límite para no saturar
    const sitios = v.plantas;
    for (let i = 0; i < sitios.length; i += 6) {
      await Promise.all(sitios.slice(i, i + 6).map(async (p) => {
        if (p.lat == null || p.lon == null) return;
        try { p.clima = await pvMgr.climaDia(p.lat, p.lon, v.dia); } catch (_) { p.clima = null; }
        if (p.clima && p.clima.hspDia && p.capacidadKwp > 0 && p.energiaFV != null) {
          const hsp = p.energiaFV / p.capacidadKwp, esp = p.clima.hspDia;
          p.desempeno = { hsp: Math.round(hsp * 100) / 100, espDiaHsp: esp, ratio: esp > 0 ? Math.round(hsp / esp * 100) / 100 : null, veredicto: esp > 0 ? (hsp / esp >= 0.8 ? 'correcta' : hsp / esp >= 0.5 ? 'regular' : 'baja') : null };
        }
      }));
    }
    res.json(v);
  } catch (e) { res.status(500).json({ error: e.message }); }
});
// configuración del envío por correo del reporte de validación
app.get('/api/pv/reporte-correo', (req, res) => { try { res.json(require('./lib/reportemail').leerCfg()); } catch (e) { res.json({ enabled: false, to: [] }); } });
app.post('/api/pv/reporte-correo', requireAdmin, (req, res) => {
  try { const rc = require('./lib/reportemail'); const cur = rc.leerCfg(); const b = req.body || {};
    if (Array.isArray(b.to)) cur.to = b.to.map(String).map((s) => s.trim()).filter(Boolean);
    if (Array.isArray(b.cc)) cur.cc = b.cc.map(String).map((s) => s.trim()).filter(Boolean);
    if (b.hora != null) cur.hora = Math.max(0, Math.min(23, parseInt(b.hora, 10) || 7));
    if (b.enabled != null) cur.enabled = !!b.enabled;
    rc.guardarCfg(cur); res.json(cur);
  } catch (e) { res.status(500).json({ error: e.message }); }
});
// enviar YA el reporte (día hábil anterior, o ?dia=YYYY-MM-DD) — para probar
app.post('/api/pv/validacion/enviar', requireAdmin, async (req, res) => {
  if (!pvMgr) return res.status(400).json({ ok: false, error: 'PV no iniciado' });
  try { const r = await require('./lib/reportemail').enviar(pvMgr, (req.body && req.body.dia) || null); res.json(r); }
  catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});
app.get('/api/supervisor/events', (req, res) => res.json(supervisor.getEvents(parseInt(req.query.limit || '200', 10))));
app.get('/api/supervisor/config', (req, res) => {
  const c = supervisor.publicConfig();
  if (req.session.user.role === 'admin') c.ingestToken = supervisor.getConfig().ingestToken;
  res.json(c);
});
app.put('/api/supervisor/config', requireAdmin, (req, res) => { const r = supervisor.updateConfig(req.body || {}); if (req.body && (req.body.scadaUser !== undefined || req.body.scadaPass)) jmobile.resetSessions(); res.json(r); });
app.delete('/api/supervisor/events', requireAdmin, (req, res) => { supervisor.clearEvents(); res.json({ ok: true }); });
app.put('/api/supervisor/sites/:id', requireAdmin, (req, res) => {
  if (!sites.find((s) => s.id === req.params.id)) return res.status(404).json({ error: 'sitio no encontrado' });
  res.json(supervisor.updateSite(req.params.id, req.body || {}));
});
app.post('/api/supervisor/rediscover/:id', requireAdmin, (req, res) => {
  jmobile.forget(req.params.id);
  res.json({ ok: true });
});
app.get('/api/supervisor/tags/:id', (req, res) => res.json(jmobile.cachedTags(req.params.id)));
app.post('/api/supervisor/ack', (req, res) => {
  const { siteId, code } = req.body || {};
  supervisor.ack(siteId, code);
  res.json({ ok: true });
});

app.get('/api/cities', (req, res) => {
  res.json(cityCoords);
});

app.post('/api/geocode', requireAdmin, async (req, res) => {
  const { address } = req.body || {};
  if (!address) return res.status(400).json({ error: 'falta la dirección' });
  try {
    const result = await geocode.geocodeAddress(address);
    if (!result) return res.status(404).json({ error: 'No se encontró esa dirección' });
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/cities', requireAdmin, (req, res) => {
  const { name, lat, lng } = req.body || {};
  if (!name || lat == null || lng == null) return res.status(400).json({ error: 'nombre, lat y lng son obligatorios' });
  cityCoords[name] = { lat: parseFloat(lat), lng: parseFloat(lng) };
  writeFileWithRetry(CITIES_FILE, JSON.stringify(cityCoords, null, 2));
  res.status(201).json(cityCoords[name]);
});

app.get('/api/weather', async (req, res) => {
  const citiesInUse = Array.from(new Set(sites.map((s) => s.city).filter(Boolean)));
  const entries = await Promise.all(
    citiesInUse.map(async (city) => [city, await getWeatherForCity(city)])
  );
  res.json(Object.fromEntries(entries));
});

app.get('/api/weather/storm-check', async (req, res) => {
  const { city, ts } = req.query;
  if (!city || !ts) return res.status(400).json({ error: 'faltan city y ts' });
  const history = await getHourlyHistoryForCity(city);
  if (!history) return res.json(null);
  res.json(weather.findStormAt(history, parseInt(ts, 10)));
});

app.get('/api/sites/:id/history', (req, res) => {
  const limit = parseInt(req.query.limit || '100', 10);
  res.json(store.getHistory(req.params.id, limit));
});

// ---------- Historial enriquecido (con duración de cada caída) + filtros ----------

function enrichedEvents() {
  const raw = store.getEvents(5000);
  const bySite = {};
  raw.forEach((e) => (bySite[e.siteId] = bySite[e.siteId] || []).push(e));

  const enrichedById = new Map();
  Object.values(bySite).forEach((list) => {
    const asc = list.slice().sort((a, b) => a.ts - b.ts);
    let openOfflineTs = null;
    asc.forEach((e) => {
      if (e.to === 'offline') {
        openOfflineTs = e.ts;
      } else if (e.to === 'online' && openOfflineTs != null) {
        enrichedById.set(e.id, e.ts - openOfflineTs);
        openOfflineTs = null;
      }
    });
  });

  return raw.map((e) => {
    const noteData = store.getEventNote(e.id);
    return { ...e, durationMs: enrichedById.get(e.id) || null, note: noteData ? noteData.note : null };
  });
}

function filterEvents(events, { siteId, from, to, type }) {
  return events.filter((e) => {
    if (siteId && siteId !== 'all' && e.siteId !== siteId) return false;
    if (from && e.ts < from) return false;
    if (to && e.ts > to) return false;
    if (type && type !== 'all' && e.to !== type) return false;
    return true;
  });
}

app.put('/api/sites/:id/maintenance', (req, res) => {
  const site = sites.find((s) => s.id === req.params.id);
  if (!site) return res.status(404).json({ error: 'sitio no encontrado' });
  const author = req.session && req.session.user ? req.session.user.username : null;
  const { note, until, type } = req.body || {};
  const saved = store.setMaintenance(site.id, { note, by: author, until: until || null, type });
  io.emit('site:update', publicSiteView(site));
  res.json(saved);
});

app.delete('/api/sites/:id/maintenance', (req, res) => {
  const site = sites.find((s) => s.id === req.params.id);
  if (!site) return res.status(404).json({ error: 'sitio no encontrado' });
  store.clearMaintenance(site.id);
  io.emit('site:update', publicSiteView(site));
  res.status(204).end();
});

app.put('/api/sites/:id/assign', (req, res) => {
  const site = sites.find((s) => s.id === req.params.id);
  if (!site) return res.status(404).json({ error: 'sitio no encontrado' });
  const author = req.session && req.session.user ? req.session.user.username : null;
  const { assignedTo } = req.body || {};
  if (!assignedTo) return res.status(400).json({ error: 'falta assignedTo' });
  const saved = store.setAssignment(site.id, assignedTo, author);
  io.emit('site:update', publicSiteView(site));
  res.json(saved);
});

app.delete('/api/sites/:id/assign', (req, res) => {
  const site = sites.find((s) => s.id === req.params.id);
  if (!site) return res.status(404).json({ error: 'sitio no encontrado' });
  store.clearAssignment(site.id);
  io.emit('site:update', publicSiteView(site));
  res.status(204).end();
});

app.get('/api/sites/:id/latency-history', (req, res) => {
  const days = Math.max(1, parseInt(req.query.days || '7', 10));
  res.json(store.getHourlyHistory(req.params.id, days));
});

app.get('/api/sites/:id/daily-uptime', (req, res) => {
  const days = Math.max(1, Math.min(120, parseInt(req.query.days || '120', 10)));
  res.json(store.getDailyUptime(req.params.id, days));
});

app.put('/api/events/:eventId/note', (req, res) => {
  const { note } = req.body || {};
  const author = req.session && req.session.user ? req.session.user.username : null;
  const saved = store.setEventNote(req.params.eventId, (note || '').trim(), author);
  res.json(saved || { cleared: true });
});

app.get('/api/events', (req, res) => {
  const limit = parseInt(req.query.limit || '200', 10);
  const { siteId, type } = req.query;
  const from = req.query.from ? parseInt(req.query.from, 10) : null;
  const to = req.query.to ? parseInt(req.query.to, 10) : null;

  if (siteId || type || from || to) {
    const filtered = filterEvents(enrichedEvents(), { siteId, from, to, type });
    return res.json(filtered.slice(0, limit));
  }
  res.json(store.getEvents(limit));
});

app.post('/api/sites', requireAdmin, (req, res) => {
  const { name, ip, port, scadaEndpoint, notes, city, group, address, exactLat, exactLng } = req.body || {};
  if (!name || !ip) return res.status(400).json({ error: 'name e ip son obligatorios' });
  const id = 'site-' + Date.now();
  const site = {
    id, name, ip, port: port || null, scadaEndpoint: scadaEndpoint || null, notes: notes || '',
    city: city || null, group: group || null, address: address || null,
    exactLat: exactLat != null && exactLat !== '' ? Number(exactLat) : null,
    exactLng: exactLng != null && exactLng !== '' ? Number(exactLng) : null,
  };
  try {
    sites.push(site);
    persistSites(sites);
    initState(site);
    ensureSiteScheduled(site, sites.length - 1);
    io.emit('sites:changed', sites.map(publicSiteView));
    res.status(201).json(publicSiteView(site));
  } catch (err) {
    sites.pop();
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/sites/:id', requireAdmin, (req, res) => {
  const site = sites.find((s) => s.id === req.params.id);
  if (!site) return res.status(404).json({ error: 'sitio no encontrado' });
  const { name, ip, port, scadaEndpoint, notes, city, group, address, exactLat, exactLng } = req.body || {};
  const before = { ...site };
  if (name !== undefined) site.name = name;
  if (ip !== undefined) site.ip = ip;
  if (port !== undefined) site.port = port || null;
  if (scadaEndpoint !== undefined) site.scadaEndpoint = scadaEndpoint || null;
  if (notes !== undefined) site.notes = notes;
  if (city !== undefined) site.city = city || null;
  if (group !== undefined) site.group = group || null;
  if (address !== undefined) site.address = address || null;
  if (exactLat !== undefined) site.exactLat = exactLat != null && exactLat !== '' ? Number(exactLat) : null;
  if (exactLng !== undefined) site.exactLng = exactLng != null && exactLng !== '' ? Number(exactLng) : null;
  try {
    persistSites(sites);
    io.emit('sites:changed', sites.map(publicSiteView));
    res.json(publicSiteView(site));
  } catch (err) {
    Object.assign(site, before);
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/sites/:id', requireAdmin, (req, res) => {
  const idx = sites.findIndex((s) => s.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'sitio no encontrado' });
  const [removed] = sites.splice(idx, 1);
  try {
    persistSites(sites);
    state.delete(req.params.id);
    io.emit('sites:changed', sites.map(publicSiteView));
    res.status(204).end();
  } catch (err) {
    sites.splice(idx, 0, removed);
    res.status(500).json({ error: err.message });
  }
});

// ---------- Configuración de alertas externas (Teams / futuro WhatsApp) ----------

app.get('/api/alerts-config', (req, res) => {
  // No se expone la URL completa del webhook por pantalla, solo si está configurada.
  res.json({
    teamsConfigured: Boolean(alertsConfig.teamsWebhookUrl),
    notifyOnOffline: alertsConfig.notifyOnOffline,
    notifyOnRecovery: alertsConfig.notifyOnRecovery,
    notifyOnIntermittent: alertsConfig.notifyOnIntermittent,
  });
});

app.put('/api/alerts-config', requireAdmin, (req, res) => {
  const { teamsWebhookUrl, notifyOnOffline, notifyOnRecovery, notifyOnIntermittent } = req.body || {};
  if (teamsWebhookUrl !== undefined) alertsConfig.teamsWebhookUrl = teamsWebhookUrl || null;
  if (notifyOnOffline !== undefined) alertsConfig.notifyOnOffline = Boolean(notifyOnOffline);
  if (notifyOnRecovery !== undefined) alertsConfig.notifyOnRecovery = Boolean(notifyOnRecovery);
  if (notifyOnIntermittent !== undefined) alertsConfig.notifyOnIntermittent = Boolean(notifyOnIntermittent);
  persistAlertsConfig(alertsConfig);
  res.json({ teamsConfigured: Boolean(alertsConfig.teamsWebhookUrl) });
});

app.post('/api/alerts-test', async (req, res) => {
  if (!alertsConfig.teamsWebhookUrl) return res.status(400).json({ error: 'No hay webhook de Teams configurado' });
  const result = await sendTeamsAlert({
    siteName: 'Sitio de prueba',
    ip: '0.0.0.0',
    from: 'online',
    to: 'offline',
    ts: Date.now(),
    message: 'Este es un mensaje de prueba desde BESS Monitor.',
  }, alertsConfig);
  res.json(result);
});

// ---------- Credenciales SCADA (para auto-login antes de la captura) ----------

app.get('/api/scada-auth', (req, res) => {
  res.json({ configured: Boolean(scadaAuth.username && scadaAuth.password) });
});

app.put('/api/scada-auth', requireAdmin, (req, res) => {
  const { username, password } = req.body || {};
  if (username !== undefined) scadaAuth.username = username || null;
  if (password !== undefined) scadaAuth.password = password || null;
  persistScadaAuth(scadaAuth);
  res.json({ configured: Boolean(scadaAuth.username && scadaAuth.password) });
});

// ---------- Lectura visual (OCR) de SOC/temperatura ----------

function httpAccessUrl(site) {
  if (!site.port || ![7000, 7010, 7020].includes(site.port)) return null;
  return `http://${site.ip}:${site.port}`;
}

app.get('/api/vision/screenshot/:id', async (req, res) => {
  const site = sites.find((s) => s.id === req.params.id);
  if (!site) return res.status(404).json({ error: 'sitio no encontrado' });
  const url = httpAccessUrl(site);
  if (!url) return res.status(400).json({ error: 'este sitio no tiene una pantalla HTTP (usa VNC)' });
  const navigation = (req.query.nav || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
  try {
    const buffer = await vision.screenshotUrl(url, { credentials: scadaAuth, navigation });
    res.setHeader('Content-Type', 'image/png');
    res.send(buffer);
  } catch (err) {
    console.error(`[vision] Falló la captura de ${site.name} (${url}):`, err.message);
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/vision/config/:id', (req, res) => {
  res.json(visionConfig[req.params.id] || null);
});

app.get('/api/vision/fields/:id', (req, res) => {
  res.json((visionConfig[req.params.id] && visionConfig[req.params.id].fields) || []);
});

app.put('/api/vision/fields/:id', requireAdmin, (req, res) => {
  const { fields } = req.body || {};
  if (!Array.isArray(fields)) return res.status(400).json({ error: 'fields debe ser un arreglo' });
  const current = visionConfig[req.params.id] || {};
  current.fields = fields;
  visionConfig[req.params.id] = current;
  persistVisionConfig(visionConfig);
  res.json({ fields: current.fields });
});

app.put('/api/vision/config/:id', requireAdmin, (req, res) => {
  const { socRegion, tempRegion, socNavigation, tempNavigation } = req.body || {};
  const current = visionConfig[req.params.id] || {};
  if (socRegion !== undefined) current.socRegion = socRegion;
  if (tempRegion !== undefined) current.tempRegion = tempRegion;
  if (socNavigation !== undefined) current.socNavigation = socNavigation;
  if (tempNavigation !== undefined) current.tempNavigation = tempNavigation;
  visionConfig[req.params.id] = current;
  persistVisionConfig(visionConfig);
  res.json(current);
});

app.delete('/api/vision/config/:id', requireAdmin, (req, res) => {
  delete visionConfig[req.params.id];
  persistVisionConfig(visionConfig);
  const st = state.get(req.params.id);
  if (st) { st.scada = null; st.scadaError = null; }
  res.status(204).end();
});

app.post('/api/vision/test-field/:id', async (req, res) => {
  const site = sites.find((s) => s.id === req.params.id);
  if (!site) return res.status(404).json({ error: 'sitio no encontrado' });
  const url = httpAccessUrl(site);
  if (!url) return res.status(400).json({ error: 'este sitio no tiene una pantalla HTTP (usa VNC)' });
  const { region, navigation, kind } = req.body || {};
  if (!region) return res.status(400).json({ error: 'falta la región a leer' });
  try {
    const results = await vision.readSiteFields(
      url,
      [{ id: 'preview', kind: kind || 'generic', region, navigation: navigation || [] }],
      scadaAuth
    );
    res.json(results.preview || { value: null, raw: '' });
  } catch (err) {
    console.error(`[vision] Falló la prueba de campo de ${site.name} (${url}):`, err.message);
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/vision/test/:id', async (req, res) => {
  const site = sites.find((s) => s.id === req.params.id);
  if (!site) return res.status(404).json({ error: 'sitio no encontrado' });
  const url = httpAccessUrl(site);
  if (!url) return res.status(400).json({ error: 'este sitio no tiene una pantalla HTTP (usa VNC)' });

  const config = {
    socRegion: req.body?.socRegion || visionConfig[site.id]?.socRegion,
    tempRegion: req.body?.tempRegion || visionConfig[site.id]?.tempRegion,
    socNavigation: req.body?.socNavigation || visionConfig[site.id]?.socNavigation,
    tempNavigation: req.body?.tempNavigation || visionConfig[site.id]?.tempNavigation,
  };
  if (!config.socRegion && !config.tempRegion) {
    return res.status(400).json({ error: 'no hay ninguna región marcada todavía' });
  }
  try {
    const result = await vision.readSiteVision(url, config, scadaAuth);
    res.json(result);
  } catch (err) {
    console.error(`[vision] Falló la prueba de lectura de ${site.name} (${url}):`, err.message);
    res.status(500).json({ error: err.message });
  }
});

function getOutageReport() {
  const now = Date.now();
  const allEvents = store.getEvents(5000);

  const buildRow = (site) => {
    const lastOfflineEvent = allEvents.find((e) => e.siteId === site.id && e.to === 'offline');
    const since = lastOfflineEvent ? lastOfflineEvent.ts : null;
    const note = lastOfflineEvent ? store.getEventNote(lastOfflineEvent.id) : null;
    return {
      id: site.id,
      name: site.name,
      ip: site.ip,
      city: site.city,
      group: site.group,
      since,
      durationMs: since ? now - since : null,
      durationText: since ? formatDuration(now - since) : 'desconocido',
      note: note ? note.note : null,
    };
  };

  const realOutages = [];
  const maintenanceOutages = [];
  sites.forEach((site) => {
    const maint = store.getMaintenance(site.id);
    if (maint) {
      // Un sitio marcado (mantenimiento / fuera de operación / sin comunicación
      // conocida) entra aquí SIEMPRE, esté en línea o no ahorita mismo — lo
      // que importa es que ya está identificado, no su estado de conexión
      // en este instante exacto.
      const durationMs = now - maint.since;
      maintenanceOutages.push({
        id: site.id,
        name: site.name,
        ip: site.ip,
        city: site.city,
        group: site.group,
        since: maint.since,
        durationMs,
        durationText: formatDuration(durationMs),
        note: null,
        maintenanceNote: maint.note || null,
        maintenanceType: maint.type || 'mantenimiento',
      });
    } else if ((state.get(site.id) || {}).status === 'offline') {
      realOutages.push(buildRow(site));
    }
  });

  realOutages.sort((a, b) => (b.durationMs || 0) - (a.durationMs || 0));
  maintenanceOutages.sort((a, b) => (b.durationMs || 0) - (a.durationMs || 0));

  return {
    generatedAt: now,
    totalSites: sites.length,
    offlineCount: realOutages.length,
    maintenanceCount: maintenanceOutages.length,
    onlineCount: sites.length - realOutages.length - maintenanceOutages.length,
    sites: realOutages,
    maintenanceSites: maintenanceOutages,
  };
}

function buildOutageReportText(report) {
  const fecha = new Date(report.generatedAt).toLocaleString('es-MX');
  const parts = [`📋 Reporte de comunicación — ${fecha}`];

  if (report.offlineCount === 0) {
    parts.push(`✅ Los ${report.totalSites} sitios están en línea (fuera de los marcados como conocidos). Sin caídas activas.`);
  } else {
    const lines = report.sites.map((s) =>
      `🔴 ${s.name} (${s.ip})${s.city ? ' · ' + s.city : ''} — sin comunicación desde las ${new Date(s.since).toLocaleTimeString('es-MX')} (hace ${s.durationText})${s.note ? `\n   📝 ${s.note}` : ''}`
    );
    parts.push(`${report.offlineCount} de ${report.totalSites} sitios sin comunicación:\n\n${lines.join('\n')}`);
    parts.push(`✅ Los otros ${report.onlineCount} sitios están en línea.`);
  }

  if (report.maintenanceCount > 0) {
    const typeLabel = { mantenimiento: 'en mantenimiento', fuera_operacion: 'fuera de operación', sin_comunicacion: 'sin comunicación conocida (silenciado)' };
    const typeIcon = { mantenimiento: '🔧', fuera_operacion: '⚫', sin_comunicacion: '🔕' };
    const maintLines = report.maintenanceSites.map((s) =>
      `${typeIcon[s.maintenanceType] || '🔧'} ${s.name} (${s.ip}) — ${typeLabel[s.maintenanceType] || 'en mantenimiento'}${s.maintenanceNote ? ': ' + s.maintenanceNote : ''} (desde hace ${s.durationText})`
    );
    parts.push(`Marcados como conocidos (no cuentan como falla nueva):\n\n${maintLines.join('\n')}`);
  }

  return parts.join('\n\n');
}

// ---------- Reporte de sitios sin comunicación ----------

app.get('/api/outage-report', (req, res) => {
  const report = getOutageReport();
  res.json({ ...report, text: buildOutageReportText(report) });
});

app.post('/api/outage-report/send-teams', requireAdmin, async (req, res) => {
  if (!alertsConfig.teamsWebhookUrl) return res.status(400).json({ error: 'No hay webhook de Teams configurado' });
  const report = getOutageReport();
  const text = buildOutageReportText(report);
  const result = await sendTeamsText(text, 'Reporte de comunicación — BESS Monitor', alertsConfig);
  res.json(result);
});

// ---------- Ranking de sitios más problemáticos ----------

function computeRanking(days) {
  const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
  const events = store.getEvents(5000).filter((e) => e.ts >= cutoff);

  const bySite = {};
  events.forEach((e) => {
    (bySite[e.siteId] = bySite[e.siteId] || []).push(e);
  });

  const rows = sites.map((site) => {
    const evs = (bySite[site.id] || []).slice().sort((a, b) => a.ts - b.ts);
    let drops = 0;
    let downtimeMs = 0;
    let openOfflineTs = null;

    evs.forEach((e) => {
      if (e.to === 'offline') {
        drops += 1;
        openOfflineTs = e.ts;
      } else if (e.to === 'online' && openOfflineTs != null) {
        downtimeMs += e.ts - openOfflineTs;
        openOfflineTs = null;
      }
    });
    if (openOfflineTs != null) downtimeMs += Date.now() - openOfflineTs;

    const st = state.get(site.id);
    return {
      id: site.id,
      name: site.name,
      ip: site.ip,
      drops,
      downtimeMs,
      currentStatus: st ? st.status : 'unknown',
      uptimePct: store.uptimePercent(site.id),
    };
  });

  rows.sort((a, b) => b.drops - a.drops || b.downtimeMs - a.downtimeMs);
  return rows;
}

app.get('/api/monthly-report', (req, res) => {
  const days = Math.max(1, parseInt(req.query.days || '30', 10));
  const ranking = computeRanking(days);

  const totalSites = sites.length;
  const validUptimes = ranking.filter((r) => r.uptimePct != null).map((r) => r.uptimePct);
  const avgUptime = validUptimes.length ? Math.round((validUptimes.reduce((a, b) => a + b, 0) / validUptimes.length) * 10) / 10 : null;
  const totalDrops = ranking.reduce((sum, r) => sum + r.drops, 0);
  const totalDowntimeMs = ranking.reduce((sum, r) => sum + r.downtimeMs, 0);

  const byGroup = {};
  sites.forEach((site) => {
    const g = site.group || 'Sin asignar';
    const r = ranking.find((x) => x.id === site.id);
    if (!byGroup[g]) byGroup[g] = { count: 0, uptimeSum: 0, uptimeCount: 0, drops: 0 };
    byGroup[g].count++;
    if (r) {
      byGroup[g].drops += r.drops;
      if (r.uptimePct != null) { byGroup[g].uptimeSum += r.uptimePct; byGroup[g].uptimeCount++; }
    }
  });
  const groupSummary = Object.entries(byGroup).map(([name, g]) => ({
    name,
    siteCount: g.count,
    drops: g.drops,
    avgUptime: g.uptimeCount ? Math.round((g.uptimeSum / g.uptimeCount) * 10) / 10 : null,
  })).sort((a, b) => (a.avgUptime ?? 100) - (b.avgUptime ?? 100));

  const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
  const notableEvents = filterEvents(enrichedEvents(), { from: cutoff })
    .filter((e) => e.note)
    .slice(0, 30);

  res.json({
    generatedAt: Date.now(),
    days,
    totalSites,
    avgUptime,
    totalDrops,
    totalDowntimeMs,
    ranking: ranking.slice(0, 15),
    groupSummary,
    notableEvents,
  });
});

app.get('/api/ranking', (req, res) => {
  const days = Math.max(1, parseInt(req.query.days || '7', 10));
  res.json(computeRanking(days));
});

// ---------- Exportación CSV ----------

function formatDuration(ms) {
  const totalMin = Math.round(ms / 60000);
  if (totalMin < 1) return '<1 min';
  if (totalMin < 60) return `${totalMin} min`;
  const h = Math.floor(totalMin / 60);
  const m = totalMin % 60;
  return m ? `${h}h ${m}min` : `${h}h`;
}

function toCsvValue(v) {
  const s = v === null || v === undefined ? '' : String(v);
  if (/[",\n]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

function rowsToCsv(headers, rows) {
  const lines = [headers.join(',')];
  rows.forEach((row) => {
    lines.push(headers.map((h) => toCsvValue(row[h])).join(','));
  });
  return lines.join('\n');
}

app.get('/api/export/events.csv', (req, res) => {
  const { siteId, type } = req.query;
  let from = req.query.from ? parseInt(req.query.from, 10) : null;
  let to = req.query.to ? parseInt(req.query.to, 10) : null;
  if (!from && !to && req.query.days) {
    from = Date.now() - Math.max(1, parseInt(req.query.days, 10)) * 24 * 60 * 60 * 1000;
  }

  const events = filterEvents(enrichedEvents(), { siteId, from, to, type })
    .map((e) => ({
      ...e,
      fecha: new Date(e.ts).toLocaleString('es-MX'),
      duracion: e.durationMs != null ? formatDuration(e.durationMs) : '',
    }));
  const csv = rowsToCsv(['fecha', 'siteName', 'ip', 'from', 'to', 'duracion', 'message'], events);
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="eventos.csv"`);
  res.send('\uFEFF' + csv); // BOM para que Excel abra bien los acentos
});

app.get('/api/export/ranking.csv', (req, res) => {
  const days = Math.max(1, parseInt(req.query.days || '7', 10));
  const ranking = computeRanking(days).map((r) => ({
    ...r,
    downtimeMinutos: Math.round(r.downtimeMs / 60000),
  }));
  const csv = rowsToCsv(
    ['name', 'ip', 'drops', 'downtimeMinutos', 'uptimePct', 'currentStatus'],
    ranking
  );
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="ranking_${days}d.csv"`);
  res.send('\uFEFF' + csv);
});

// ---------- Motor de monitoreo de conectividad ----------

const STATUS_LABELS = {
  online: 'en línea',
  intermittent: 'intermitente',
  offline: 'desconectado',
  unknown: 'sin datos',
};

async function pollConnectivity(site) {
  const st = state.get(site.id);
  const result = await checkSite(site);
  const now = Date.now();
  const prevStatus = st.status;

  st.lastCheck = now;
  st.latencyMs = result.up ? result.latencyMs : null;

  if (result.up) {
    st.consecutiveOK += 1;
    st.consecutiveFails = 0;
    if (prevStatus === 'offline') {
      st.status = 'online';
    } else if (prevStatus === 'intermittent') {
      st.status = st.consecutiveOK >= 3 ? 'online' : 'intermittent';
    } else {
      st.status = 'online';
    }
  } else {
    st.consecutiveFails += 1;
    st.consecutiveOK = 0;
    if (st.consecutiveFails >= FAILS_FOR_OFFLINE) {
      st.status = 'offline';
    } else if (st.consecutiveFails >= INTERMITTENT_FAILS) {
      // 2+ fallos seguidos: ya es intermitente de verdad
      st.status = prevStatus === 'offline' ? 'offline' : 'intermittent';
    } else {
      // 1 solo fallo: lo absorbemos (no cambiamos de estado) para no marcar
      // caídas falsas por un parpadeo de VPN o por la PC saturada un instante.
      st.status = prevStatus === 'unknown' ? 'intermittent' : prevStatus;
    }
  }

  if (st.status === 'offline' && prevStatus !== 'offline') {
    st.offlineSince = now;
    st.escalationLevel = 0;
  } else if (st.status === 'online') {
    st.offlineSince = null;
    st.escalationLevel = 0;
    if (prevStatus === 'offline' || prevStatus === 'intermittent') {
      store.clearAssignment(site.id); // ya se resolvió, no hace falta seguir "asignado"
    }
  }

  const inMaintenance = Boolean(store.getMaintenance(site.id));

  store.addHistoryPoint(site.id, { t: now, up: result.up, latencyMs: result.latencyMs });

  if (st.status !== prevStatus && prevStatus !== 'unknown') {
    const evt = {
      id: `${site.id}-${now}`,
      siteId: site.id,
      siteName: site.name,
      ip: site.ip,
      from: prevStatus,
      to: st.status,
      ts: now,
      message: buildEventMessage(site, prevStatus, st.status),
      inMaintenance,
    };
    store.addEvent(evt);
    io.emit('site:statusChange', evt);

    const shouldNotify = !inMaintenance && (
      (st.status === 'offline' && alertsConfig.notifyOnOffline) ||
      (st.status === 'online' && (prevStatus === 'offline' || prevStatus === 'intermittent') && alertsConfig.notifyOnRecovery) ||
      (st.status === 'intermittent' && alertsConfig.notifyOnIntermittent)
    );

    if (shouldNotify) {
      sendTeamsAlert(evt, alertsConfig).catch((err) => console.error('Fallo alerta Teams:', err.message));
    }
  }

  if (st.status === 'offline' && st.offlineSince && !inMaintenance) {
    checkEscalation(site, st, now);
  }

  const view = publicSiteView(site);
  io.emit('site:update', view);
}

function checkEscalation(site, st, now) {
  const minutesDown = (now - st.offlineSince) / 60000;
  // De mayor a menor, para que si el sitio lleva mucho tiempo caído (ej. el
  // programa se acaba de prender) salte directo al nivel que le toca, no
  // uno por uno.
  for (let i = ESCALATION_LEVELS.length - 1; i >= 0; i--) {
    const lvl = ESCALATION_LEVELS[i];
    if (minutesDown >= lvl.minutes && st.escalationLevel < lvl.level) {
      st.escalationLevel = lvl.level;
      const payload = {
        siteId: site.id,
        siteName: site.name,
        ip: site.ip,
        level: lvl.level,
        code: lvl.code,
        label: lvl.label,
        minutesDown: Math.round(minutesDown),
        ts: now,
      };
      io.emit('site:escalation', payload);
      if (lvl.level >= 3 && alertsConfig.teamsWebhookUrl) {
        const text = `🚨 ${lvl.label.toUpperCase()} — ${site.name} (${site.ip}) lleva ${Math.round(minutesDown)} minutos sin comunicación.`;
        sendTeamsText(text, `BESS Monitor — ${lvl.label}`, alertsConfig).catch(() => {});
      }
      break; // ya se disparó el nivel más alto que le toca por ahora
    }
  }
}

function buildEventMessage(site, from, to) {
  if (to === 'offline') return `${site.name} (${site.ip}) perdió comunicación`;
  if (to === 'online' && (from === 'offline' || from === 'intermittent')) {
    return `${site.name} (${site.ip}) recuperó comunicación`;
  }
  if (to === 'intermittent') return `${site.name} (${site.ip}) presenta comunicación intermitente`;
  return `${site.name} (${site.ip}) cambió de ${STATUS_LABELS[from]} a ${STATUS_LABELS[to]}`;
}

async function pollScada(site) {
  if (!site.scadaEndpoint) return;
  const st = state.get(site.id);
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000);
    const resp = await fetch(site.scadaEndpoint, { signal: controller.signal });
    clearTimeout(timeout);
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const data = await resp.json();
    st.scada = data;
    st.scadaError = null;
    st.scadaUpdatedAt = Date.now();
    io.emit('site:scada', { siteId: site.id, scada: data, scadaUpdatedAt: st.scadaUpdatedAt });
    supervisor.ingest(site.id, data, 'scada');
  } catch (err) {
    st.scadaError = err.message;
    st.scadaUpdatedAt = Date.now();
    io.emit('site:scada', { siteId: site.id, scada: null, scadaError: err.message, scadaUpdatedAt: st.scadaUpdatedAt });
  }
}

const POWER_STANDBY_THRESHOLD = 5; // kW o unidad equivalente; por debajo de esto se considera standby

function deriveStatus(powerValue) {
  if (powerValue == null || Number.isNaN(powerValue)) return null;
  if (Math.abs(powerValue) < POWER_STANDBY_THRESHOLD) return 'standby';
  return powerValue > 0 ? 'descargando' : 'cargando';
}

async function pollVision(site) {
  const config = visionConfig[site.id];
  if (!config) return;
  const url = httpAccessUrl(site);
  if (!url) return;
  const st = state.get(site.id);

  try {
    if (config.fields && config.fields.length) {
      const results = await vision.readSiteFields(url, config.fields, scadaAuth);
      const fieldsOut = config.fields.map((f) => ({
        id: f.id,
        label: f.label,
        kind: f.kind || 'generic',
        unit: f.unit || '',
        value: results[f.id] ? results[f.id].value : null,
        raw: results[f.id] ? results[f.id].raw : '',
      }));
      const powerField = fieldsOut.find((f) => f.kind === 'power' && f.value != null);
      const colorField = fieldsOut.find((f) => f.kind === 'color-status' && f.value != null);
      const data = {
        fields: fieldsOut,
        status: colorField ? colorField.value : (powerField ? deriveStatus(powerField.value) : null),
      };
      st.scada = data;
      st.scadaError = null;
      st.scadaUpdatedAt = Date.now();
      io.emit('site:scada', { siteId: site.id, scada: data, scadaUpdatedAt: st.scadaUpdatedAt });
      supervisor.ingest(site.id, data, 'ocr');
    } else if (config.socRegion || config.tempRegion) {
      // Compatibilidad con calibraciones antiguas (solo SOC/temperatura).
      const result = await vision.readSiteVision(url, config, scadaAuth);
      const data = {};
      if (result.soc != null) data.soc = result.soc;
      if (result.tempC != null) data.tempC = result.tempC;
      st.scada = data;
      st.scadaError = null;
      st.scadaUpdatedAt = Date.now();
      io.emit('site:scada', { siteId: site.id, scada: data, scadaUpdatedAt: st.scadaUpdatedAt });
      supervisor.ingest(site.id, data, 'ocr');
    }
  } catch (err) {
    st.scadaError = err.message;
    st.scadaUpdatedAt = Date.now();
    io.emit('site:scada', { siteId: site.id, scada: null, scadaError: err.message, scadaUpdatedAt: st.scadaUpdatedAt });
  }
}

// ---------- SUPERVISOR: lectura continua mientras la pantalla está abierta ----------
// En cuanto alguien abre /supervisor, el monitor lee TODOS los sitios calibrados
// de forma continua (unos cuantos a la vez), sin esperar el intervalo normal de
// 45 s. Cuando se cierra la última pantalla del supervisor, vuelve al ritmo normal.
const SUP_CYCLE_MS = parseInt(process.env.SUPERVISOR_CYCLE_MS || '1500', 10);     // pausa mínima entre vueltas
const SUP_CONCURRENCY = parseInt(process.env.SUPERVISOR_CONCURRENCY || '12', 10);   // sitios leídos al mismo tiempo
const visionInFlight = new Set();
async function pollVisionSafe(site) {
  if (visionInFlight.has(site.id)) return;          // nunca dos lecturas del mismo sitio a la vez
  visionInFlight.add(site.id);
  try { await pollVision(site); } finally { visionInFlight.delete(site.id); }
}
function isSiteCalibrated(id) {
  const site = sites.find((s) => s.id === id);
  if (!site) return false;
  const vc = visionConfig[id];
  if (vncMgr && vncMgr.has(id)) return true;          // sitio por VNC
  if (jmobile.isJMobileSite(site)) return true;       // lectura directa: no necesita calibración
  return Boolean(site.scadaEndpoint) || Boolean(vc && httpAccessUrl(site) && ((vc.fields && vc.fields.length) || vc.socRegion || vc.tempRegion));
}
const supViewers = new Set();
let supLoopRunning = false;
let supLastCycle = { ms: null, at: null, sites: 0 };
// v23 — SEPARACIÓN "BESS Monitor" vs "Supervisor en vivo":
// El supervisor (telemetría, INICIOS DE SESIÓN en las pantallas y monitoreo de las pestañas) ya
// NO corre 24/7 por defecto. Solo se activa cuando alguien abre la pantalla "Supervisor en vivo"
// (que emite 'supervisor:join'). Abrir el BESS Monitor (solo comunicación/pings) ya NO lo activa.
// Los pings de conectividad y el "Reporte de comunicación" siguen corriendo siempre, aparte.
// Para volver al modo 24/7 (grabar histórico aunque nadie tenga la pantalla abierta): SUPERVISOR_SIEMPRE=1.
function supAlwaysOn() { return process.env.SUPERVISOR_SIEMPRE === '1'; }
function supActive() { return supViewers.size > 0 || supAlwaysOn(); }
function supStatus() {
  return { active: supActive(), alwaysOn: supAlwaysOn(), relay: sites.filter((s) => supervisor.srcAge(s.id, 'navegador') < 20000).length, respaldo: sites.filter((s) => supervisor.srcAge(s.id, 'navegador') >= 20000 && supervisor.srcAge(s.id, 'directo') < 20000).length, compartidas: Object.keys(jmobile.sharedHosts()).length, sesionUnica: supervisor.getConfig().sesionUnica !== false, viewers: supViewers.size, calibrated: sites.filter((s) => isSiteCalibrated(s.id)).length, total: sites.length, lastCycleMs: supLastCycle.ms, lastCycleAt: supLastCycle.at };
}
/* Cada sitio tiene su PROPIO ciclo de lectura: una pantalla lenta o sin respuesta ya no frena a las demás
   (antes se esperaba a que terminara la vuelta completa y por eso a veces se veía "pasmado" 10–20 s). */
const SUP_SITE_MS = parseInt(process.env.SUPERVISOR_SITIO_MS || '1000', 10);   // pausa entre lecturas de un mismo sitio
let supSlots = Math.max(1, SUP_CONCURRENCY * 2);                                 // lecturas simultáneas máximas
const supWaiters = [];
async function supAcquire() { if (supSlots > 0) { supSlots--; return; } await new Promise((r) => supWaiters.push(r)); }
function supRelease() { const w = supWaiters.shift(); if (w) w(); else supSlots++; }
const supSiteLoops = new Set();
const supRenew = {};
/* ── v14: lectura COMPLETA de cada pantalla (racks, PCS, medidores…) ──
   Más lenta que la principal: cada 90 s por sitio (cada 10 s si alguien tiene abierto ese sitio en ⛶).
   Va un sitio a la vez para no cargar la VPN ni las pantallas. */
const deepData = {}, deepWatch = {}, deepAlarms = {}, hmiAlarms = {};
// Severidad del HMI (JMobile) → vocabulario del supervisor (para color/rojo). Se conserva el texto original ("1-low", "4-above normal"…) aparte.
function normSevHmi(raw) {
  const s = String(raw || '').toLowerCase(), m = s.match(/(\d+)/), n = m ? +m[1] : 0;
  if (n >= 5 || /high|critical|emergen|crit|fire|smog|smoke/.test(s)) return 'crítica';
  if (n === 4 || /above normal|major|fault|trip/.test(s)) return 'alta';
  if (n === 3 || /\bnormal\b|medium|moderate/.test(s)) return 'media';
  if (n === 1 || n === 2 || /low|below|minor|info|warn/.test(s)) return 'baja';
  return 'media';
}
// Alarmas leídas TAL CUAL del HMI (nombre + severidad), enviadas por el script Relay desde la pestaña ya logueada.
function ingestHmiAlarms(id, arr) {
  const seen = {}, items = [];
  (Array.isArray(arr) ? arr : []).forEach((a) => {
    const nombre = String((a && a.nombre) || '').trim(); if (!nombre || seen[nombre]) return; seen[nombre] = 1;
    const raw = String((a && a.sev) || '');
    items.push({ nombre, sev: normSevHmi(raw), sevTxt: raw, tipo: 'alarma', valor: (a && a.valor != null) ? a.valor : '', hora: (a && a.hora) || '' });
  });
  const crit = items.filter((a) => a.sev === 'crítica' || a.sev === 'alta').length;
  hmiAlarms[id] = { at: Date.now(), activas: items.length, crit, items, source: 'hmi' };
}
async function deepLoop() {
  for (;;) {
    try {
      const scfg = supervisor.getConfig();
      // Racks/PCS: se leen mientras haya con qué (sesión directa, o —en modo solo pestaña— reutilizando la cookie de la pestaña).
      // En modo unSoloLogin, readDeep NO abre sesión propia: si no hay cookie de pestaña que compartir, no lee (no 2ª sesión).
      if (supActive() && scfg.lecturaCompleta !== false && (scfg.lecturaDirecta || scfg.unSoloLogin)) {
        const list = sites.slice().sort((a, b) => (deepWatch[b.id] || 0) - (deepWatch[a.id] || 0));
        for (const site of list) {
          if (!jmobile.isJMobileSite(site) || Number(site.port) === 7010 || (vncMgr && vncMgr.has(site.id))) continue;
          const stc = state.get(site.id); if (stc && stc.status === 'offline') continue;
          const now = Date.now();
          const watched = deepWatch[site.id] && now - deepWatch[site.id] < 120000, d = deepData[site.id] || {};
          if (d.errAt && now - d.errAt < (watched ? 8000 : 120000)) continue;
          // watched: refresco EN VIVO cada ~3.5 s (solo racks/PCS/medidor) + lectura completa cada 45 s
          const gap = watched ? 3500 : 90000;
          if (d.at && now - d.at < gap) continue;
          const needFull = !d.values || !d.fullAt || now - d.fullAt > (watched ? 45000 : 90000);
          try {
            const cli = jmobile.client(site, (st) => supervisor.scadaCredsFor(st, scadaAuth));
            if (needFull) {
              deepData[site.id] = Object.assign(await cli.readDeep(), { err: null, errAt: 0, fullAt: Date.now() });
            } else {
              const live = await cli.readDeepLive(), cur = deepData[site.id] || {};
              cur.values = Object.assign({}, cur.values, live.values); cur.at = live.at; cur.err = null; cur.errAt = 0; cur.pageOf = cur.pageOf || live.pageOf;
              deepData[site.id] = cur;
            }
            try {
              const dd = deepData[site.id];
              if (dd && dd.values) {
                const parsed = equiposLib.parse(dd.values, { at: dd.at });
                deephist.record(site.id, parsed);
                const act = (parsed.alarmas || []).filter((a) => a.activo);
                deepAlarms[site.id] = {
                  at: dd.at,
                  activas: act.length,
                  crit: act.filter((a) => a.sev === 'crítica' || a.sev === 'alta').length,
                  items: act.map((a) => ({ nombre: a.nombre, sev: a.sev, tipo: a.tipo })),
                };
              }
            } catch (_) {}
          }
          catch (e) { deepData[site.id] = Object.assign(d, { err: e.message, errAt: Date.now() }); }
          if (watched) break;   // vuelve a priorizar el sitio que se está viendo
        }
      }
    } catch (_) {}
    await sleep(800);
  }
}
setTimeout(deepLoop, 20000);
try { deephist.prune(); setInterval(() => deephist.prune(), 24 * 3600e3); } catch (_) {}
const relayHosts = {}; // host → último envío del Relay
const SUP_BOOT = Date.now();
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function siteLoop(siteId) {
  if (supSiteLoops.has(siteId)) return; supSiteLoops.add(siteId);
  try {
    while (supActive()) {
      const site = sites.find((s) => s.id === siteId);
      if (!site || !isSiteCalibrated(site.id)) break;
      const stc = state.get(site.id);
      if (vncMgr && vncMgr.has(site.id)) { await sleep(5000); continue; }   // lo lee el módulo VNC
      if (Number(site.port) === 7010) { await sleep(5000); continue; }   // SEL RTAC (LG): no es JMobile, solo se lee por su pestaña con el Relay
      if (stc && stc.status === 'offline') { await sleep(5000); continue; }                                  // sin comunicación (ping)
      if (!supervisor.getConfig().lecturaDirecta && supervisor.srcAge(site.id, 'navegador') < 20000) { jmobile.logoutSite(site.id); await sleep(3000); continue; } // modo solo pestañas: la pestaña ya manda datos
      // Modo "solo pestañas" (default): el Supervisor NO inicia sesión en las pantallas (tienen pocos accesos).
      // Los datos llegan únicamente de las pestañas de Chrome con el script Relay.
      const scfg = supervisor.getConfig(), ageTab = supervisor.srcAge(site.id, 'navegador');
      // Respaldo: si la pestaña de este sitio YA mandaba datos y se calló (sesión cerrada, pestaña congelada…),
      // el Supervisor lee con su propia sesión mientras tanto y la suelta en cuanto la pestaña regresa. Así no se pierden datos.
      // v11.2: también cuenta un sitio cuya pestaña no ha mandado nada desde que arrancó el monitor (antes se quedaba sin datos)
      const graciaOk = Date.now() - SUP_BOOT > (scfg.respaldoSeg || 45) * 1000;
      const respaldo = scfg.respaldoDirecto !== false && graciaOk && (ageTab === Infinity ? scfg.respaldoSoloConPestana !== true : ageTab > (scfg.respaldoSeg || 45) * 1000);
      if (!scfg.lecturaDirecta && !respaldo) { await sleep(3000); continue; }
      const t0 = Date.now();
      await supAcquire();
      try {
        if (jmobile.isJMobileSite(site)) {
          // si la lectura directa lleva rato congelada, se abre una sesión nueva (algunas pantallas dejan de refrescar la sesión vieja)
          const vv = supervisor.view(site.id); if (vv && vv.congeladoHint && (!supRenew[site.id] || Date.now() - supRenew[site.id] > 600000)) { supRenew[site.id] = Date.now(); await jmobile.logoutSite(site.id); }
          // El servidor lee con la cookie de la pestaña (MISMA sesión = un solo login). Fuente 'directo' para que su lectura COMPLETA tenga prioridad sobre la lectura parcial de la pestaña (evita el parpadeo). Se MUESTRA como "pestaña" (ver view()).
          try { const data = await jmobile.client(site, (st) => supervisor.scadaCredsFor(st, scadaAuth)).read(); supervisor.ingest(site.id, data, 'directo'); }
          catch (err) { supervisor.readError(site.id, err.message); if (site.scadaEndpoint) await pollScada(site); if (AUTO_VISION && visionConfig[site.id]) await pollVisionSafe(site); }
        } else { if (site.scadaEndpoint) await pollScada(site); if (AUTO_VISION && visionConfig[site.id]) await pollVisionSafe(site); }
      } catch (_) {} finally { supRelease(); }
      supLastCycle = { ms: Date.now() - t0, at: Date.now(), sites: supSiteLoops.size };
      await sleep(Math.max(250, SUP_SITE_MS - (Date.now() - t0)));
    }
  } finally { supSiteLoops.delete(siteId); }
}
async function supervisorLoop() {
  if (supLoopRunning) return;
  supLoopRunning = true;
  console.log(supAlwaysOn() ? '[supervisor] lectura continua 24/7 ACTIVADA (grabando histórico)' : '[supervisor] lectura continua ACTIVADA (pantalla del supervisor abierta)');
  while (supActive()) {
    sites.filter((s) => isSiteCalibrated(s.id)).forEach((s, i) => { if (!supSiteLoops.has(s.id)) setTimeout(() => siteLoop(s.id), (i % 20) * 50); }); // también arranca sitios nuevos
    io.emit('supervisor:status', supStatus());
    await sleep(5000);
  }
  supLoopRunning = false;
  jmobile.logoutAll(); // se cierran las sesiones en las pantallas para no ocupar lugares
  console.log('[supervisor] lectura continua en pausa (no hay pantallas del supervisor abiertas)');
}

// Escalona los chequeos para no lanzar 35+ pings en el mismo instante exacto
function scheduleSitePolling(site, idx) {
  const offset = (idx * 250) % PING_INTERVAL_MS;
  setTimeout(() => {
    pollConnectivity(site);
    setInterval(() => pollConnectivity(site), PING_INTERVAL_MS);
  }, offset);

  if (site.scadaEndpoint) {
    const scadaOffset = (idx * 400) % SCADA_INTERVAL_MS;
    setTimeout(() => {
      pollScada(site);
      setInterval(() => pollScada(site), SCADA_INTERVAL_MS);
    }, scadaOffset);
  }

  if (AUTO_VISION) {
    const visionOffset = (idx * 1500) % VISION_INTERVAL_MS;
    setTimeout(() => {
      pollVisionSafe(site);
      setInterval(() => { if (!supLoopRunning) pollVisionSafe(site); }, VISION_INTERVAL_MS); // si el supervisor ya está leyendo, no se duplica
    }, visionOffset + 5000);
  }
}

const scheduledSiteIds = new Set();

function ensureSiteScheduled(site, idx) {
  if (scheduledSiteIds.has(site.id)) return; // ya tiene su ciclo corriendo, no se duplica
  scheduledSiteIds.add(site.id);
  scheduleSitePolling(site, idx);
}

function startLoops() {
  sites.forEach((site, idx) => ensureSiteScheduled(site, idx));
}

async function startServer() {
  const behindProxy = process.env.BEHIND_PROXY === '1';

  if (behindProxy) {
    // Modo servidor en la nube: un reverse proxy (Caddy/nginx) al frente
    // maneja el dominio y el certificado real (Let's Encrypt); esta app
    // habla HTTP en texto plano solo hacia adentro (localhost).
    app.set('trust proxy', 1);
    server = http.createServer(app);
  } else {
    // v16: el MISMO puerto atiende http:// y https:// (se distingue por el primer byte de la conexión).
    //   http://localhost:3000  → sin aviso de certificado: se puede instalar como app y no se queda en negro
    //   https://localhost:3000 → sigue funcionando igual que antes (con el certificado propio)
    const tlsOptions = await tlsCert.getOrCreateCert();
    server = http.createServer(app);
    let secureContext = null; try { secureContext = tls.createSecureContext(tlsOptions); } catch (e) { console.error('[tls] certificado inválido, solo habrá http:', e.message); }
    dualServer = net.createServer((sock) => {
      sock.on('error', () => {});
      sock.once('data', (buf) => {
        sock.pause(); sock.unshift(buf);
        if (buf[0] === 0x16 && secureContext) {
          const t = new tls.TLSSocket(sock, { isServer: true, secureContext, ALPNProtocols: ['http/1.1'] });
          t.on('error', () => {});
          server.emit('connection', t);
        } else server.emit('connection', sock);
        process.nextTick(() => sock.resume());
      });
    });
  }

  // pingTimeout alto: si la PC se congela unos segundos (RAM/CPU saturada), el navegador NO marca
  // "SIN CONEXIÓN" ni se reinicia la vista por un parón corto; aguanta hasta 60 s antes de cortar.
  io = new Server(server, { pingInterval: 25000, pingTimeout: 60000, maxHttpBufferSize: 5e6 });

  supervisor.init({
    io,
    getSites: () => sites,
    getComm: (id) => { const st = state.get(id); return st ? { status: st.status, maintenance: store.getMaintenance(id) } : null; },
    isCalibrated: isSiteCalibrated,
  });
  // v15: inicio de sesión único — el Supervisor solo usa la sesión de las pestañas (no abre una propia)
  jmobile.configure({ sesionUnica: () => supervisor.getConfig().sesionUnica !== false, sharedOnly: () => supervisor.getConfig().unSoloLogin !== false });
  // Comunicación por sitio: estado en vivo + historial (eventos y muestra por minuto)
  try { commsMgr = require('./lib/comms').init({ getSites: () => supervisor.allSites(), getPing: (id) => state.get(id), getView: (id) => { try { return supervisor.view(id); } catch (_) { return null; } } }); } catch (e) { console.error('[comms] no se pudo iniciar:', e.message); }
  // FusionSolar (Huawei): plantas que se leen desde la pestaña de FusionSolar con el script "FusionSolar Relay"
  try { let fsT = 0, fsPend = null; fusionMgr = require('./lib/fusionsolar').init({
    emit: (st) => { fsPend = st; const now = Date.now(); if (now - fsT > 2000) { fsT = now; io.emit('fusion:estado', st); fsPend = null; } else setTimeout(() => { if (fsPend) { fsT = Date.now(); io.emit('fusion:estado', fsPend); fsPend = null; } }, 2100); },
    alert: (ev) => supervisor.externalEvent(ev),
  }); } catch (e) { console.error('[fusion] no se pudo iniciar:', e.message); }
  // PV (solar) — subsistema aparte del BESS, alimentado por los Relay de los portales (FusionSolar, Solis, Sungrow, SMA)
  try { let pvT = 0, pvPend = null; pvMgr = require('./lib/pv').init({
    emit: (st) => { pvPend = st; const now = Date.now(); if (now - pvT > 2000) { pvT = now; io.emit('pv:estado', st); pvPend = null; } else setTimeout(() => { if (pvPend) { pvT = Date.now(); io.emit('pv:estado', pvPend); pvPend = null; } }, 2100); },
    alert: (ev) => supervisor.externalEvent(ev),
  }); } catch (e) { console.error('[pv] no se pudo iniciar:', e.message); }
  // FusionSolar ESS (baterías) — detalle por sitio (racks/SOC/SOH/temperaturas/humedad/CO/sensores/alarmas)
  try { let feT = 0, fePend = null; fusionEssMgr = require('./lib/fusioness').init({
    alert: (ev) => supervisor.externalEvent(ev),
    emit: (st) => { fePend = st; const now = Date.now(); if (now - feT > 2000) { feT = now; io.emit('fusioness:estado', st); fePend = null; } else setTimeout(() => { if (fePend) { feT = Date.now(); io.emit('fusioness:estado', fePend); fePend = null; } }, 2100); },
  }); } catch (e) { console.error('[fusion-ess] no se pudo iniciar:', e.message); }
  // Envío automático del Reporte de Validación Diaria PV por Outlook (config/pv-reporte.json)
  try { if (pvMgr) { reporteCorreo = require('./lib/reportemail'); reporteCorreo.iniciarProgramador(pvMgr); } } catch (e) { console.error('[pv-reporte] no se pudo iniciar:', e.message); }
  // Archivador automático por sitio → carpeta OneDrive/Drive (curvas, reportes, crudo) — config/archivador.json
  try { require('./lib/archivador').iniciarProgramador({ supervisor, historian }); } catch (e) { console.error('[archivador] no se pudo iniciar:', e.message); }
  // Sitios por VNC (BOCAR, IPASA, FM Boca del Río…): conexión compartida 24/7 + OCR de las zonas calibradas
  try { vncMgr = require('./lib/vncsites').init({ getSites: () => sites, ingest: (id, data) => supervisor.ingest(id, data, 'vnc'), readError: (id, msg) => supervisor.readError(id, msg) }); } catch (e) { console.error('[vnc] no se pudo iniciar:', e.message); }

  io.on('connection', (socket) => {
    socket.emit('sites:changed', sites.map(publicSiteView));
    socket.emit('events:init', store.getEvents(100));
    socket.emit('supervisor:init', supervisor.allViews());
    if (fusionMgr) socket.emit('fusion:estado', fusionMgr.estado());
    if (pvMgr) socket.emit('pv:estado', pvMgr.estado());
    if (fusionEssMgr) socket.emit('fusioness:estado', fusionEssMgr.estado());
    // La pantalla del supervisor se anuncia al abrir → arranca la lectura continua
    socket.on('supervisor:join', () => {
      supViewers.add(socket.id);
      socket.emit('supervisor:init', supervisor.allViews());
      io.emit('supervisor:status', supStatus());
      supervisorLoop();
    });
    socket.on('disconnect', () => {
      if (supViewers.delete(socket.id)) io.emit('supervisor:status', supStatus());
    });
  });

  startLoops();
  // SUPERVISOR: libera cualquier sesión que el Supervisor haya dejado abierta en las pantallas
  jmobile.logoutPersisted().then((n) => { if (n) console.log(`[supervisor] se cerraron ${n} sesión(es) que había dejado abiertas en las pantallas`); }).catch(() => {});
  // SUPERVISOR 24/7: arranca la lectura continua con el servidor (graba el histórico aunque nadie vea la pantalla)
  setTimeout(() => { if (supAlwaysOn()) supervisorLoop(); }, 8000);
  // si se activa "siempre activo" desde la configuración, arranca sin reiniciar
  setInterval(() => { if (supAlwaysOn() && !supLoopRunning) supervisorLoop(); }, 60000);

  // SUPERVISOR: receptor local (solo 127.0.0.1) para el script "Relay" del monkey. Cada pestaña de
  // una pantalla ya abierta manda sus lecturas aquí usando SU propia sesión → no ocupa lugares extra.
  const RELAY_PORT = parseInt(process.env.SUPERVISOR_RELAY_PORT || String(PORT + 1), 10);
  http.createServer((req, res) => {
    res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
    res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    res.setHeader('Access-Control-Allow-Private-Network', 'true');
    if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
    if (req.method === 'GET' && /^\/ping/.test(req.url)) { res.writeHead(200, { 'Content-Type': 'application/json' }); return res.end('{"ok":true}'); }
    // http://127.0.0.1:3001/estado → qué pestañas están mandando datos (para revisar el Relay)
    if (req.method === 'GET' && /^\/estado/.test(req.url)) {
      const now = Date.now(), rows = Object.keys(relayHosts).sort().map((h) => { const r = relayHosts[h]; const esc = (x) => String(x).replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c])); const ok = r.tOk && now - r.tOk < 20000; return `<tr style="background:${ok ? '#ecfdf5' : '#fef2f2'}"><td>${h}</td><td>${r.sitio || '<b style="color:#dc2626">no coincide con ningún sitio</b>'}</td><td>${r.n}</td><td>${Math.round((now - r.t) / 1000)} s</td><td>${r.tOk ? Math.round((now - r.tOk) / 1000) + ' s' : 'nunca'}</td><td>${esc(r.diag || '')}</td><td>${esc(r.ver || '')}</td></tr>`; }).join('');
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      return res.end(`<meta charset="utf-8"><meta http-equiv="refresh" content="3"><title>Relay</title><body style="font-family:sans-serif"><h2>Pestañas que mandan datos al Supervisor</h2><table border="1" cellpadding="6" style="border-collapse:collapse"><tr><th>Pantalla</th><th>Sitio</th><th>Datos</th><th>Último contacto</th><th>Últimos datos</th><th>Estado de la pestaña</th><th>Versión</th></tr>${rows || '<tr><td colspan="7">Ninguna pestaña ha mandado datos todavía. Revisa que el script Relay esté instalado y activo en Tampermonkey y recarga las pestañas.</td></tr>'}</table></body>`);
    }
    // respaldo de transporte del Relay: GET /ingest?j=<json> (por si el navegador bloquea el POST)
    if (req.method === 'GET' && /^\/ingest\?/.test(req.url)) {
      try { const body = JSON.parse(new URL(req.url, 'http://x').searchParams.get('j') || '{}'); relayBodyHandler(body); } catch (_) {}
      res.writeHead(204); return res.end();
    }
    if (req.method !== 'POST' || !/^\/ingest/.test(req.url)) { res.writeHead(404); return res.end('{}'); }
    let b = '';
    req.on('data', (c) => { b += c; if (b.length > 2e6) req.destroy(); });
    req.on('end', () => {
      let n = 0, body = null; try { body = JSON.parse(b); } catch (_) {}
      n = relayBodyHandler(body);
      res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ ok: true, updated: n }));
    });
  }).on('error', (err) => console.error('[supervisor] no se pudo abrir el receptor local', RELAY_PORT, err.message))
    .listen(RELAY_PORT, '127.0.0.1', () => console.log(`[supervisor] receptor del script Relay en http://127.0.0.1:${RELAY_PORT}/ingest`));
  function relayBodyHandler(body) {
      if (!body) return 0;
      if (body.fusion) { let m = 0; try { if (fusionMgr) m = fusionMgr.ingest(body.fusion); } catch (e) { console.error('[fusion]', e.message); } try { if (pvMgr) pvMgr.ingestFusion(body.fusion); } catch (e) { console.error('[pv-fusion]', e.message); } return m; }
      if (body.fusionEss) { let m = 0; try { if (fusionEssMgr) { m = fusionEssMgr.ingest(body.fusionEss); if (io) io.emit('fusioness:estado', fusionEssMgr.estado()); } } catch (e) { console.error('[fusion-ess]', e.message); } return m; }
      if (body.pv) { try { return pvMgr ? pvMgr.ingest(body.pv) : 0; } catch (e) { console.error('[pv]', e.message); return 0; } }
      let n = 0; try { n = supervisorIngestItems(body); } catch (_) {}
      try { const items = Array.isArray(body) ? body : (body && body.items) || [body]; items.forEach((it) => { if (!it || !it.host) return; const st = sites.find((x) => `${x.ip}:${x.port}` === it.host) || sites.find((x) => x.ip === String(it.host).split(':')[0]); if (it.alarmas && Array.isArray(it.alarmas)) { if (st) { try { ingestHmiAlarms(st.id, it.alarmas); } catch (_) {} } if (!it.data) return; } if (it.sesion && it.sesion.cookie) jmobile.adoptSession(it.host, it.sesion); const nF = ((it.data || {}).fields || []).length, prev = relayHosts[it.host] || {}; relayHosts[it.host] = { t: Date.now(), n: nF, tOk: nF ? Date.now() : prev.tOk || 0, sitio: st ? st.name : null, diag: it.diag ? String(it.diag).slice(0, 200) : (nF ? 'enviando' : ''), ver: it.ver || prev.ver || '' }; }); } catch (_) {}
      return n;
  }

  (dualServer || server).listen(PORT, () => {
    if (behindProxy) {
      console.log(`BESS Monitor corriendo en http://localhost:${PORT} (detrás de reverse proxy)`);
    } else {
      console.log(`BESS Monitor corriendo en http://localhost:${PORT}   ← usa esta (sin avisos, se puede instalar como app)`);
      console.log(`                 y también en https://localhost:${PORT} (certificado propio)`);
    }
    console.log(`Monitoreando ${sites.length} sitio(s). Intervalo de ping: ${PING_INTERVAL_MS} ms`);
  });

}

startServer().catch((err) => {
  console.error('No se pudo iniciar el servidor:', err.message);
  process.exit(1);
});

async function shutdown() {
  try { historian.flushAll(); } catch (_) {}
  try { await Promise.race([jmobile.logoutAll(), new Promise((r) => setTimeout(r, 3000))]); } catch (_) {}
  try { await vision.closeBrowser(); } catch (_) {}
  process.exit(0);
}
// Ctrl+C, cerrar la ventana negra de Windows (SIGHUP/SIGBREAK) o apagar: se guarda el minuto en curso y se cierran las sesiones
['SIGINT', 'SIGTERM', 'SIGHUP', 'SIGBREAK'].forEach((sig) => { try { process.on(sig, shutdown); } catch (_) {} });
