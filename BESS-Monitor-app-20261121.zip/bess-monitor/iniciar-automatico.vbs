Set objShell = CreateObject("WScript.Shell")
Set objFSO = CreateObject("Scripting.FileSystemObject")
strScriptDir = objFSO.GetParentFolderName(WScript.ScriptFullName)
' Minimizado (7) en vez de oculto (0) — así si algo falla, se puede ver la ventana.
objShell.Run "cmd /c cd /d """ & strScriptDir & """ && iniciar.bat", 7, False
