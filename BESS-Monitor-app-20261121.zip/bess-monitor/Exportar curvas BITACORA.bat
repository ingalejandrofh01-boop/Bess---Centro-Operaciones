@echo off
rem ==== Exporta las curvas de Bitacora (Centro BESS) a la carpeta de OneDrive ====
rem Doble clic para probar manualmente (muestra el resumen y espera una tecla).
rem El Programador de tareas llama a "node" directamente (ver LEEME-curvas.txt).
cd /d "%~dp0"
node "exportar-curvas-bitacora.js"
echo.
echo ---------------------------------------------
echo Terminado. Revisa la carpeta BITACORA.
pause
